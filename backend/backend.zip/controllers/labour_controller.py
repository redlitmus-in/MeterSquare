"""
Labour Management Controller
Handles all business logic for the 8-step Labour/Attendance workflow:
1. Production Manager - Add Labour to Registry
2. Site Engineer - Raise Site Requisition
3. Project Manager - Approve/Reject Requisition
4. Production Manager - Allocate & Assign Personnel
5. Site Engineer - Confirm Site Arrival
6. Site Engineer - Daily Attendance Logs
7. Project Manager - Review & Lock Data
8. Admin (HR) - Payroll Processing
"""
from datetime import datetime, date, timedelta
from flask import request, jsonify, g
from config.db import db
from config.logging import get_logger
from models.worker import Worker
from models.labour_requisition import LabourRequisition
from models.labour_arrival import LabourArrival
from models.worker_assignment import WorkerAssignment
from models.daily_attendance import DailyAttendance, AttendanceApprovalHistory
from sqlalchemy.orm import selectinload, joinedload
from sqlalchemy import func, and_, or_
from utils.whatsapp_service import WhatsAppService
from utils.skill_matcher import skill_matches

log = get_logger()

# Initialize WhatsApp service
whatsapp_service = WhatsAppService()

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

# Role sets for authorization (normalized without spaces/underscores)
SUPER_ADMIN_ROLES = frozenset(['admin', 'td', 'technicaldirector'])
LABOUR_ADMIN_ROLES = frozenset(['admin', 'td', 'technicaldirector', 'productionmanager'])


def normalize_role(role: str) -> str:
    """Normalize role string for consistent comparison."""
    if not role:
        return ''
    return role.lower().replace(' ', '').replace('_', '').replace('-', '')


def get_user_assigned_project_ids(user_id: int) -> list:
    """
    Get list of project IDs where user is assigned in any role.
    Returns empty list if user_id is None or invalid.
    """
    if not user_id:
        return []

    from models.project import Project

    assigned_projects = Project.query.filter(
        Project.is_deleted == False,
        or_(
            # PM: user_id is JSONB array, check if user_id is in the array
            Project.user_id.contains([user_id]),
            # Site Supervisor/SE
            Project.site_supervisor_id == user_id,
            # MEP Supervisor: mep_supervisor_id is JSONB array
            Project.mep_supervisor_id.contains([user_id]),
            # Estimator
            Project.estimator_id == user_id,
            # Buyer
            Project.buyer_id == user_id
        )
    ).with_entities(Project.project_id).all()

    return [p.project_id for p in assigned_projects]


# =============================================================================
# STEP 1: WORKER REGISTRY (Production Manager)
# =============================================================================

def get_workers():
    """Get all workers with optional filters"""
    try:
        current_user = g.user

        # Query params
        status = request.args.get('status', 'active')
        skill = request.args.get('skill')
        search = request.args.get('search')
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 20, type=int), 100)

        query = Worker.query.filter(Worker.is_deleted == False)

        if status and status != 'all':
            query = query.filter(Worker.status == status)

        if search:
            search_term = f"%{search}%"
            query = query.filter(
                or_(
                    Worker.full_name.ilike(search_term),
                    Worker.worker_code.ilike(search_term),
                    Worker.phone.ilike(search_term)
                )
            )

        query = query.order_by(Worker.created_at.desc())

        # Apply skill filter with flexible matching
        if skill:
            all_results = query.all()
            skill_filtered = [w for w in all_results if skill_matches(skill, w.skills or [])]

            # Manual pagination after filtering
            total = len(skill_filtered)
            start = (page - 1) * per_page
            end = start + per_page
            items = skill_filtered[start:end]

            return jsonify({
                "success": True,
                "workers": [w.to_dict() for w in items],
                "pagination": {
                    "page": page,
                    "per_page": per_page,
                    "total": total,
                    "pages": (total + per_page - 1) // per_page,
                    "has_prev": page > 1,
                    "has_next": end < total
                }
            }), 200
        else:
            paginated = query.paginate(page=page, per_page=per_page, error_out=False)
            return jsonify({
                "success": True,
                "workers": [w.to_dict() for w in paginated.items],
                "pagination": {
                    "page": page,
                    "per_page": per_page,
                    "total": paginated.total,
                    "pages": paginated.pages,
                    "has_prev": paginated.has_prev,
                    "has_next": paginated.has_next
                }
            }), 200

    except Exception as e:
        log.error(f"Error getting workers: {str(e)}")
        return jsonify({"error": str(e)}), 500


def create_worker():
    """Create a new worker in the registry"""
    try:
        current_user = g.user
        data = request.get_json()

        # Validate required fields
        if not data.get('full_name'):
            return jsonify({"error": "full_name is required"}), 400
        if not data.get('hourly_rate'):
            return jsonify({"error": "hourly_rate is required"}), 400

        # Generate worker code
        worker_code = Worker.generate_worker_code()

        worker = Worker(
            worker_code=worker_code,
            full_name=data['full_name'],
            phone=data.get('phone'),
            email=data.get('email'),
            hourly_rate=float(data['hourly_rate']),
            skills=data.get('skills', []),
            worker_type=data.get('worker_type', 'regular'),
            emergency_contact=data.get('emergency_contact'),
            emergency_phone=data.get('emergency_phone'),
            id_number=data.get('id_number'),
            id_type=data.get('id_type'),
            photo_url=data.get('photo_url'),
            status='active',
            notes=data.get('notes'),
            created_by=current_user.get('full_name', 'System')
        )

        db.session.add(worker)
        db.session.commit()

        log.info(f"Worker created: {worker_code} by {current_user.get('full_name')}")

        return jsonify({
            "success": True,
            "message": "Worker created successfully",
            "worker": worker.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        log.error(f"Error creating worker: {str(e)}")
        return jsonify({"error": str(e)}), 500


def get_worker_by_id(worker_id):
    """Get a single worker by ID"""
    try:
        worker = Worker.query.filter_by(
            worker_id=worker_id,
            is_deleted=False
        ).first()

        if not worker:
            return jsonify({"error": "Worker not found"}), 404

        return jsonify({
            "success": True,
            "worker": worker.to_dict()
        }), 200

    except Exception as e:
        log.error(f"Error getting worker: {str(e)}")
        return jsonify({"error": str(e)}), 500


def update_worker(worker_id):
    """Update worker information"""
    try:
        current_user = g.user
        data = request.get_json()

        worker = Worker.query.filter_by(
            worker_id=worker_id,
            is_deleted=False
        ).first()

        if not worker:
            return jsonify({"error": "Worker not found"}), 404

        # Update fields
        if 'full_name' in data:
            worker.full_name = data['full_name']
        if 'phone' in data:
            worker.phone = data['phone']
        if 'email' in data:
            worker.email = data['email']
        if 'hourly_rate' in data:
            worker.hourly_rate = float(data['hourly_rate'])
        if 'skills' in data:
            worker.skills = data['skills']
        if 'worker_type' in data:
            worker.worker_type = data['worker_type']
        if 'emergency_contact' in data:
            worker.emergency_contact = data['emergency_contact']
        if 'emergency_phone' in data:
            worker.emergency_phone = data['emergency_phone']
        if 'id_number' in data:
            worker.id_number = data['id_number']
        if 'id_type' in data:
            worker.id_type = data['id_type']
        if 'photo_url' in data:
            worker.photo_url = data['photo_url']
        if 'status' in data:
            worker.status = data['status']
        if 'notes' in data:
            worker.notes = data['notes']

        worker.last_modified_by = current_user.get('full_name', 'System')

        db.session.commit()

        log.info(f"Worker updated: {worker.worker_code} by {current_user.get('full_name')}")

        return jsonify({
            "success": True,
            "message": "Worker updated successfully",
            "worker": worker.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error updating worker: {str(e)}")
        return jsonify({"error": str(e)}), 500


def delete_worker(worker_id):
    """Soft delete a worker"""
    try:
        current_user = g.user

        worker = Worker.query.filter_by(
            worker_id=worker_id,
            is_deleted=False
        ).first()

        if not worker:
            return jsonify({"error": "Worker not found"}), 404

        worker.is_deleted = True
        worker.status = 'terminated'
        worker.last_modified_by = current_user.get('full_name', 'System')

        db.session.commit()

        log.info(f"Worker deleted: {worker.worker_code} by {current_user.get('full_name')}")

        return jsonify({
            "success": True,
            "message": "Worker deleted successfully"
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error deleting worker: {str(e)}")
        return jsonify({"error": str(e)}), 500


def get_workers_by_skill(skill):
    """Get workers with a specific skill"""
    try:
        # Get all active workers
        all_workers = Worker.query.filter(
            Worker.is_deleted == False,
            Worker.status == 'active'
        ).all()

        # Filter using flexible skill matching
        matching_workers = []
        for worker in all_workers:
            if skill_matches(skill, worker.skills or []):
                matching_workers.append(worker)

        return jsonify({
            "success": True,
            "workers": [w.to_dict_minimal() for w in matching_workers]
        }), 200

    except Exception as e:
        log.error(f"Error getting workers by skill: {str(e)}")
        return jsonify({"error": str(e)}), 500


# =============================================================================
# STEP 2: REQUISITIONS (Site Engineer)
# =============================================================================

def create_requisition():
    """Site Engineer or Project Manager creates a labour requisition with multiple labour items"""
    try:
        current_user = g.user
        data = request.get_json()

        # Detect if requester is PM or SE - ALWAYS use session role, NEVER trust request body
        # This is critical for security - malicious SE could send requester_role='PM' to bypass approval
        user_role = normalize_role(current_user.get('role', ''))
        requester_role = 'PM' if user_role in ['pm', 'projectmanager'] else 'SE'

        # Ignore any requester_role from request body for security
        if data.get('requester_role'):
            log.warning(f"Ignoring requester_role from request body. Using session role: {requester_role}")

        # Validate required fields
        required = ['project_id', 'site_name', 'required_date', 'labour_items']
        for field in required:
            if not data.get(field):
                return jsonify({"error": f"{field} is required"}), 400

        # Validate labour_items array
        labour_items = data.get('labour_items', [])
        if not isinstance(labour_items, list) or len(labour_items) == 0:
            return jsonify({"error": "labour_items must be a non-empty array"}), 400

        # Validate each labour item
        for idx, item in enumerate(labour_items):
            required_item_fields = ['work_description', 'skill_required', 'workers_count']
            for field in required_item_fields:
                if not item.get(field):
                    return jsonify({"error": f"labour_items[{idx}].{field} is required"}), 400

        # Generate requisition code with retry logic for race conditions
        max_retries = 5
        requisition = None

        for attempt in range(max_retries):
            try:
                # Generate unique requisition code
                requisition_code = LabourRequisition.generate_requisition_code()

                # Get first labour item for backward compatibility fields
                first_item = labour_items[0]
                total_workers = sum(item.get('workers_count', 0) for item in labour_items)

                # Create single requisition with multiple labour items
                # Status Flow:
                # - Both PM and SE requisitions: 'pending' (draft, must be manually sent)
                # - PM must manually send to Production Manager (no auto-approval)
                # - SE must send to PM first, then PM sends to Production Manager
                initial_status = 'pending'

                # Parse time fields if provided
                start_time = None
                end_time = None

                if data.get('start_time'):
                    try:
                        start_time = datetime.strptime(data['start_time'], '%H:%M').time()
                    except ValueError:
                        return jsonify({"error": "Invalid time format for start_time. Use HH:MM"}), 400

                if data.get('end_time'):
                    try:
                        end_time = datetime.strptime(data['end_time'], '%H:%M').time()
                    except ValueError:
                        return jsonify({"error": "Invalid time format for end_time. Use HH:MM"}), 400

                # Validate times: End time must be after start time
                if start_time and end_time:
                    # Convert to minutes for comparison
                    start_minutes = start_time.hour * 60 + start_time.minute
                    end_minutes = end_time.hour * 60 + end_time.minute
                    if end_minutes <= start_minutes:
                        return jsonify({"error": "End time must be after start time"}), 400

                requisition = LabourRequisition(
                    requisition_code=requisition_code,
                    project_id=data['project_id'],
                    site_name=data['site_name'],
                    required_date=datetime.strptime(data['required_date'], '%Y-%m-%d').date(),
                    start_time=start_time,
                    end_time=end_time,
                    preferred_worker_ids=data.get('preferred_worker_ids', []),
                    preferred_workers_notes=data.get('preferred_workers_notes'),
                    labour_items=labour_items,  # Store all labour items in JSONB
                    # Backward compatibility: populate old fields with first item or summary
                    work_description=first_item.get('work_description') if len(labour_items) == 1 else f"Multiple Labour Items ({len(labour_items)} items)",
                    skill_required=first_item.get('skill_required') if len(labour_items) == 1 else "Multiple Skills",
                    workers_count=total_workers,  # Total workers across all items
                    boq_id=first_item.get('boq_id'),
                    item_id=first_item.get('item_id'),
                    labour_id=first_item.get('labour_id'),
                    work_status='pending_assignment',
                    requested_by_user_id=current_user.get('user_id'),
                    requested_by_name=current_user.get('full_name', 'Unknown'),
                    requester_role=requester_role,  # Track if PM or SE created this
                    status=initial_status,
                    created_by=current_user.get('full_name', 'System')
                    # Note: transport_fee will be set by Production Manager during worker assignment
                )

                db.session.add(requisition)
                db.session.commit()

                log.info(f"Requisition created: {requisition_code} with {len(labour_items)} labour items, {total_workers} total workers by {current_user.get('full_name')}")
                break  # Success, exit retry loop

            except Exception as commit_error:
                db.session.rollback()

                # Check if it's a unique constraint violation on requisition_code
                if 'labour_requisitions_requisition_code_key' in str(commit_error):
                    if attempt < max_retries - 1:
                        log.warning(f"Requisition code collision on attempt {attempt + 1}, retrying...")
                        import time
                        time.sleep(0.1)  # Wait 100ms before retry
                        continue  # Retry with new code
                    else:
                        log.error(f"Failed to generate unique requisition code after {max_retries} attempts")
                        return jsonify({"error": "Failed to generate unique requisition code. Please try again."}), 500
                else:
                    # Different error, raise it
                    raise commit_error

        # TODO: Send notification to PM

        return jsonify({
            "success": True,
            "message": f"Requisition submitted successfully with {len(labour_items)} labour item(s)",
            "requisition": requisition.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        log.error(f"Error creating requisition: {str(e)}")
        return jsonify({"error": str(e)}), 500


def get_my_requisitions():
    """Get requisitions created by the current user
    Admin viewing as a role sees ALL requisitions created by users of that role"""
    try:
        current_user = g.user
        user_id = current_user.get('user_id')
        user_role = normalize_role(current_user.get('role', ''))

        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 15, type=int), 100)
        status = request.args.get('status')
        assignment_status = request.args.get('assignment_status')  # New parameter for filtering by assignment_status

        query = LabourRequisition.query.filter(
            LabourRequisition.is_deleted == False
        )

        # Admin sees ALL requisitions (for oversight when viewing as another role)
        if user_role in SUPER_ADMIN_ROLES:
            log.info(f"Admin {user_id} viewing all requisitions")
            # No user filtering - admin sees everything
        else:
            # Regular users only see their own requisitions
            query = query.filter(LabourRequisition.requested_by_user_id == user_id)

        if status:
            # Support comma-separated status values (e.g., 'pending,send_to_pm')
            if ',' in status:
                status_list = [s.strip() for s in status.split(',')]
                query = query.filter(LabourRequisition.status.in_(status_list))
            else:
                query = query.filter(LabourRequisition.status == status)

        if assignment_status:
            # Filter by assignment_status (e.g., 'assigned' or 'unassigned')
            query = query.filter(LabourRequisition.assignment_status == assignment_status)

        query = query.order_by(LabourRequisition.created_at.desc())
        paginated = query.paginate(page=page, per_page=per_page, error_out=False)

        # Fix N+1 query: Batch load workers for assigned and preferred worker IDs
        all_worker_ids = set()
        for req in paginated.items:
            if req.assigned_worker_ids:
                all_worker_ids.update(req.assigned_worker_ids)
            if req.preferred_worker_ids:
                all_worker_ids.update(req.preferred_worker_ids)

        workers_map = {}
        if all_worker_ids:
            workers = Worker.query.filter(
                Worker.worker_id.in_(list(all_worker_ids)),
                Worker.is_deleted == False
            ).all()
            workers_map = {w.worker_id: w for w in workers}

        # Add workers_map to each requisition's to_dict context
        requisitions_data = []
        for req in paginated.items:
            req_dict = req.to_dict()
            # Enrich with pre-loaded worker data to avoid N+1
            if req.assigned_worker_ids and workers_map:
                req_dict['assigned_workers'] = [
                    {'worker_id': wid, 'full_name': workers_map[wid].full_name, 'worker_code': workers_map[wid].worker_code}
                    for wid in req.assigned_worker_ids if wid in workers_map
                ]
            if req.preferred_worker_ids and workers_map:
                req_dict['preferred_workers'] = [
                    {'worker_id': wid, 'full_name': workers_map[wid].full_name, 'worker_code': workers_map[wid].worker_code}
                    for wid in req.preferred_worker_ids if wid in workers_map
                ]
            requisitions_data.append(req_dict)

        return jsonify({
            "success": True,
            "requisitions": requisitions_data,
            "pagination": {
                "page": page,
                "per_page": per_page,
                "total": paginated.total,
                "pages": paginated.pages
            }
        }), 200

    except Exception as e:
        log.error(f"Error getting my requisitions: {str(e)}")
        return jsonify({"error": str(e)}), 500


def get_requisitions_by_project(project_id):
    """Get all requisitions for a specific project (for status tracking on labour items)"""
    try:
        current_user = g.user

        # Validate project_id
        if not project_id or project_id <= 0:
            return jsonify({"error": "Invalid project_id"}), 400

        # Authorization: User must be assigned to this project or have admin/PM role
        # For now, we allow the requester to see requisitions they created OR
        # if they have PM/Admin/Production Manager roles
        user_id = current_user.get('user_id')
        user_role = current_user.get('role', '').lower()

        # Allow access for PM, Admin, Production Manager, or if user has requisitions for this project
        privileged_roles = ['pm', 'admin', 'production_manager', 'td', 'project_manager']
        is_privileged = user_role in privileged_roles

        if not is_privileged:
            # Check if user has created any requisitions for this project (Site Engineer use case)
            user_has_access = LabourRequisition.query.filter(
                LabourRequisition.project_id == project_id,
                LabourRequisition.requested_by_user_id == user_id,
                LabourRequisition.is_deleted == False
            ).first() is not None

            if not user_has_access:
                # Also check if user is assigned to this project (via some other mechanism)
                # For now, allow access if we can't verify - the SE needs to see status for items they may create
                pass

        requisitions = LabourRequisition.query.filter(
            LabourRequisition.project_id == project_id,
            LabourRequisition.is_deleted == False
        ).all()

        # Fix N+1 query: Batch load workers for all requisitions
        all_worker_ids = set()
        for req in requisitions:
            if req.assigned_worker_ids:
                all_worker_ids.update(req.assigned_worker_ids)
            if req.preferred_worker_ids:
                all_worker_ids.update(req.preferred_worker_ids)

        workers_map = {}
        if all_worker_ids:
            workers = Worker.query.filter(
                Worker.worker_id.in_(list(all_worker_ids)),
                Worker.is_deleted == False
            ).all()
            workers_map = {w.worker_id: w for w in workers}

        # Build a lookup map by labour_id for quick status checking
        labour_status_map = {}
        for req in requisitions:
            # Handle both old single labour_id and new labour_items array
            if req.labour_items and isinstance(req.labour_items, list):
                # Modern requisitions with multiple labour items
                for item in req.labour_items:
                    labour_id = item.get('labour_id')
                    if labour_id:
                        labour_status_map[str(labour_id)] = {
                            'requisition_id': req.requisition_id,
                            'requisition_code': req.requisition_code,
                            'status': req.status,
                            'work_status': req.work_status,
                            'assignment_status': req.assignment_status
                        }
            elif req.labour_id:
                # Legacy single labour item (backward compatibility)
                labour_status_map[req.labour_id] = {
                    'requisition_id': req.requisition_id,
                    'requisition_code': req.requisition_code,
                    'status': req.status,
                    'work_status': req.work_status,
                    'assignment_status': req.assignment_status
                }

        return jsonify({
            "success": True,
            "requisitions": [r.to_dict() for r in requisitions],
            "labour_status_map": labour_status_map
        }), 200

    except Exception as e:
        log.error(f"Error getting requisitions by project: {str(e)}")
        return jsonify({"error": str(e)}), 500


def get_requisition_by_id(requisition_id):
    """Get a single requisition by ID"""
    try:
        requisition = LabourRequisition.query.options(
            joinedload(LabourRequisition.project)
        ).filter_by(
            requisition_id=requisition_id,
            is_deleted=False
        ).first()

        if not requisition:
            return jsonify({"error": "Requisition not found"}), 404

        return jsonify({
            "success": True,
            "requisition": requisition.to_dict()
        }), 200

    except Exception as e:
        log.error(f"Error getting requisition: {str(e)}")
        return jsonify({"error": str(e)}), 500


def update_requisition(requisition_id):
    """Update a requisition (only if pending)"""
    try:
        current_user = g.user
        data = request.get_json()

        requisition = LabourRequisition.query.filter_by(
            requisition_id=requisition_id,
            is_deleted=False
        ).first()

        if not requisition:
            return jsonify({"error": "Requisition not found"}), 404

        if requisition.status != 'pending':
            return jsonify({"error": "Can only update pending requisitions"}), 400

        # Update fields
        if 'site_name' in data:
            requisition.site_name = data['site_name']
        if 'work_description' in data:
            requisition.work_description = data['work_description']
        if 'skill_required' in data:
            requisition.skill_required = data['skill_required']
        if 'workers_count' in data:
            requisition.workers_count = int(data['workers_count'])
        if 'required_date' in data:
            requisition.required_date = datetime.strptime(data['required_date'], '%Y-%m-%d').date()
        if 'start_time' in data:
            if data['start_time']:
                # Parse time string (HH:MM) to time object
                time_parts = data['start_time'].split(':')
                requisition.start_time = datetime.strptime(data['start_time'], '%H:%M').time()
            else:
                requisition.start_time = None
        if 'end_time' in data:
            if data['end_time']:
                requisition.end_time = datetime.strptime(data['end_time'], '%H:%M').time()
            else:
                requisition.end_time = None
        if 'preferred_workers_notes' in data:
            requisition.preferred_workers_notes = data['preferred_workers_notes']
        if 'preferred_worker_ids' in data:
            requisition.preferred_worker_ids = data['preferred_worker_ids']

        # Update labour items if provided
        if 'labour_items' in data and data['labour_items']:
            # Create a new list to ensure SQLAlchemy detects the change
            # This forces a copy of the data structure
            requisition.labour_items = [dict(item) for item in data['labour_items']]

            # Mark the labour_items JSON field as modified so SQLAlchemy detects the change
            from sqlalchemy.orm.attributes import flag_modified
            flag_modified(requisition, 'labour_items')

            # Force flush to ensure the change is written
            db.session.flush()

        # Validate time: end_time must be after start_time
        if requisition.start_time and requisition.end_time:
            start_minutes = requisition.start_time.hour * 60 + requisition.start_time.minute
            end_minutes = requisition.end_time.hour * 60 + requisition.end_time.minute
            if end_minutes <= start_minutes:
                return jsonify({"error": "End time must be after start time"}), 400

        requisition.last_modified_by = current_user.get('full_name', 'System')

        db.session.commit()

        return jsonify({
            "success": True,
            "message": "Requisition updated successfully",
            "requisition": requisition.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error updating requisition: {str(e)}")
        return jsonify({"error": str(e)}), 500


def resubmit_requisition(requisition_id):
    """Resubmit a rejected or pending requisition with optional edits (Site Engineer)"""
    try:
        current_user = g.user
        data = request.get_json()

        requisition = LabourRequisition.query.filter_by(
            requisition_id=requisition_id,
            is_deleted=False
        ).first()

        if not requisition:
            return jsonify({"error": "Requisition not found"}), 404

        # Allow resubmit for rejected or pending requisitions
        if requisition.status not in ['rejected', 'pending']:
            return jsonify({"error": "Can only resubmit rejected or pending requisitions"}), 400

        # Verify the requester is the original creator
        if requisition.requested_by_user_id != current_user.get('user_id'):
            user_role = current_user.get('role', '').lower()
            if user_role not in ['admin', 'pm', 'project_manager']:
                return jsonify({"error": "Only the original requester can resubmit"}), 403

        # Update site_name if provided
        if 'site_name' in data:
            if not data['site_name'] or not str(data['site_name']).strip():
                return jsonify({"error": "site_name cannot be empty"}), 400
            requisition.site_name = str(data['site_name']).strip()

        # Update required_date if provided
        if 'required_date' in data:
            new_date = datetime.strptime(data['required_date'], '%Y-%m-%d').date()
            if new_date < date.today():
                return jsonify({"error": "required_date cannot be in the past"}), 400
            requisition.required_date = new_date

        # Update start_time if provided
        if 'start_time' in data:
            if data['start_time']:
                try:
                    requisition.start_time = datetime.strptime(data['start_time'], '%H:%M').time()
                except ValueError:
                    return jsonify({"error": "Invalid time format for start_time. Use HH:MM"}), 400
            else:
                requisition.start_time = None

        # Update end_time if provided
        if 'end_time' in data:
            if data['end_time']:
                try:
                    requisition.end_time = datetime.strptime(data['end_time'], '%H:%M').time()
                except ValueError:
                    return jsonify({"error": "Invalid time format for end_time. Use HH:MM"}), 400
            else:
                requisition.end_time = None

        # Validate times: End time must be after start time
        if requisition.start_time and requisition.end_time:
            # Convert to minutes for comparison
            start_minutes = requisition.start_time.hour * 60 + requisition.start_time.minute
            end_minutes = requisition.end_time.hour * 60 + requisition.end_time.minute
            if end_minutes <= start_minutes:
                return jsonify({"error": "End time must be after start time"}), 400

        # Update preferred_workers_notes if provided
        # Update preferred_worker_ids if provided
        if 'preferred_worker_ids' in data:
            requisition.preferred_worker_ids = data.get('preferred_worker_ids', [])

        if 'preferred_workers_notes' in data:
            requisition.preferred_workers_notes = data.get('preferred_workers_notes')

        # Update labour_items if provided
        if 'labour_items' in data:
            labour_items = data.get('labour_items', [])

            # Validate labour_items array
            if not isinstance(labour_items, list) or len(labour_items) == 0:
                return jsonify({"error": "labour_items must be a non-empty array"}), 400

            # Validate each labour item
            for idx, item in enumerate(labour_items):
                if not item.get('work_description', '').strip():
                    return jsonify({"error": f"work_description is required for labour item {idx + 1}"}), 400
                if not item.get('skill_required', '').strip():
                    return jsonify({"error": f"skill_required is required for labour item {idx + 1}"}), 400
                if not item.get('workers_count') or int(item.get('workers_count', 0)) < 1:
                    return jsonify({"error": f"workers_count must be at least 1 for labour item {idx + 1}"}), 400

            # Update labour_items
            requisition.labour_items = labour_items

            # Update backward compatibility fields
            total_workers = sum(item.get('workers_count', 0) for item in labour_items)
            first_item = labour_items[0]

            if len(labour_items) == 1:
                requisition.work_description = first_item.get('work_description')
                requisition.skill_required = first_item.get('skill_required')
                requisition.workers_count = first_item.get('workers_count')
            else:
                requisition.work_description = f"Multiple Labour Items ({len(labour_items)} items)"
                requisition.skill_required = "Multiple Skills"
                requisition.workers_count = total_workers

        # Legacy fields support (if labour_items not provided)
        else:
            if 'work_description' in data:
                if not data['work_description'] or not str(data['work_description']).strip():
                    return jsonify({"error": "work_description cannot be empty"}), 400
                requisition.work_description = str(data['work_description']).strip()
            if 'skill_required' in data:
                if not data['skill_required'] or not str(data['skill_required']).strip():
                    return jsonify({"error": "skill_required cannot be empty"}), 400
                requisition.skill_required = str(data['skill_required']).strip()
            if 'workers_count' in data:
                count = int(data['workers_count'])
                if count < 1 or count > 500:
                    return jsonify({"error": "workers_count must be between 1 and 500"}), 400
                requisition.workers_count = count

        # Keep status unchanged - just update the data
        # User must manually click "Resend to PM" to send
        requisition.last_modified_by = current_user.get('full_name', 'System')

        db.session.commit()

        log.info(f"Requisition updated: {requisition.requisition_code} by {current_user.get('full_name')}")

        return jsonify({
            "success": True,
            "message": "Requisition updated successfully. Click 'Resend to PM' to send for approval.",
            "requisition": requisition.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error resubmitting requisition: {str(e)}")
        return jsonify({"error": str(e)}), 500


def send_to_production(requisition_id):
    """PM sends a requisition to production for worker assignment.
    Handles both PM-created drafts (status='pending') and SE-created requests (status='send_to_pm').
    """
    try:
        current_user = g.user
        user_role = normalize_role(current_user.get('role', ''))

        # Only PMs can send to production
        if user_role not in ['pm', 'projectmanager']:
            return jsonify({"error": "Only Project Managers can send requisitions to production"}), 403

        requisition = LabourRequisition.query.filter_by(
            requisition_id=requisition_id,
            is_deleted=False
        ).first()

        if not requisition:
            return jsonify({"error": "Requisition not found"}), 404

        # Accept both PM drafts ('pending') and SE requests sent to PM ('send_to_pm')
        allowed_statuses = ['pending', 'send_to_pm']
        if requisition.status not in allowed_statuses:
            return jsonify({"error": f"Can only send pending requisitions to production. Current status: {requisition.status}"}), 400

        # For PM-created requisitions, verify PM owns it
        if requisition.requester_role == 'PM' and requisition.requested_by_user_id != current_user.get('user_id'):
            return jsonify({"error": "You can only send your own requisitions to production"}), 403

        # Update status to 'approved' - ready for production manager to assign workers
        requisition.status = 'approved'
        requisition.approved_by_user_id = current_user.get('user_id')
        requisition.approved_by_name = current_user.get('full_name', 'Unknown')
        requisition.approval_date = datetime.utcnow()
        requisition.last_modified_by = current_user.get('full_name', 'System')

        # CRITICAL: Always set assignment_status to 'unassigned' when PM approves
        # This ensures the requisition appears in Production Manager's "Pending Assignment" queue
        requisition.assignment_status = 'unassigned'

        db.session.commit()

        log.info(f"Requisition sent to production: {requisition.requisition_code} (created by {requisition.requester_role}) approved by {current_user.get('full_name')}")

        # TODO: Send notification to production manager

        return jsonify({
            "success": True,
            "message": "Requisition sent to production for worker assignment",
            "requisition": requisition.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error sending requisition to production: {str(e)}")
        return jsonify({"error": str(e)}), 500


def delete_requisition(requisition_id):
    """Delete a requisition (soft delete) - Site Engineer can only delete pending requisitions"""
    try:
        current_user = g.user

        requisition = LabourRequisition.query.filter_by(
            requisition_id=requisition_id,
            is_deleted=False
        ).first()

        if not requisition:
            return jsonify({"error": "Requisition not found"}), 404

        # Only allow deletion of pending requisitions
        if requisition.status != 'pending':
            return jsonify({"error": "Can only delete pending requisitions"}), 400

        # Verify the requester is the original creator
        if requisition.requested_by_user_id != current_user.get('user_id'):
            user_role = current_user.get('role', '').lower()
            if user_role not in ['admin', 'pm', 'project_manager']:
                return jsonify({"error": "Only the original requester can delete"}), 403

        # Check if workers have been assigned
        if requisition.assignment_status == 'assigned':
            return jsonify({"error": "Cannot delete requisition with assigned workers"}), 400

        # Soft delete
        requisition.is_deleted = True
        requisition.last_modified_by = current_user.get('full_name', 'System')

        db.session.commit()

        log.info(f"Requisition deleted: {requisition.requisition_code} by {current_user.get('full_name')}")

        return jsonify({
            "success": True,
            "message": "Requisition deleted successfully"
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error deleting requisition: {str(e)}")
        return jsonify({"error": str(e)}), 500


def resend_requisition(requisition_id):
    """Resend/notify PM about a pending or rejected requisition"""
    try:
        current_user = g.user

        requisition = LabourRequisition.query.filter_by(
            requisition_id=requisition_id,
            is_deleted=False
        ).first()

        if not requisition:
            return jsonify({"error": "Requisition not found"}), 404

        # Only allow resending pending or rejected requisitions
        if requisition.status not in ['pending', 'rejected']:
            return jsonify({"error": "Can only send pending or rejected requisitions"}), 400

        # Verify the requester is the original creator
        if requisition.requested_by_user_id != current_user.get('user_id'):
            user_role = current_user.get('role', '').lower()
            if user_role not in ['admin', 'pm', 'project_manager']:
                return jsonify({"error": "Only the original requester can resend"}), 403

        # Update request date to show it was resent
        requisition.request_date = datetime.utcnow()
        requisition.last_modified_by = current_user.get('full_name', 'System')

        # Change status to send_to_pm to indicate it's been sent to PM
        requisition.status = 'send_to_pm'

        # Clear rejection reason if it was previously rejected
        if requisition.rejection_reason:
            requisition.rejection_reason = None
            requisition.approved_by_user_id = None
            requisition.approved_by_name = None
            requisition.approval_date = None

        db.session.commit()

        # TODO: Send notification to PM

        log.info(f"Requisition resent: {requisition.requisition_code} by {current_user.get('full_name')}")

        return jsonify({
            "success": True,
            "message": "Requisition resent to Project Manager"
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error resending requisition: {str(e)}")
        return jsonify({"error": str(e)}), 500


# =============================================================================
# STEP 3: APPROVE REQUISITIONS (Project Manager)
# =============================================================================

def get_pending_requisitions():
    """
    Get requisitions for PM with optional status filter, filtered by user's assigned projects.

    Status Flow:
    1. SE creates requisition -> status: 'pending' (draft on SE side)
    2. SE sends to PM -> status: 'send_to_pm' (visible in PM's "SE Pending" tab)
    3. PM approves -> status: 'approved'
    4. PM rejects -> status: 'rejected'
    5. PM creates requisition -> status: 'pending' (draft in PM's "My Pending" tab)
    6. PM manually sends to Production Manager -> status changes appropriately

    Query Parameters:
    - status: 'pending' (for send_to_pm), 'approved', 'rejected'
    - project_id: Filter by specific project
    - page: Page number for pagination
    - per_page: Items per page (max 100)
    """
    try:
        current_user = g.user
        user_id = current_user.get('user_id')
        user_role = normalize_role(current_user.get('role', ''))

        # Validate user_id
        if not user_id:
            return jsonify({"error": "User ID not found in session"}), 401

        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 15, type=int), 100)
        project_id = request.args.get('project_id', type=int)
        status = request.args.get('status', 'pending')  # Default to pending
        view_as_role = request.args.get('view_as_role', '').lower()  # For admin viewing as other roles

        # Track if original user is admin (for viewing as other roles)
        is_admin_viewing_as_role = user_role in SUPER_ADMIN_ROLES and view_as_role

        # If admin is viewing as another role, use that role for filtering
        if is_admin_viewing_as_role:
            user_role = view_as_role

        # Query labour requisitions
        query = LabourRequisition.query.options(
            joinedload(LabourRequisition.project)
        ).filter(
            LabourRequisition.is_deleted == False
        )

        # Filter by status
        # For 'pending' tab on PM side, only show requisitions that have been sent to PM (send_to_pm status)
        # This excludes draft requisitions that are still 'pending' on SE side
        if status == 'pending':
            query = query.filter(LabourRequisition.status == 'send_to_pm')
        elif status in ['approved', 'rejected']:
            query = query.filter(LabourRequisition.status == status)

        if project_id:
            query = query.filter(LabourRequisition.project_id == project_id)

        # Role-based filtering - different logic for pending vs approved/rejected tabs
        # Admin viewing as role sees ALL data for that role (no user-specific filtering)
        if is_admin_viewing_as_role:
            log.info(f"Admin viewing as {view_as_role} - skipping user-specific filtering")
            # No additional filtering - admin sees all data for the role
        elif user_role not in SUPER_ADMIN_ROLES:
            if user_role == 'pm' or user_role == 'projectmanager':
                # For PENDING tab: filter by project_id (PM's assigned projects)
                # For APPROVED/REJECTED tabs: filter by approved_by_user_id
                if status == 'pending':
                    # Get all projects and find which ones this PM is assigned to
                    from models.project import Project
                    all_projects = Project.query.filter(
                        Project.is_deleted == False,
                        Project.user_id.isnot(None)
                    ).all()

                    assigned_project_ids = []
                    for proj in all_projects:
                        if proj.user_id and isinstance(proj.user_id, list) and user_id in proj.user_id:
                            assigned_project_ids.append(proj.project_id)

                    if assigned_project_ids:
                        query = query.filter(LabourRequisition.project_id.in_(assigned_project_ids))
                    else:
                        return jsonify({
                            "success": True,
                            "requisitions": [],
                            "pagination": {
                                "page": page,
                                "per_page": per_page,
                                "total": 0,
                                "pages": 0
                            }
                        }), 200
                else:
                    # For approved/rejected tabs: filter by approved_by_user_id
                    query = query.filter(LabourRequisition.approved_by_user_id == user_id)

            elif user_role in ['mep', 'mepsupervisor', 'mep_supervisor']:
                # MEP Supervisor: filter by projects where mep_supervisor_id contains this user
                # For PENDING tab: filter by MEP's assigned projects
                # For APPROVED/REJECTED tabs: filter by approved_by_user_id
                if status == 'pending':

                    from models.project import Project
                    all_projects = Project.query.filter(
                        Project.is_deleted == False,
                        Project.mep_supervisor_id.isnot(None)
                    ).all()

                    assigned_project_ids = []
                    for proj in all_projects:
                        if proj.mep_supervisor_id and isinstance(proj.mep_supervisor_id, list) and user_id in proj.mep_supervisor_id:
                            assigned_project_ids.append(proj.project_id)

                    if assigned_project_ids:
                        query = query.filter(LabourRequisition.project_id.in_(assigned_project_ids))
                    else:
                        return jsonify({
                            "success": True,
                            "requisitions": [],
                            "pagination": {
                                "page": page,
                                "per_page": per_page,
                                "total": 0,
                                "pages": 0
                            }
                        }), 200
                else:
                    # For approved/rejected tabs: filter by approved_by_user_id
                    query = query.filter(LabourRequisition.approved_by_user_id == user_id)

            else:
                # For other roles (SE, etc), use project assignment filtering
                assigned_project_ids = get_user_assigned_project_ids(user_id)
                if assigned_project_ids:
                    query = query.filter(LabourRequisition.project_id.in_(assigned_project_ids))
                else:
                    return jsonify({
                        "success": True,
                        "requisitions": [],
                        "pagination": {
                            "page": page,
                            "per_page": per_page,
                            "total": 0,
                            "pages": 0
                        }
                    }), 200

        query = query.order_by(LabourRequisition.required_date.desc())
        paginated = query.paginate(page=page, per_page=per_page, error_out=False)

        return jsonify({
            "success": True,
            "requisitions": [r.to_dict() for r in paginated.items],
            "pagination": {
                "page": page,
                "per_page": per_page,
                "total": paginated.total,
                "pages": paginated.pages
            }
        }), 200

    except Exception as e:
        log.error(f"Error getting requisitions: {str(e)}")
        return jsonify({"error": str(e)}), 500


def approve_requisition(requisition_id):
    """
    PM approves a requisition.

    Only requisitions with status='send_to_pm' can be approved.
    This ensures SE has explicitly sent the requisition for PM approval.
    """
    try:
        current_user = g.user

        requisition = LabourRequisition.query.filter_by(
            requisition_id=requisition_id,
            is_deleted=False
        ).first()

        if not requisition:
            return jsonify({"error": "Requisition not found"}), 404

        # Only approve requisitions that have been sent to PM
        if requisition.status != 'send_to_pm':
            error_msg = "Requisition cannot be approved"
            if requisition.status == 'pending':
                error_msg = "This requisition is still in draft state and hasn't been sent to PM for approval"
            elif requisition.status == 'approved':
                error_msg = "This requisition has already been approved"
            elif requisition.status == 'rejected':
                error_msg = "This requisition has already been rejected"

            return jsonify({"error": error_msg}), 400

        requisition.status = 'approved'
        requisition.approved_by_user_id = current_user.get('user_id')
        requisition.approved_by_name = current_user.get('full_name', 'Unknown')
        requisition.approval_date = datetime.utcnow()
        requisition.last_modified_by = current_user.get('full_name', 'System')

        # CRITICAL: Always set assignment_status to 'unassigned' when PM approves
        # This ensures the requisition appears in Production Manager's "Pending Assignment" queue
        # regardless of what status it had before (fixes old 'pending' status from legacy code)
        requisition.assignment_status = 'unassigned'

        db.session.commit()
        return jsonify({
            "success": True,
            "message": "Requisition approved successfully and sent to Production Manager for worker assignment",
            "requisition": requisition.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error approving requisition: {str(e)}")
        return jsonify({"error": str(e)}), 500


def reject_requisition(requisition_id):
    """
    PM rejects a requisition.

    Only requisitions with status='send_to_pm' can be rejected.
    This ensures SE has explicitly sent the requisition for PM review.
    """
    try:
        current_user = g.user
        data = request.get_json()

        reason = data.get('reason', '')
        if not reason:
            return jsonify({"error": "Rejection reason is required"}), 400

        requisition = LabourRequisition.query.filter_by(
            requisition_id=requisition_id,
            is_deleted=False
        ).first()

        if not requisition:
            return jsonify({"error": "Requisition not found"}), 404

        # Only reject requisitions that have been sent to PM
        if requisition.status != 'send_to_pm':
            error_msg = "Requisition cannot be rejected"
            if requisition.status == 'pending':
                error_msg = "This requisition is still in draft state and hasn't been sent to PM for review"
            elif requisition.status == 'approved':
                error_msg = "This requisition has already been approved"
            elif requisition.status == 'rejected':
                error_msg = "This requisition has already been rejected"

            return jsonify({"error": error_msg}), 400

        requisition.status = 'rejected'
        requisition.approved_by_user_id = current_user.get('user_id')
        requisition.approved_by_name = current_user.get('full_name', 'Unknown')
        requisition.approval_date = datetime.utcnow()
        requisition.rejection_reason = reason
        requisition.last_modified_by = current_user.get('full_name', 'System')

        db.session.commit()
        return jsonify({
            "success": True,
            "message": "Requisition rejected",
            "requisition": requisition.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error rejecting requisition: {str(e)}")
        return jsonify({"error": str(e)}), 500


# =============================================================================
# STEP 4: ASSIGN PERSONNEL (Production Manager)
# =============================================================================

def get_approved_requisitions():
    """Get approved requisitions with optional assignment status filter, filtered by user's assigned projects"""
    try:
        current_user = g.user
        user_id = current_user.get('user_id')
        user_role = normalize_role(current_user.get('role', ''))

        # Validate user_id
        if not user_id:
            return jsonify({"error": "User ID not found in session"}), 401

        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 20, type=int), 100)
        assignment_status = request.args.get('assignment_status')  # 'unassigned' or 'assigned'

        query = LabourRequisition.query.options(
            joinedload(LabourRequisition.project)
        ).filter(
            LabourRequisition.status == 'approved',
            LabourRequisition.is_deleted == False
        )

        # Filter by assignment status if provided
        if assignment_status in ['unassigned', 'assigned']:
            query = query.filter(LabourRequisition.assignment_status == assignment_status)

        # Role-based project filtering
        # Admin, TD, and Production Manager can see all approved requisitions
        if user_role not in LABOUR_ADMIN_ROLES:
            assigned_project_ids = get_user_assigned_project_ids(user_id)

            if assigned_project_ids:
                query = query.filter(LabourRequisition.project_id.in_(assigned_project_ids))
            else:
                # User has no assigned projects, return empty result
                return jsonify({
                    "success": True,
                    "requisitions": [],
                    "pagination": {
                        "page": page,
                        "per_page": per_page,
                        "total": 0,
                        "pages": 0
                    }
                }), 200

        query = query.order_by(LabourRequisition.required_date.desc())
        paginated = query.paginate(page=page, per_page=per_page, error_out=False)

        return jsonify({
            "success": True,
            "requisitions": [r.to_dict() for r in paginated.items],
            "pagination": {
                "page": page,
                "per_page": per_page,
                "total": paginated.total,
                "pages": paginated.pages
            }
        }), 200

    except Exception as e:
        log.error(f"Error getting approved requisitions: {str(e)}")
        return jsonify({"error": str(e)}), 500


def get_available_workers():
    """Get workers available for assignment on a specific date"""
    try:
        skill = request.args.get('skill')
        date_str = request.args.get('date', date.today().isoformat())
        target_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        requisition_id = request.args.get('requisition_id', type=int)

        # Get requisition to check time range if provided
        target_requisition = None
        if requisition_id:
            target_requisition = LabourRequisition.query.get(requisition_id)

        # Get all active workers
        query = Worker.query.filter(
            Worker.is_deleted == False,
            Worker.status == 'active'
        )

        all_workers = query.all()

        # Filter by skill using flexible matching
        workers = []
        if skill:
            for worker in all_workers:
                if skill_matches(skill, worker.skills or []):
                    workers.append(worker)
        else:
            workers = all_workers

        # Check which workers have active assignments on the target date
        # We need to check both WorkerAssignment AND LabourArrival tables
        # to determine if worker is truly unavailable

        today = datetime.utcnow().date()
        assigned_workers = {}

        # Only check for assignments on today or past dates
        # Future dates don't need conflict checking
        if target_date <= today:
            # Find requisitions assigned for the target date
            requisitions_on_date = db.session.query(LabourRequisition).filter(
                LabourRequisition.required_date == target_date,
                LabourRequisition.is_deleted == False,
                LabourRequisition.assignment_status == 'assigned'
            ).all()

            for req in requisitions_on_date:
                if req.assigned_worker_ids:
                    for worker_id in req.assigned_worker_ids:
                        # Check if worker has departed from this assignment
                        arrival = LabourArrival.query.filter_by(
                            requisition_id=req.requisition_id,
                            worker_id=worker_id,
                            arrival_date=target_date,
                            is_deleted=False
                        ).first()

                        # If target requisition has time range, check for time overlap
                        is_unavailable = False
                        if target_requisition and target_requisition.start_time and target_requisition.end_time and req.start_time and req.end_time:
                            # Check time overlap: new_start < existing_end AND new_end > existing_start
                            if (target_requisition.start_time < req.end_time and
                                target_requisition.end_time > req.start_time):
                                is_unavailable = True
                        else:
                            # No time info available, use departure status
                            # Worker is unavailable if:
                            # 1. No arrival record exists yet (assigned but not processed)
                            # 2. Arrival exists but status is not 'departed'
                            if not arrival or (arrival and arrival.arrival_status != 'departed'):
                                is_unavailable = True

                        if is_unavailable:
                            # Worker is currently assigned and hasn't departed (or has time conflict)
                            assigned_workers[worker_id] = {
                                'requisition_code': req.requisition_code,
                                'status': arrival.arrival_status if arrival else 'assigned'
                            }

        # Build response with ALL workers, marking assignment status
        workers_response = []
        available_count = 0

        for worker in workers:
            worker_dict = worker.to_dict_minimal()
            is_assigned = worker.worker_id in assigned_workers

            if is_assigned:
                worker_dict['is_assigned'] = True
                worker_dict['assignment'] = assigned_workers[worker.worker_id]
            else:
                worker_dict['is_assigned'] = False
                available_count += 1

            workers_response.append(worker_dict)

        return jsonify({
            "success": True,
            "workers": workers_response,
            "total_available": available_count,
            "total_matching": len(workers_response)
        }), 200

    except Exception as e:
        log.error(f"Error getting available workers: {str(e)}")
        return jsonify({"error": str(e)}), 500


def assign_workers_to_requisition(requisition_id):
    """Production Manager assigns workers to an approved requisition"""
    try:
        current_user = g.user
        data = request.get_json()

        worker_ids = data.get('worker_ids', [])
        if not worker_ids:
            return jsonify({"error": "worker_ids is required"}), 400

        requisition = LabourRequisition.query.filter_by(
            requisition_id=requisition_id,
            is_deleted=False
        ).first()

        if not requisition:
            return jsonify({"error": "Requisition not found"}), 404

        if requisition.status != 'approved':
            return jsonify({"error": "Requisition is not approved"}), 400

        if requisition.assignment_status == 'assigned':
            return jsonify({"error": "Requisition already has assigned workers"}), 400

        # Verify all workers exist and are active
        workers = Worker.query.filter(
            Worker.worker_id.in_(worker_ids),
            Worker.is_deleted == False,
            Worker.status == 'active'
        ).all()

        if len(workers) != len(worker_ids):
            return jsonify({"error": "Some workers are invalid or inactive"}), 400

        # CRITICAL: Verify no workers are already assigned on the target date (server-side validation)
        target_date = requisition.required_date
        today = datetime.utcnow().date()

        # Only check for conflicts if assignment is for today
        # Future dates are allowed without restriction
        if target_date <= today:
            # Check for existing assignments on the target date
            conflicting_workers = []

            for worker_id in worker_ids:
                # Find all requisitions this worker is assigned to on the target date
                existing_requisitions = db.session.query(LabourRequisition).filter(
                    LabourRequisition.assigned_worker_ids.contains([worker_id]),
                    LabourRequisition.required_date == target_date,
                    LabourRequisition.is_deleted == False,
                    LabourRequisition.assignment_status == 'assigned',
                    LabourRequisition.requisition_id != requisition_id  # Exclude current requisition
                ).all()

                if existing_requisitions:
                    # For each existing assignment, check if worker has departed
                    has_active_assignment = False

                    for existing_req in existing_requisitions:
                        # Check arrival record to see if worker has departed
                        arrival = LabourArrival.query.filter_by(
                            requisition_id=existing_req.requisition_id,
                            worker_id=worker_id,
                            arrival_date=target_date,
                            is_deleted=False
                        ).first()

                        # Check if times overlap when both requisitions have start/end times
                        if requisition.start_time and requisition.end_time and existing_req.start_time and existing_req.end_time:
                            # Time overlap exists if: new_start < existing_end AND new_end > existing_start
                            # Example: 11AM-6PM vs 6PM-10PM -> 6PM < 6PM (FALSE) -> NO OVERLAP ✓
                            # Example: 11AM-6PM vs 5PM-10PM -> 5PM < 6PM (TRUE) AND 10PM > 11AM (TRUE) -> OVERLAP ✗
                            if (requisition.start_time < existing_req.end_time and
                                requisition.end_time > existing_req.start_time):
                                has_active_assignment = True
                                break
                            # No time overlap, worker is available for non-overlapping shift
                        else:
                            # If times not specified, check departure status
                            if arrival and arrival.arrival_status != 'departed':
                                # No departure recorded and no time info, assume full day conflict
                                has_active_assignment = True
                                break

                    if has_active_assignment:
                        worker = next((w for w in workers if w.worker_id == worker_id), None)
                        if worker:
                            # Get the conflicting requisition code for better error message
                            conflict_req_code = existing_req.requisition_code if existing_req else 'unknown'
                            conflicting_workers.append(f"{worker.full_name} (currently on {conflict_req_code})")

            if conflicting_workers:
                worker_details = '\n• '.join(conflicting_workers)
                return jsonify({
                    "error": f"Cannot assign workers - they are already working on another requisition:\n\n• {worker_details}\n\nThey must clock out first before being assigned to a new requisition."
                }), 400

        # Create worker assignments
        for worker in workers:
            assignment = WorkerAssignment(
                worker_id=worker.worker_id,
                project_id=requisition.project_id,
                requisition_id=requisition.requisition_id,
                assigned_by_user_id=current_user.get('user_id'),
                assignment_type='regular',
                assignment_start_date=requisition.required_date,
                hourly_rate_override=None,
                role_at_site=requisition.skill_required,
                status='active',
                created_by=current_user.get('full_name', 'System')
            )
            db.session.add(assignment)

            # Create arrival record only if it doesn't already exist
            existing_arrival = LabourArrival.query.filter_by(
                requisition_id=requisition.requisition_id,
                worker_id=worker.worker_id,
                arrival_date=requisition.required_date
            ).first()

            if not existing_arrival:
                arrival = LabourArrival(
                    requisition_id=requisition.requisition_id,
                    worker_id=worker.worker_id,
                    project_id=requisition.project_id,
                    arrival_date=requisition.required_date,
                    arrival_status='assigned',
                    created_by=current_user.get('full_name', 'System')
                )
                db.session.add(arrival)
            else:
                log.info(f"Arrival record already exists for worker {worker.worker_id} on {requisition.required_date}, skipping creation")

        # Update requisition
        requisition.assignment_status = 'assigned'
        requisition.work_status = 'assigned'  # Update work status when workers are assigned
        requisition.assigned_worker_ids = worker_ids
        requisition.assigned_by_user_id = current_user.get('user_id')
        requisition.assigned_by_name = current_user.get('full_name', 'Unknown')
        requisition.assignment_date = datetime.utcnow()
        requisition.last_modified_by = current_user.get('full_name', 'System')

        # Update transport fee (PM sets transport cost during worker assignment)
        transport_fee = data.get('transport_fee', 0)
        if transport_fee is not None:
            requisition.transport_fee = float(transport_fee)

        # Update transport logistics details (driver and vehicle information)
        driver_name = data.get('driver_name')
        if driver_name:
            requisition.driver_name = driver_name

        vehicle_number = data.get('vehicle_number')
        if vehicle_number:
            requisition.vehicle_number = vehicle_number

        driver_contact = data.get('driver_contact')
        if driver_contact:
            requisition.driver_contact = driver_contact

        db.session.commit()

        # Send WhatsApp notification to workers
        whatsapp_results = []
        notification_sent_count = 0

        # Get project name for the message
        project_name = requisition.project.project_name if requisition.project else f"Project #{requisition.project_id}"
        formatted_date = requisition.required_date.strftime('%d %b %Y') if requisition.required_date else 'N/A'

        # Format time shift details
        time_shift = "Not specified"
        if requisition.start_time and requisition.end_time:
            time_shift = f"{requisition.start_time.strftime('%I:%M %p')} - {requisition.end_time.strftime('%I:%M %p')}"
        elif requisition.start_time:
            time_shift = f"From {requisition.start_time.strftime('%I:%M %p')}"
        elif requisition.end_time:
            time_shift = f"Until {requisition.end_time.strftime('%I:%M %p')}"

        for worker in workers:
            if worker.phone:
                # Create assignment notification message
                message = f"""🔔 *Work Assignment Notification*

Hello *{worker.full_name}*,

You have been assigned to a new work order:

📋 *Assignment Details:*
• Requisition: {requisition.requisition_code}
• Project: {project_name}
• Location: {requisition.site_name}
• Work: {requisition.work_description}
• Role: {requisition.skill_required}
• Date: {formatted_date}
• Time: {time_shift}

Please report to the site on time. Contact your supervisor for any queries.

_MeterSquare Interiors LLC_"""

                # Mask phone number for response (PII protection)
                masked_phone = f"{worker.phone[:4]}****{worker.phone[-4:]}" if len(worker.phone) > 8 else "****"

                try:
                    result = whatsapp_service.send_message(worker.phone, message)
                    if result.get('success'):
                        notification_sent_count += 1
                    else:
                        log.warning(f"WhatsApp failed for worker {worker.worker_code}: {result.get('message')}")
                    whatsapp_results.append({
                        'worker_id': worker.worker_id,
                        'worker_code': worker.worker_code,
                        'phone': masked_phone,
                        'success': result.get('success')
                    })
                except Exception as wa_error:
                    log.error(f"WhatsApp error for worker {worker.worker_code}: {str(wa_error)}")
                    whatsapp_results.append({
                        'worker_id': worker.worker_id,
                        'worker_code': worker.worker_code,
                        'phone': masked_phone,
                        'success': False
                    })
            else:
                whatsapp_results.append({
                    'worker_id': worker.worker_id,
                    'worker_code': worker.worker_code,
                    'phone': None,
                    'success': False
                })

        # Update whatsapp_notified flag if at least one notification was sent
        if notification_sent_count > 0:
            requisition.whatsapp_notified = True
            db.session.commit()

        return jsonify({
            "success": True,
            "message": f"{len(workers)} workers assigned successfully. WhatsApp sent to {notification_sent_count} workers.",
            "requisition": requisition.to_dict(),
            "whatsapp_notifications": whatsapp_results
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error assigning workers: {str(e)}")
        return jsonify({"error": str(e)}), 500


def retain_workers_for_next_day(requisition_id):
    """
    Reassign/duplicate a requisition with same workers for a new date.
    Validates worker availability and time conflicts before creating new requisition.
    Creates requisition with status 'send_to_pm' for PM approval (not auto-approved).
    """
    try:
        # g.user is a dictionary, not a User object
        current_user = g.user
        user_id = current_user['user_id']
        user_name = current_user.get('full_name', current_user.get('email', 'Unknown'))

        # Normalize role to 'SE' or 'PM' (max 10 chars for DB column)
        raw_role = current_user.get('role', 'SE')
        if 'pm' in raw_role.lower() or 'project' in raw_role.lower():
            user_role = 'PM'
        else:
            user_role = 'SE'

        data = request.get_json()

        # Validate required fields
        required_date = data.get('required_date')
        start_time_str = data.get('start_time')
        end_time_str = data.get('end_time')

        if not required_date:
            return jsonify({"error": "Required date is mandatory"}), 400

        # Get original requisition
        original_req = LabourRequisition.query.get(requisition_id)
        if not original_req:
            return jsonify({"error": "Original requisition not found"}), 404

        # Check if original requisition has assigned workers
        if not original_req.assigned_worker_ids or len(original_req.assigned_worker_ids) == 0:
            return jsonify({"error": "Original requisition has no assigned workers"}), 400

        # Parse date and times
        target_date = datetime.strptime(required_date, '%Y-%m-%d').date()
        start_time = datetime.strptime(start_time_str, '%H:%M').time() if start_time_str else None
        end_time = datetime.strptime(end_time_str, '%H:%M').time() if end_time_str else None

        # Validate times (allow overnight shifts where end_time < start_time, e.g., 22:00 to 06:00)
        # Only reject if times are exactly the same
        if start_time and end_time and start_time == end_time:
            return jsonify({"error": "End time must be different from start time"}), 400

        # Check worker availability and conflicts
        today = datetime.utcnow().date()
        unavailable_workers = []
        available_workers = []

        if target_date <= today and start_time and end_time:
            # Only check conflicts for today/past dates with time specified
            for worker_id in original_req.assigned_worker_ids:
                # Find existing assignments on target date
                existing_reqs = db.session.query(LabourRequisition).filter(
                    LabourRequisition.assigned_worker_ids.contains([worker_id]),
                    LabourRequisition.required_date == target_date,
                    LabourRequisition.is_deleted == False,
                    LabourRequisition.assignment_status == 'assigned'
                ).all()

                has_conflict = False
                conflict_details = None

                for existing_req in existing_reqs:
                    if existing_req.start_time and existing_req.end_time:
                        # Check time overlap (handle overnight shifts)
                        # Overnight shift: start_time > end_time (e.g., 22:00 to 06:00)
                        new_is_overnight = start_time > end_time
                        existing_is_overnight = existing_req.start_time > existing_req.end_time

                        # Check for overlap based on shift types
                        has_overlap = False
                        if new_is_overnight and existing_is_overnight:
                            # Both overnight: always overlap
                            has_overlap = True
                        elif new_is_overnight:
                            # New shift is overnight: overlaps if existing starts before new ends or ends after new starts
                            has_overlap = (existing_req.start_time <= end_time or existing_req.end_time >= start_time)
                        elif existing_is_overnight:
                            # Existing shift is overnight: overlaps if new starts before existing ends or ends after existing starts
                            has_overlap = (start_time <= existing_req.end_time or end_time >= existing_req.start_time)
                        else:
                            # Both same-day shifts: standard overlap check
                            has_overlap = (start_time < existing_req.end_time and end_time > existing_req.start_time)

                        if has_overlap:
                            has_conflict = True
                            conflict_details = {
                                'requisition_code': existing_req.requisition_code,
                                'time_range': f"{existing_req.start_time.strftime('%H:%M')} - {existing_req.end_time.strftime('%H:%M')}"
                            }
                            break

                worker = Worker.query.get(worker_id)
                if has_conflict:
                    unavailable_workers.append({
                        'worker_id': worker_id,
                        'worker_name': worker.full_name if worker else 'Unknown',
                        'worker_code': worker.worker_code if worker else 'N/A',
                        'conflict': conflict_details
                    })
                else:
                    available_workers.append(worker_id)
        else:
            # Future date or no time specified - all workers available
            available_workers = original_req.assigned_worker_ids.copy()

        # If check_only flag is set, return availability without creating
        if data.get('check_only'):
            return jsonify({
                "success": True,
                "check_only": True,
                "available_workers": available_workers,
                "unavailable_workers": unavailable_workers,
                "total_workers": len(original_req.assigned_worker_ids),
                "available_count": len(available_workers),
                "conflict_count": len(unavailable_workers)
            }), 200

        # Create new requisition with available workers only
        if len(available_workers) == 0:
            return jsonify({"error": "No workers available for the selected date and time. All have conflicts."}), 400

        # Generate new requisition code
        new_req_code = LabourRequisition.generate_requisition_code()

        # Build preferred workers notes with available workers
        worker_names = []
        for worker_id in available_workers:
            worker = Worker.query.get(worker_id)
            if worker:
                worker_names.append(f"{worker.full_name} ({worker.worker_code})")

        preferred_notes = f"Reassigning from {original_req.requisition_code}: " + ", ".join(worker_names)

        # Create new requisition - send to PM for approval
        new_requisition = LabourRequisition(
            requisition_code=new_req_code,
            project_id=original_req.project_id,
            site_name=original_req.site_name,
            required_date=target_date,
            start_time=start_time,
            end_time=end_time,
            labour_items=original_req.labour_items,  # Copy labour items
            work_description=original_req.work_description,
            skill_required=original_req.skill_required,
            workers_count=len(available_workers),  # Update count
            boq_id=original_req.boq_id,
            item_id=original_req.item_id,
            labour_id=original_req.labour_id,
            requested_by_user_id=user_id,
            requested_by_name=user_name,
            requester_role=user_role,
            status='send_to_pm',  # Send to PM for approval (not auto-approved)
            assignment_status='unassigned',  # Not yet assigned (use 'unassigned' not 'pending')
            preferred_worker_ids=available_workers,  # Store as preferred workers
            preferred_workers_notes=preferred_notes,
            created_by=user_name
        )

        db.session.add(new_requisition)
        db.session.flush()  # Get requisition_id

        # No labour arrivals created yet - PM will assign workers after approval

        db.session.commit()

        return jsonify({
            "success": True,
            "message": f"Reassignment requisition created with {len(available_workers)} preferred worker(s). Sent to PM for approval.",
            "new_requisition": new_requisition.to_dict(),
            "unavailable_workers": unavailable_workers,
            "preferred_workers_count": len(available_workers),
            "conflict_count": len(unavailable_workers)
        }), 201

    except Exception as e:
        db.session.rollback()
        log.error(f"Error reassigning workers: {str(e)}")
        return jsonify({"error": str(e)}), 500


# =============================================================================
# STEP 5: ARRIVAL CONFIRMATION (Site Engineer)
# =============================================================================

def get_arrivals_for_date(project_id, date_str):
    """Get assigned workers for arrival confirmation"""
    try:
        target_date = datetime.strptime(date_str, '%Y-%m-%d').date()

        arrivals = LabourArrival.query.options(
            joinedload(LabourArrival.worker)
        ).filter(
            LabourArrival.project_id == project_id,
            LabourArrival.arrival_date == target_date,
            LabourArrival.is_deleted == False
        ).all()

        return jsonify({
            "success": True,
            "arrivals": [a.to_dict_with_worker() for a in arrivals],
            "date": date_str
        }), 200

    except Exception as e:
        log.error(f"Error getting arrivals: {str(e)}")
        return jsonify({"error": str(e)}), 500


def confirm_arrival():
    """Site Engineer confirms worker arrival"""
    try:
        current_user = g.user
        data = request.get_json()

        arrival_id = data.get('arrival_id')
        arrival_time = data.get('arrival_time')  # HH:MM format

        if not arrival_id:
            return jsonify({"error": "arrival_id is required"}), 400

        arrival = LabourArrival.query.filter_by(
            arrival_id=arrival_id,
            is_deleted=False
        ).first()

        if not arrival:
            return jsonify({"error": "Arrival record not found"}), 404

        if arrival.arrival_status == 'confirmed':
            return jsonify({"error": "Arrival already confirmed"}), 400

        arrival.arrival_status = 'confirmed'
        arrival.arrival_time = arrival_time or datetime.now().strftime('%H:%M')
        arrival.confirmed_at = datetime.utcnow()
        arrival.confirmed_by_user_id = current_user.get('user_id')

        db.session.commit()

        return jsonify({
            "success": True,
            "message": "Arrival confirmed",
            "arrival": arrival.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error confirming arrival: {str(e)}")
        return jsonify({"error": str(e)}), 500


def mark_no_show():
    """Site Engineer marks worker as no-show"""
    try:
        current_user = g.user
        data = request.get_json()

        arrival_id = data.get('arrival_id')

        if not arrival_id:
            return jsonify({"error": "arrival_id is required"}), 400

        arrival = LabourArrival.query.filter_by(
            arrival_id=arrival_id,
            is_deleted=False
        ).first()

        if not arrival:
            return jsonify({"error": "Arrival record not found"}), 404

        arrival.arrival_status = 'no_show'
        arrival.confirmed_at = datetime.utcnow()
        arrival.confirmed_by_user_id = current_user.get('user_id')

        db.session.commit()
        return jsonify({
            "success": True,
            "message": "Worker marked as no-show",
            "arrival": arrival.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error marking no-show: {str(e)}")
        return jsonify({"error": str(e)}), 500


def mark_departure():
    """Site Engineer marks worker departure (clock out)"""
    import re
    try:
        current_user = g.user
        data = request.get_json()

        # Role-based authorization
        user_role = current_user.get('role', '').lower().replace(' ', '').replace('_', '')
        allowed_roles = ['se', 'siteengineer', 'pm', 'projectmanager', 'admin', 'productionmanager', 'td', 'technicaldirector']
        if user_role not in allowed_roles:
            return jsonify({"error": "Unauthorized. Only Site Engineers, Project Managers, or Admins can mark departures."}), 403

        arrival_id = data.get('arrival_id')
        departure_time = data.get('departure_time')  # HH:MM format

        if not arrival_id:
            return jsonify({"error": "arrival_id is required"}), 400

        # Validate time format if provided
        if departure_time:
            if not re.match(r'^([01]?[0-9]|2[0-3]):[0-5][0-9]$', departure_time):
                return jsonify({"error": "Invalid departure_time format. Use HH:MM (e.g., 17:30)"}), 400

        arrival = LabourArrival.query.filter_by(
            arrival_id=arrival_id,
            is_deleted=False
        ).first()

        if not arrival:
            return jsonify({"error": "Arrival record not found"}), 404

        if arrival.arrival_status != 'confirmed':
            return jsonify({"error": "Worker must be confirmed as arrived before marking departure"}), 400

        if arrival.departure_time:
            return jsonify({"error": "Departure already recorded"}), 400

        # Calculate departure time
        final_departure_time = departure_time or datetime.now().strftime('%H:%M')

        # Validate departure time is after arrival time
        if arrival.arrival_time and final_departure_time:
            try:
                arr_parts = arrival.arrival_time.split(':')
                dep_parts = final_departure_time.split(':')
                arrival_minutes = int(arr_parts[0]) * 60 + int(arr_parts[1])
                departure_minutes = int(dep_parts[0]) * 60 + int(dep_parts[1])
                if departure_minutes < arrival_minutes:
                    return jsonify({"error": f"Departure time ({final_departure_time}) cannot be before arrival time ({arrival.arrival_time})"}), 400
            except (ValueError, IndexError):
                pass  # If parsing fails, allow the time through

        arrival.arrival_status = 'departed'
        arrival.departure_time = final_departure_time
        arrival.departed_at = datetime.utcnow()

        # Auto-create DailyAttendance record for payroll processing
        # Check if attendance record already exists
        existing_attendance = DailyAttendance.query.filter_by(
            worker_id=arrival.worker_id,
            project_id=arrival.project_id,
            attendance_date=arrival.arrival_date,
            is_deleted=False
        ).first()

        if not existing_attendance:
            # Get worker's hourly rate
            worker = Worker.query.get(arrival.worker_id)
            if worker:
                # Parse arrival and departure times to datetime
                clock_in_dt = datetime.combine(
                    arrival.arrival_date,
                    datetime.strptime(arrival.arrival_time, '%H:%M').time()
                )
                clock_out_dt = datetime.combine(
                    arrival.arrival_date,
                    datetime.strptime(final_departure_time, '%H:%M').time()
                )

                attendance = DailyAttendance(
                    worker_id=arrival.worker_id,
                    project_id=arrival.project_id,
                    requisition_id=arrival.requisition_id,  # CRITICAL: Link to requisition for PM filtering
                    attendance_date=arrival.arrival_date,
                    clock_in_time=clock_in_dt,
                    clock_out_time=clock_out_dt,
                    hourly_rate=worker.hourly_rate,
                    attendance_status='completed',
                    approval_status='pending',  # Ready for PM review
                    entered_by_user_id=current_user.get('user_id'),
                    entered_by_role=current_user.get('role', 'SE'),
                    created_by=current_user.get('full_name', 'System')
                )
                # Calculate hours and cost
                attendance.calculate_hours_and_cost()
                db.session.add(attendance)

        db.session.commit()
        return jsonify({
            "success": True,
            "message": f"Worker clocked out at {arrival.departure_time}",
            "arrival": arrival.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error marking departure: {str(e)}")
        return jsonify({"error": str(e)}), 500


# =============================================================================
# STEP 6: ATTENDANCE LOGS (Site Engineer)
# =============================================================================

def clock_in_worker():
    """Site Engineer clocks in a worker"""
    try:
        current_user = g.user
        data = request.get_json()

        worker_id = data.get('worker_id')
        project_id = data.get('project_id')
        attendance_date = data.get('attendance_date', date.today().isoformat())
        clock_in_time = data.get('clock_in_time')  # ISO format or HH:MM
        labour_role = data.get('labour_role')  # Labour role/skill for BOQ cost tracking

        # Sanitize labour_role if provided
        if labour_role:
            labour_role = str(labour_role).strip()[:100]

        if not worker_id or not project_id:
            return jsonify({"error": "worker_id and project_id are required"}), 400

        target_date = datetime.strptime(attendance_date, '%Y-%m-%d').date()

        # Check if attendance record already exists
        existing = DailyAttendance.query.filter_by(
            worker_id=worker_id,
            project_id=project_id,
            attendance_date=target_date,
            is_deleted=False
        ).first()

        if existing:
            if existing.clock_in_time:
                return jsonify({"error": "Worker already clocked in for this day"}), 400
            attendance = existing
            # Update labour_role if provided and not already set
            if labour_role and not attendance.labour_role:
                attendance.labour_role = labour_role
        else:
            # Get worker's hourly rate
            worker = Worker.query.get(worker_id)
            if not worker:
                return jsonify({"error": "Worker not found"}), 404

            attendance = DailyAttendance(
                worker_id=worker_id,
                project_id=project_id,
                attendance_date=target_date,
                hourly_rate=worker.hourly_rate,
                labour_role=labour_role,  # Link to BOQ labour item for cost tracking
                approval_status='pending',  # Will be reviewed by PM after completion
                entered_by_user_id=current_user.get('user_id'),
                entered_by_role=current_user.get('role', 'SE'),
                created_by=current_user.get('full_name', 'System')
            )
            db.session.add(attendance)

        # Parse clock in time
        if clock_in_time:
            if 'T' in clock_in_time:
                attendance.clock_in_time = datetime.fromisoformat(clock_in_time)
            else:
                # HH:MM format
                time_parts = clock_in_time.split(':')
                attendance.clock_in_time = datetime.combine(
                    target_date,
                    datetime.strptime(clock_in_time, '%H:%M').time()
                )
        else:
            attendance.clock_in_time = datetime.now()

        attendance.attendance_status = 'present'
        attendance.last_modified_by = current_user.get('full_name', 'System')

        db.session.commit()
        return jsonify({
            "success": True,
            "message": "Worker clocked in successfully",
            "attendance": attendance.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error clocking in worker: {str(e)}")
        return jsonify({"error": str(e)}), 500


def clock_out_worker():
    """Site Engineer clocks out a worker"""
    try:
        current_user = g.user
        data = request.get_json()

        worker_id = data.get('worker_id')
        project_id = data.get('project_id')
        attendance_date = data.get('attendance_date', date.today().isoformat())
        clock_out_time = data.get('clock_out_time')
        break_minutes = data.get('break_duration_minutes', 0)

        if not worker_id or not project_id:
            return jsonify({"error": "worker_id and project_id are required"}), 400

        target_date = datetime.strptime(attendance_date, '%Y-%m-%d').date()

        attendance = DailyAttendance.query.filter_by(
            worker_id=worker_id,
            project_id=project_id,
            attendance_date=target_date,
            is_deleted=False
        ).first()

        if not attendance:
            return jsonify({"error": "No clock-in record found for this worker"}), 404

        if not attendance.clock_in_time:
            return jsonify({"error": "Worker has not clocked in"}), 400

        if attendance.clock_out_time:
            return jsonify({"error": "Worker already clocked out"}), 400

        # Parse clock out time
        if clock_out_time:
            if 'T' in clock_out_time:
                attendance.clock_out_time = datetime.fromisoformat(clock_out_time)
            else:
                attendance.clock_out_time = datetime.combine(
                    target_date,
                    datetime.strptime(clock_out_time, '%H:%M').time()
                )
        else:
            attendance.clock_out_time = datetime.now()

        attendance.break_duration_minutes = break_minutes
        attendance.attendance_status = 'completed'
        attendance.approval_status = 'pending'  # Ready for PM review

        # Calculate hours and cost
        attendance.calculate_hours_and_cost()

        attendance.last_modified_by = current_user.get('full_name', 'System')

        db.session.commit()
        return jsonify({
            "success": True,
            "message": "Worker clocked out successfully",
            "attendance": attendance.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error clocking out worker: {str(e)}")
        return jsonify({"error": str(e)}), 500


def get_daily_attendance(project_id, date_str):
    """Get daily attendance records for a project"""
    try:
        target_date = datetime.strptime(date_str, '%Y-%m-%d').date()

        records = DailyAttendance.query.options(
            joinedload(DailyAttendance.worker)
        ).filter(
            DailyAttendance.project_id == project_id,
            DailyAttendance.attendance_date == target_date,
            DailyAttendance.is_deleted == False
        ).all()

        return jsonify({
            "success": True,
            "attendance": [r.to_dict() for r in records],
            "date": date_str,
            "total_records": len(records)
        }), 200

    except Exception as e:
        log.error(f"Error getting daily attendance: {str(e)}")
        return jsonify({"error": str(e)}), 500


def update_attendance(attendance_id):
    """Update an attendance record (before lock)"""
    try:
        current_user = g.user
        data = request.get_json()

        attendance = DailyAttendance.query.filter_by(
            attendance_id=attendance_id,
            is_deleted=False
        ).first()

        if not attendance:
            return jsonify({"error": "Attendance record not found"}), 404

        if attendance.approval_status == 'locked':
            return jsonify({"error": "Cannot modify locked attendance"}), 400

        # Update fields
        if 'clock_in_time' in data and data['clock_in_time']:
            attendance.original_clock_in = attendance.clock_in_time
            if 'T' in data['clock_in_time']:
                attendance.clock_in_time = datetime.fromisoformat(data['clock_in_time'])
            else:
                attendance.clock_in_time = datetime.combine(
                    attendance.attendance_date,
                    datetime.strptime(data['clock_in_time'], '%H:%M').time()
                )

        if 'clock_out_time' in data and data['clock_out_time']:
            attendance.original_clock_out = attendance.clock_out_time
            if 'T' in data['clock_out_time']:
                attendance.clock_out_time = datetime.fromisoformat(data['clock_out_time'])
            else:
                attendance.clock_out_time = datetime.combine(
                    attendance.attendance_date,
                    datetime.strptime(data['clock_out_time'], '%H:%M').time()
                )

        if 'break_duration_minutes' in data:
            attendance.break_duration_minutes = int(data['break_duration_minutes'])

        if 'correction_reason' in data:
            attendance.correction_reason = data['correction_reason']
            attendance.corrected_by_user_id = current_user.get('user_id')
            attendance.corrected_at = datetime.utcnow()

        if 'entry_notes' in data:
            attendance.entry_notes = data['entry_notes']

        # Recalculate hours and cost
        attendance.calculate_hours_and_cost()
        attendance.last_modified_by = current_user.get('full_name', 'System')

        db.session.commit()

        return jsonify({
            "success": True,
            "message": "Attendance updated successfully",
            "attendance": attendance.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error updating attendance: {str(e)}")
        return jsonify({"error": str(e)}), 500


# =============================================================================
# STEP 7: REVIEW & LOCK (Project Manager)
# =============================================================================

def get_attendance_to_lock():
    """Get attendance records with optional status filter - only for PM/MEP's assigned projects"""
    try:
        user_id = g.user.get('user_id')
        user_role = normalize_role(g.user.get('role', ''))
        if not user_id:
            return jsonify({'success': False, 'error': 'User not authenticated'}), 401

        project_id = request.args.get('project_id', type=int)
        date_str = request.args.get('date')
        approval_status = request.args.get('approval_status', 'pending')  # 'pending' or 'locked'
        view_as_role = request.args.get('view_as_role', '').lower()  # For admin viewing as other roles

        # Valid roles for view_as_role parameter
        VALID_VIEW_AS_ROLES = frozenset(['pm', 'projectmanager', 'mep', 'mepsupervisor', 'mep_supervisor', 'se', 'siteengineer'])

        # Validate view_as_role if provided
        if view_as_role and view_as_role not in VALID_VIEW_AS_ROLES:
            return jsonify({'success': False, 'error': f'Invalid view_as_role: {view_as_role}'}), 400

        # If admin is viewing as another role, use that role for filtering
        is_admin_viewing_as_role = False
        original_role = user_role
        if user_role in SUPER_ADMIN_ROLES and view_as_role:
            is_admin_viewing_as_role = True
            user_role = view_as_role

        from models.project import Project
        from models.labour_arrival import LabourArrival
        from models.worker import Worker

        pm_project_ids = []

        # Admin viewing as role gets ALL projects (no user-specific filtering)
        if is_admin_viewing_as_role or original_role in SUPER_ADMIN_ROLES:
            all_projects = Project.query.filter(
                Project.is_deleted == False
            ).all()
            pm_project_ids = [proj.project_id for proj in all_projects]
        # Role-based project filtering for regular users
        elif user_role in ['mep', 'mepsupervisor', 'mep_supervisor']:
            # MEP: Get projects where mep_supervisor_id contains this user
            all_projects = Project.query.filter(
                Project.is_deleted == False,
                Project.mep_supervisor_id.isnot(None)
            ).all()

            for proj in all_projects:
                if proj.mep_supervisor_id and isinstance(proj.mep_supervisor_id, list) and user_id in proj.mep_supervisor_id:
                    pm_project_ids.append(proj.project_id)
        else:
            # PM: Get projects where user_id contains this user
            all_projects = Project.query.filter(
                Project.is_deleted == False,
                Project.user_id.isnot(None)
            ).all()

            for proj in all_projects:
                if proj.user_id and isinstance(proj.user_id, list) and user_id in proj.user_id:
                    pm_project_ids.append(proj.project_id)
        # If no projects assigned, return empty list
        if not pm_project_ids:
            return jsonify({
                "success": True,
                "attendance": [],
                "total_records": 0
            }), 200

        # STEP 1: Check for departed arrivals that need attendance records created
        # Auto-create missing attendance records for departed arrivals (works for all queries)

        # Build query for departed arrivals
        departed_query = LabourArrival.query.filter(
            LabourArrival.arrival_status == 'departed',
            LabourArrival.project_id.in_(pm_project_ids),
            LabourArrival.is_deleted == False
        )

        # Add date filter if provided
        if date_str:
            target_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            departed_query = departed_query.filter(LabourArrival.arrival_date == target_date)

        departed_arrivals = departed_query.all()

        # Auto-create missing attendance records for departed workers
        if departed_arrivals:
            for arrival in departed_arrivals:
                # Check if attendance already exists
                existing = DailyAttendance.query.filter_by(
                    worker_id=arrival.worker_id,
                    project_id=arrival.project_id,
                    attendance_date=arrival.arrival_date,
                    is_deleted=False
                ).first()

                if not existing and arrival.arrival_time and arrival.departure_time:
                    # Create attendance record
                    worker = Worker.query.get(arrival.worker_id)
                    if worker:
                        clock_in_dt = datetime.combine(
                            arrival.arrival_date,
                            datetime.strptime(arrival.arrival_time, '%H:%M').time()
                        )
                        clock_out_dt = datetime.combine(
                            arrival.arrival_date,
                            datetime.strptime(arrival.departure_time, '%H:%M').time()
                        )

                        attendance = DailyAttendance(
                            worker_id=arrival.worker_id,
                            project_id=arrival.project_id,
                            requisition_id=arrival.requisition_id,  # CRITICAL: Link to requisition for PM filtering
                            attendance_date=arrival.arrival_date,
                            clock_in_time=clock_in_dt,
                            clock_out_time=clock_out_dt,
                            hourly_rate=worker.hourly_rate,
                            attendance_status='completed',
                            approval_status='pending',
                            entered_by_user_id=user_id,
                            entered_by_role='System',
                            created_by='System Auto-Create'
                        )
                        attendance.calculate_hours_and_cost()
                        db.session.add(attendance)

            db.session.commit()

        # STEP 2: Query attendance records
        # Join with requisition to filter by PM who approved the requisition
        # This ensures each PM only sees attendance from their approved requisitions
        query = DailyAttendance.query.options(
            joinedload(DailyAttendance.worker),
            joinedload(DailyAttendance.project)
        ).join(
            LabourRequisition,
            DailyAttendance.requisition_id == LabourRequisition.requisition_id
        ).filter(
            DailyAttendance.is_deleted == False,
            DailyAttendance.project_id.in_(pm_project_ids)  # Filter by projects
        )

        # Admin viewing as role sees ALL attendance records (no approver filter)
        if not is_admin_viewing_as_role and original_role not in SUPER_ADMIN_ROLES:
            # Regular PM only sees requisitions they approved
            query = query.filter(LabourRequisition.approved_by_user_id == user_id)
        else:
            log.info(f"Admin viewing all attendance records (no approver filter)")

        # Filter by approval status
        if approval_status == 'pending':
            # Include records with approval_status='pending' OR (approval_status is NULL and attendance is completed)
            query = query.filter(
                or_(
                    DailyAttendance.approval_status == 'pending',
                    and_(
                        DailyAttendance.approval_status.is_(None),
                        DailyAttendance.attendance_status == 'completed',
                        DailyAttendance.clock_out_time.isnot(None)
                    )
                )
            )
        elif approval_status == 'locked':
            query = query.filter(DailyAttendance.approval_status == 'locked')

        if project_id:
            # Additional filter if specific project requested
            if project_id in pm_project_ids:
                query = query.filter(DailyAttendance.project_id == project_id)
            else:
                # Requested project not assigned to this PM
                return jsonify({
                    "success": True,
                    "attendance": [],
                    "total_records": 0
                }), 200

        if date_str:
            target_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            query = query.filter(DailyAttendance.attendance_date == target_date)

        query = query.order_by(DailyAttendance.attendance_date.desc())
        records = query.all()

        return jsonify({
            "success": True,
            "attendance": [r.to_dict_for_lock() for r in records],
            "total_records": len(records)
        }), 200

    except Exception as e:
        log.error(f"Error getting attendance: {str(e)}")
        return jsonify({"error": str(e)}), 500


def lock_attendance(attendance_id):
    """PM locks a single attendance record"""
    try:
        current_user = g.user
        data = request.get_json() or {}

        attendance = DailyAttendance.query.filter_by(
            attendance_id=attendance_id,
            is_deleted=False
        ).first()

        if not attendance:
            return jsonify({"error": "Attendance record not found"}), 404

        if attendance.approval_status == 'locked':
            return jsonify({"error": "Attendance already locked"}), 400

        # Lock the record
        attendance.approval_status = 'locked'
        attendance.approved_by_user_id = current_user.get('user_id')
        attendance.approved_by_name = current_user.get('full_name', 'Unknown')
        attendance.approval_date = datetime.utcnow()
        attendance.last_modified_by = current_user.get('full_name', 'System')

        # Create history record
        history = AttendanceApprovalHistory(
            attendance_id=attendance_id,
            action='locked',
            action_by_user_id=current_user.get('user_id'),
            action_by_name=current_user.get('full_name', 'Unknown'),
            action_by_role='PM',
            comments=data.get('comments'),
            previous_status='pending',
            new_status='locked',
            data_snapshot={
                'total_hours': attendance.total_hours,
                'total_cost': attendance.total_cost,
                'clock_in': attendance.clock_in_time.isoformat() if attendance.clock_in_time else None,
                'clock_out': attendance.clock_out_time.isoformat() if attendance.clock_out_time else None
            }
        )
        db.session.add(history)

        db.session.commit()

        return jsonify({
            "success": True,
            "message": "Attendance locked for payroll",
            "attendance": attendance.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error locking attendance: {str(e)}")
        return jsonify({"error": str(e)}), 500


def lock_day_attendance():
    """PM locks all attendance records for a specific day"""
    try:
        current_user = g.user
        data = request.get_json()

        project_id = data.get('project_id')
        date_str = data.get('date')

        if not project_id or not date_str:
            return jsonify({"error": "project_id and date are required"}), 400

        target_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        user_id = current_user.get('user_id')

        # Join with requisition to only lock attendance from requisitions approved by this PM
        records = DailyAttendance.query.join(
            LabourRequisition,
            DailyAttendance.requisition_id == LabourRequisition.requisition_id
        ).filter(
            DailyAttendance.project_id == project_id,
            DailyAttendance.attendance_date == target_date,
            DailyAttendance.approval_status == 'pending',
            DailyAttendance.is_deleted == False,
            LabourRequisition.approved_by_user_id == user_id  # CRITICAL: Only lock attendance from this PM's requisitions
        ).all()

        locked_count = 0
        for attendance in records:
            attendance.approval_status = 'locked'
            attendance.approved_by_user_id = current_user.get('user_id')
            attendance.approved_by_name = current_user.get('full_name', 'Unknown')
            attendance.approval_date = datetime.utcnow()
            attendance.last_modified_by = current_user.get('full_name', 'System')

            # Create history record
            history = AttendanceApprovalHistory(
                attendance_id=attendance.attendance_id,
                action='locked',
                action_by_user_id=current_user.get('user_id'),
                action_by_name=current_user.get('full_name', 'Unknown'),
                action_by_role='PM',
                previous_status='pending',
                new_status='locked'
            )
            db.session.add(history)
            locked_count += 1

        db.session.commit()

        return jsonify({
            "success": True,
            "message": f"{locked_count} attendance records locked for payroll",
            "locked_count": locked_count
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error locking day attendance: {str(e)}")
        return jsonify({"error": str(e)}), 500


# =============================================================================
# STEP 8: PAYROLL (Admin/HR)
# =============================================================================

def get_locked_for_payroll():
    """Get locked attendance records for payroll processing"""
    try:
        project_id = request.args.get('project_id', type=int)
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')

        query = DailyAttendance.query.options(
            joinedload(DailyAttendance.worker)
        ).filter(
            DailyAttendance.approval_status == 'locked',
            DailyAttendance.is_deleted == False
        )

        if project_id:
            query = query.filter(DailyAttendance.project_id == project_id)

        if start_date:
            query = query.filter(DailyAttendance.attendance_date >= datetime.strptime(start_date, '%Y-%m-%d').date())

        if end_date:
            query = query.filter(DailyAttendance.attendance_date <= datetime.strptime(end_date, '%Y-%m-%d').date())

        query = query.order_by(DailyAttendance.attendance_date.desc())
        records = query.all()

        # Calculate totals
        total_hours = sum(r.total_hours or 0 for r in records)
        total_cost = sum(r.total_cost or 0 for r in records)

        return jsonify({
            "success": True,
            "attendance": [r.to_dict() for r in records],
            "summary": {
                "total_records": len(records),
                "total_hours": round(total_hours, 2),
                "total_cost": round(total_cost, 2)
            }
        }), 200

    except Exception as e:
        log.error(f"Error getting locked attendance: {str(e)}")
        return jsonify({"error": str(e)}), 500


def get_payroll_summary():
    """Get payroll summary grouped by project and worker (nested structure)"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        project_id = request.args.get('project_id', type=int)

        if not start_date or not end_date:
            return jsonify({"error": "start_date and end_date are required"}), 400

        start = datetime.strptime(start_date, '%Y-%m-%d').date()
        end = datetime.strptime(end_date, '%Y-%m-%d').date()

        # Import Project model
        from models.project import Project
        from models.labour_requisition import LabourRequisition

        # Aggregate by project, requisition, and worker
        query = db.session.query(
            DailyAttendance.project_id,
            Project.project_name,
            Project.project_code,
            DailyAttendance.requisition_id,
            LabourRequisition.requisition_code,
            LabourRequisition.work_description,
            LabourRequisition.skill_required,
            LabourRequisition.site_name,
            LabourRequisition.workers_count,
            LabourRequisition.transport_fee,
            DailyAttendance.worker_id,
            Worker.worker_code,
            Worker.full_name,
            Worker.hourly_rate,
            func.count(DailyAttendance.attendance_id).label('days_worked'),
            func.sum(DailyAttendance.total_hours).label('total_hours'),
            func.sum(DailyAttendance.regular_hours).label('regular_hours'),
            func.sum(DailyAttendance.overtime_hours).label('overtime_hours'),
            func.sum(DailyAttendance.total_cost).label('total_cost')
        ).join(Worker).join(Project).outerjoin(
            LabourRequisition,
            DailyAttendance.requisition_id == LabourRequisition.requisition_id
        ).filter(
            DailyAttendance.approval_status == 'locked',
            DailyAttendance.is_deleted == False,
            DailyAttendance.attendance_date >= start,
            DailyAttendance.attendance_date <= end
        )

        # Filter by project if specified
        if project_id:
            query = query.filter(DailyAttendance.project_id == project_id)

        results = query.group_by(
            DailyAttendance.project_id,
            Project.project_name,
            Project.project_code,
            DailyAttendance.requisition_id,
            LabourRequisition.requisition_code,
            LabourRequisition.work_description,
            LabourRequisition.skill_required,
            LabourRequisition.site_name,
            LabourRequisition.workers_count,
            LabourRequisition.transport_fee,
            DailyAttendance.worker_id,
            Worker.worker_code,
            Worker.full_name,
            Worker.hourly_rate
        ).order_by(Project.project_name, LabourRequisition.requisition_code, Worker.full_name).all()

        # Group by project -> requisition -> workers (nested structure)
        projects_dict = {}
        flat_summary = []  # Keep flat list for backwards compatibility
        requisition_transport_added = set()  # Track which requisitions already have transport fee added

        for r in results:
            # Build flat summary (backwards compatible)
            flat_summary.append({
                'worker_id': r.worker_id,
                'worker_code': r.worker_code,
                'worker_name': r.full_name,
                'project_id': r.project_id,
                'project_name': r.project_name,
                'requisition_id': r.requisition_id,
                'average_hourly_rate': float(r.hourly_rate) if r.hourly_rate else 0,
                'total_days': r.days_worked,
                'total_hours': round(float(r.total_hours or 0), 2),
                'total_regular_hours': round(float(r.regular_hours or 0), 2),
                'total_overtime_hours': round(float(r.overtime_hours or 0), 2),
                'total_cost': round(float(r.total_cost or 0), 2)
            })

            # Build nested structure: Project -> Requisition -> Workers
            if r.project_id not in projects_dict:
                projects_dict[r.project_id] = {
                    'project_id': r.project_id,
                    'project_name': r.project_name,
                    'project_code': r.project_code,
                    'total_hours': 0,
                    'total_regular_hours': 0,
                    'total_overtime_hours': 0,
                    'total_cost': 0,
                    'total_days': 0,
                    'worker_count': 0,
                    'requisitions': {}
                }

            proj = projects_dict[r.project_id]

            # Group by requisition within project
            req_key = r.requisition_id if r.requisition_id else 'no_requisition'
            if req_key not in proj['requisitions']:
                proj['requisitions'][req_key] = {
                    'requisition_id': r.requisition_id,
                    'requisition_code': r.requisition_code if r.requisition_id else 'General Work',
                    'work_description': r.work_description if r.requisition_id else 'No Requisition',
                    'skill_required': r.skill_required if r.requisition_id else 'General',
                    'site_name': r.site_name if r.requisition_id else None,
                    'workers_count': r.workers_count if r.requisition_id else None,
                    'transport_fee': float(r.transport_fee or 0) if r.requisition_id else 0,
                    'total_hours': 0,
                    'total_regular_hours': 0,
                    'total_overtime_hours': 0,
                    'total_cost': 0,
                    'total_days': 0,
                    'workers': []
                }

                # Add transport fee once per requisition (not per worker)
                if r.requisition_id and r.requisition_id not in requisition_transport_added:
                    transport_fee_value = float(r.transport_fee or 0)
                    proj['requisitions'][req_key]['total_cost'] += transport_fee_value
                    proj['total_cost'] += transport_fee_value
                    requisition_transport_added.add(r.requisition_id)

            req = proj['requisitions'][req_key]
            req['workers'].append({
                'worker_id': r.worker_id,
                'worker_code': r.worker_code,
                'worker_name': r.full_name,
                'average_hourly_rate': float(r.hourly_rate) if r.hourly_rate else 0,
                'total_days': r.days_worked,
                'total_hours': round(float(r.total_hours or 0), 2),
                'total_regular_hours': round(float(r.regular_hours or 0), 2),
                'total_overtime_hours': round(float(r.overtime_hours or 0), 2),
                'total_cost': round(float(r.total_cost or 0), 2)
            })

            # Update requisition totals
            req['total_hours'] += float(r.total_hours or 0)
            req['total_regular_hours'] += float(r.regular_hours or 0)
            req['total_overtime_hours'] += float(r.overtime_hours or 0)
            req['total_cost'] += float(r.total_cost or 0)
            req['total_days'] += r.days_worked

            # Update project totals
            proj['total_hours'] += float(r.total_hours or 0)
            proj['total_regular_hours'] += float(r.regular_hours or 0)
            proj['total_overtime_hours'] += float(r.overtime_hours or 0)
            proj['total_cost'] += float(r.total_cost or 0)
            proj['total_days'] += r.days_worked

        # Round project and requisition totals, convert requisitions dict to list
        grouped_data = []
        for proj in projects_dict.values():
            proj['total_hours'] = round(proj['total_hours'], 2)
            proj['total_regular_hours'] = round(proj['total_regular_hours'], 2)
            proj['total_overtime_hours'] = round(proj['total_overtime_hours'], 2)
            proj['total_cost'] = round(proj['total_cost'], 2)

            # Convert requisitions dict to list and round totals
            requisitions_list = []
            total_workers_in_project = 0
            for req in proj['requisitions'].values():
                req['total_hours'] = round(req['total_hours'], 2)
                req['total_regular_hours'] = round(req['total_regular_hours'], 2)
                req['total_overtime_hours'] = round(req['total_overtime_hours'], 2)
                req['total_cost'] = round(req['total_cost'], 2)
                total_workers_in_project += len(req['workers'])
                requisitions_list.append(req)

            proj['requisitions'] = requisitions_list
            proj['worker_count'] = total_workers_in_project
            grouped_data.append(proj)

        grand_total = sum(p['total_cost'] for p in grouped_data)
        total_hours = sum(p['total_hours'] for p in grouped_data)

        return jsonify({
            "success": True,
            "payroll_summary": flat_summary,  # Backwards compatible flat list
            "grouped_by_project": grouped_data,  # New nested structure
            "period": {
                "start_date": start_date,
                "end_date": end_date
            },
            "grand_total": round(grand_total, 2),
            "total_hours": round(total_hours, 2),
            "total_workers": len(flat_summary),
            "total_projects": len(grouped_data)
        }), 200

    except Exception as e:
        log.error(f"Error getting payroll summary: {str(e)}")
        return jsonify({"error": str(e)}), 500


# =============================================================================
# DASHBOARD & REPORTS
# =============================================================================

def get_labour_dashboard():
    """Get dashboard statistics for labour management, filtered by user's assigned projects"""
    try:
        current_user = g.user
        user_id = current_user.get('user_id')
        user_role = normalize_role(current_user.get('role', ''))

        # Validate user_id
        if not user_id:
            return jsonify({"error": "User ID not found in session"}), 401

        today = date.today()

        # Role-based project filtering
        # Admin, TD, and Production Manager can see all stats
        assigned_project_ids = None

        if user_role not in LABOUR_ADMIN_ROLES:
            assigned_project_ids = get_user_assigned_project_ids(user_id)

        # Build queries with optional project filtering
        pending_req_query = LabourRequisition.query.filter(
            LabourRequisition.status == 'pending',
            LabourRequisition.is_deleted == False
        )
        approved_unassigned_query = LabourRequisition.query.filter(
            LabourRequisition.status == 'approved',
            LabourRequisition.assignment_status == 'unassigned',
            LabourRequisition.is_deleted == False
        )
        arrivals_pending_query = LabourArrival.query.filter(
            LabourArrival.arrival_date == today,
            LabourArrival.arrival_status == 'assigned',
            LabourArrival.is_deleted == False
        )
        arrivals_confirmed_query = LabourArrival.query.filter(
            LabourArrival.arrival_date == today,
            LabourArrival.arrival_status == 'confirmed',
            LabourArrival.is_deleted == False
        )
        pending_lock_query = DailyAttendance.query.filter(
            DailyAttendance.approval_status == 'pending',
            DailyAttendance.is_deleted == False
        )

        # Apply project filter if user has restricted access
        if assigned_project_ids is not None:
            if assigned_project_ids:
                pending_req_query = pending_req_query.filter(
                    LabourRequisition.project_id.in_(assigned_project_ids)
                )
                approved_unassigned_query = approved_unassigned_query.filter(
                    LabourRequisition.project_id.in_(assigned_project_ids)
                )
                arrivals_pending_query = arrivals_pending_query.filter(
                    LabourArrival.project_id.in_(assigned_project_ids)
                )
                arrivals_confirmed_query = arrivals_confirmed_query.filter(
                    LabourArrival.project_id.in_(assigned_project_ids)
                )
                pending_lock_query = pending_lock_query.filter(
                    DailyAttendance.project_id.in_(assigned_project_ids)
                )
            else:
                # User has no assigned projects, return zero stats
                return jsonify({
                    "success": True,
                    "dashboard": {
                        'total_workers': 0,
                        'pending_requisitions': 0,
                        'approved_unassigned': 0,
                        'today_arrivals_pending': 0,
                        'today_arrivals_confirmed': 0,
                        'pending_lock': 0
                    },
                    "date": today.isoformat()
                }), 200

        stats = {
            'total_workers': Worker.query.filter(Worker.is_deleted == False, Worker.status == 'active').count(),
            'pending_requisitions': pending_req_query.count(),
            'approved_unassigned': approved_unassigned_query.count(),
            'today_arrivals_pending': arrivals_pending_query.count(),
            'today_arrivals_confirmed': arrivals_confirmed_query.count(),
            'pending_lock': pending_lock_query.count()
        }

        return jsonify({
            "success": True,
            "dashboard": stats,
            "date": today.isoformat()
        }), 200

    except Exception as e:
        log.error(f"Error getting dashboard: {str(e)}")
        return jsonify({"error": str(e)}), 500


# =============================================================================
# UTILITY: Get Projects for User
# =============================================================================

def get_user_projects():
    """
    Get projects accessible to current user for dropdowns/filters.
    Used by Attendance Lock and other labour features.
    Returns projects based on user's primary role:
    - Admin/TD: All non-completed projects
    - PM: Projects where they are PM (user_id contains their ID)
    - SE: Projects where they are SE (site_supervisor_id)
    - Other roles: Their specific role assignment
    """
    try:
        current_user = g.get('user')
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401

        user_id = current_user.get('user_id')
        user_role = normalize_role(current_user.get('role', ''))

        from models.project import Project

        # Admin/TD can see all non-completed projects
        if user_role in SUPER_ADMIN_ROLES:
            projects_query = Project.query.filter(
                Project.is_deleted == False,
                func.lower(Project.status) != 'completed'
            ).order_by(Project.project_name)
        # Project Manager - only projects where they are PM AND (has approved BOQ OR has SE assignments)
        # This matches the "My Projects" page logic (Pending + Assigned tabs)
        elif user_role == 'projectmanager':
            from models.boq import BOQ
            from models.pm_assign_ss import PMAssignSS

            # Get projects with approved BOQs OR with SE assignments
            projects_query = db.session.query(Project).filter(
                Project.is_deleted == False,
                func.lower(Project.status) != 'completed',
                Project.user_id.contains([user_id])
            ).join(
                BOQ, Project.project_id == BOQ.project_id
            ).filter(
                BOQ.is_deleted == False,
                or_(
                    # Has approved BOQ (Pending tab)
                    BOQ.status.in_(['approved', 'Approved']),
                    # Has SE assignments (Assigned tab)
                    # Must be assignments made BY this PM
                    BOQ.boq_id.in_(
                        db.session.query(PMAssignSS.boq_id).filter(
                            PMAssignSS.is_deleted == False,
                            PMAssignSS.assigned_by_pm_id == user_id
                        )
                    )
                )
            ).distinct().order_by(Project.project_name)
        # Site Engineer/Supervisor - only projects where they are SE
        elif user_role in ['siteengineer', 'sitesupervisor', 'ss']:
            projects_query = Project.query.filter(
                Project.is_deleted == False,
                func.lower(Project.status) != 'completed',
                Project.site_supervisor_id == user_id
            ).order_by(Project.project_name)
        # MEP Supervisor - only projects where they are MEP
        elif user_role in ['mepsupervisor', 'mep']:
            projects_query = Project.query.filter(
                Project.is_deleted == False,
                func.lower(Project.status) != 'completed',
                Project.mep_supervisor_id.contains([user_id])
            ).order_by(Project.project_name)
        # Other roles: Check all possible assignments
        else:
            projects_query = Project.query.filter(
                Project.is_deleted == False,
                func.lower(Project.status) != 'completed',
                or_(
                    Project.user_id.contains([user_id]),
                    Project.site_supervisor_id == user_id,
                    Project.mep_supervisor_id.contains([user_id]),
                    Project.estimator_id == user_id,
                    Project.buyer_id == user_id
                )
            ).order_by(Project.project_name)

        projects = projects_query.all()

        projects_list = [{
            'project_id': p.project_id,
            'project_code': p.project_code or f'P{p.project_id}',
            'project_name': p.project_name,
            'client': p.client,
            'location': p.location,
            'status': p.status
        } for p in projects]

        return jsonify({
            'success': True,
            'projects': projects_list
        }), 200

    except Exception as e:
        log.error(f"Error fetching user projects: {str(e)}")
        return jsonify({'error': str(e)}), 500


def download_assignment_pdf(requisition_id):
    """Download PDF report for a specific requisition assignment"""
    try:
        from flask import send_file
        from utils.labour_assignment_pdf_generator import generate_assignment_pdf
        from datetime import timezone

        # Helper function to convert UTC to local timezone
        def utc_to_local(utc_dt):
            """Convert UTC datetime to local system timezone"""
            if utc_dt.tzinfo is None:
                # Assume UTC if timezone-naive
                utc_dt = utc_dt.replace(tzinfo=timezone.utc)
            # Convert to local time using timestamp
            timestamp = utc_dt.timestamp()
            local_dt = datetime.fromtimestamp(timestamp)
            return local_dt

        # Fetch requisition with all details
        requisition = LabourRequisition.query.filter_by(
            requisition_id=requisition_id,
            is_deleted=False
        ).first()

        if not requisition:
            return jsonify({"error": "Requisition not found"}), 404

        # Prepare data for PDF
        requisition_dict = requisition.to_dict()

        # Get assigned workers with full details
        if requisition.assigned_worker_ids:
            workers = Worker.query.filter(
                Worker.worker_id.in_(requisition.assigned_worker_ids),
                Worker.is_deleted == False
            ).all()

            requisition_dict['assigned_workers'] = [{
                'worker_id': w.worker_id,
                'worker_code': w.worker_code,
                'full_name': w.full_name,
                'skills': w.skills or [],
                'phone': w.phone,
                'hourly_rate': float(w.hourly_rate) if w.hourly_rate else 0
            } for w in workers]
        else:
            requisition_dict['assigned_workers'] = []

        # Format dates and times for display (convert UTC to local timezone)
        # Note: required_date is a DATE field (no time component), so no timezone conversion needed
        if requisition_dict.get('required_date'):
            # Parse as date string (YYYY-MM-DD format)
            date_str = requisition_dict['required_date']
            if isinstance(date_str, str):
                try:
                    date_obj = datetime.strptime(date_str, '%Y-%m-%d')
                    requisition_dict['required_date'] = date_obj.strftime('%B %d, %Y')
                except:
                    pass

        # Format time fields to 12-hour format with AM/PM
        # These are local work shift times, no timezone conversion needed
        if requisition_dict.get('start_time'):
            time_str = requisition_dict['start_time']
            if isinstance(time_str, str):
                try:
                    # Try parsing HH:MM format first (from to_dict)
                    try:
                        time_obj = datetime.strptime(time_str, '%H:%M').time()
                    except:
                        # Fallback to HH:MM:SS format
                        time_obj = datetime.strptime(time_str, '%H:%M:%S').time()

                    # Format as 12-hour time
                    requisition_dict['start_time'] = datetime.combine(datetime.today(), time_obj).strftime('%I:%M %p')
                except:
                    pass

        if requisition_dict.get('end_time'):
            time_str = requisition_dict['end_time']
            if isinstance(time_str, str):
                try:
                    # Try parsing HH:MM format first (from to_dict)
                    try:
                        time_obj = datetime.strptime(time_str, '%H:%M').time()
                    except:
                        # Fallback to HH:MM:SS format
                        time_obj = datetime.strptime(time_str, '%H:%M:%S').time()

                    # Format as 12-hour time
                    requisition_dict['end_time'] = datetime.combine(datetime.today(), time_obj).strftime('%I:%M %p')
                except:
                    pass

        if requisition_dict.get('request_date'):
            date_obj = datetime.fromisoformat(requisition_dict['request_date'])
            local_date = utc_to_local(date_obj)
            requisition_dict['request_date'] = local_date.strftime('%B %d, %Y %I:%M %p')

        if requisition_dict.get('approval_date'):
            date_obj = datetime.fromisoformat(requisition_dict['approval_date'])
            local_date = utc_to_local(date_obj)
            requisition_dict['approval_date'] = local_date.strftime('%B %d, %Y %I:%M %p')

        if requisition_dict.get('assignment_date'):
            date_obj = datetime.fromisoformat(requisition_dict['assignment_date'])
            local_date = utc_to_local(date_obj)
            requisition_dict['assignment_date'] = local_date.strftime('%B %d, %Y %I:%M %p')

        # Generate PDF
        pdf_buffer = generate_assignment_pdf(requisition_dict)

        # Create filename with current date
        filename = f"Assignment_{requisition.requisition_code}_{datetime.now().strftime('%Y%m%d')}.pdf"

        return send_file(
            pdf_buffer,
            mimetype='application/pdf',
            as_attachment=True,
            download_name=filename
        )

    except Exception as e:
        log.error(f"Error generating assignment PDF: {str(e)}")
        return jsonify({"error": f"Failed to generate PDF: {str(e)}"}), 500


def download_daily_schedule_pdf():
    """Download daily worker assignment schedule PDF (poster format for hostel wall)"""
    try:
        from flask import send_file
        from utils.daily_schedule_pdf_generator import generate_daily_schedule_pdf
        from datetime import timezone

        # Helper function to convert UTC to local timezone
        def utc_to_local(utc_dt):
            """Convert UTC datetime to local system timezone"""
            if utc_dt.tzinfo is None:
                utc_dt = utc_dt.replace(tzinfo=timezone.utc)
            timestamp = utc_dt.timestamp()
            local_dt = datetime.fromtimestamp(timestamp)
            return local_dt

        # Get date from query parameter
        date_str = request.args.get('date')
        if not date_str:
            return jsonify({"error": "Date parameter is required"}), 400

        try:
            target_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({"error": "Invalid date format. Use YYYY-MM-DD"}), 400

        # Fetch all assigned requisitions for this date (not rejected, with assigned workers)
        requisitions = LabourRequisition.query.filter(
            LabourRequisition.required_date == target_date,
            LabourRequisition.assignment_status == 'assigned',
            LabourRequisition.status != 'rejected',
            LabourRequisition.is_deleted == False
        ).options(
            joinedload(LabourRequisition.project)
        ).all()

        # Group requisitions by project
        projects_data = {}

        for req in requisitions:
            project_id = req.project_id
            project_name = req.project.project_name if req.project else 'Unknown Project'

            if project_id not in projects_data:
                projects_data[project_id] = {
                    'project_id': project_id,
                    'project_name': project_name,
                    'site_name': req.site_name,
                    'requisitions': []
                }

            # Get assigned workers with full details
            assigned_workers = []
            if req.assigned_worker_ids:
                workers = Worker.query.filter(
                    Worker.worker_id.in_(req.assigned_worker_ids),
                    Worker.is_deleted == False
                ).all()

                assigned_workers = [{
                    'worker_id': w.worker_id,
                    'worker_code': w.worker_code,
                    'full_name': w.full_name,
                    'skills': w.skills or [],
                    'phone': w.phone
                } for w in workers]

            # Format time fields to 12-hour format
            start_time_formatted = 'N/A'
            end_time_formatted = 'N/A'

            if req.start_time:
                time_obj = req.start_time
                start_time_formatted = datetime.combine(datetime.today(), time_obj).strftime('%I:%M %p')

            if req.end_time:
                time_obj = req.end_time
                end_time_formatted = datetime.combine(datetime.today(), time_obj).strftime('%I:%M %p')

            # Add requisition data to project
            projects_data[project_id]['requisitions'].append({
                'requisition_code': req.requisition_code,
                'site_name': req.site_name,
                'start_time': start_time_formatted,
                'end_time': end_time_formatted,
                'driver_name': req.driver_name or 'N/A',
                'vehicle_number': req.vehicle_number or 'N/A',
                'driver_contact': req.driver_contact or 'N/A',
                'transport_fee': float(req.transport_fee) if req.transport_fee else 0.0,
                'assigned_workers': assigned_workers
            })

        # Convert to list and sort by project name
        projects_list = sorted(projects_data.values(), key=lambda x: x['project_name'])

        # Prepare data for PDF generator
        schedule_data = {
            'date': target_date.strftime('%B %d, %Y'),  # Format: January 15, 2026
            'date_short': target_date.strftime('%d-%b-%Y'),  # Format: 15-Jan-2026
            'projects': projects_list,
            'total_projects': len(projects_list),
            'total_workers': sum(
                len(req['assigned_workers'])
                for project in projects_list
                for req in project['requisitions']
            )
        }

        # Generate PDF
        pdf_buffer = generate_daily_schedule_pdf(schedule_data)

        # Create filename
        filename = f"Daily_Worker_Schedule_{target_date.strftime('%Y%m%d')}.pdf"

        return send_file(
            pdf_buffer,
            mimetype='application/pdf',
            as_attachment=True,
            download_name=filename
        )

    except Exception as e:
        log.error(f"Error generating daily schedule PDF: {str(e)}")
        return jsonify({"error": f"Failed to generate PDF: {str(e)}"}), 500
