from flask import request, jsonify, g
from config.db import db
from models.project import Project
from models.boq import *
from models.preliminary_master import BOQPreliminary, BOQInternalRevision
from config.logging import get_logger
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm.attributes import flag_modified
from utils.boq_email_service import BOQEmailService
from models.user import User
from models.role import Role
from utils.admin_viewing_context import get_effective_user_context, should_apply_role_filter
from sqlalchemy import func, and_, or_
from config.change_request_config import CR_CONFIG


log = get_logger()


def validate_negotiable_margin_formula(client_amount, materials, labour, misc, overhead_profit, transport, calculated_margin):
    """
    Validate that negotiable margin follows the correct formula:
    Negotiable Margin = Client Amount - (Materials + Labour + Misc + O&P + Transport)

    Raises ValueError if formula is incorrect
    """
    expected_internal_cost = materials + labour + misc + overhead_profit + transport
    expected_margin = client_amount - expected_internal_cost

    # Allow small floating point differences (0.01)
    tolerance = 0.01
    difference = abs(expected_margin - calculated_margin)

    if difference > tolerance:
        error_msg = (
            f"Negotiable margin calculation error!\n"
            f"Expected: {expected_margin:.2f} "
            f"(Client: {client_amount:.2f} - Internal: {expected_internal_cost:.2f})\n"
            f"Got: {calculated_margin:.2f}\n"
            f"Difference: {difference:.2f}\n"
            f"Formula: Client Amount - (Materials + Labour + Misc + O&P + Transport)\n"
            f"Breakdown: {client_amount:.2f} - ({materials:.2f} + {labour:.2f} + {misc:.2f} + {overhead_profit:.2f} + {transport:.2f})"
        )
        log.error(error_msg)
        raise ValueError(error_msg)

    return True


def add_to_master_tables(item_name, description, work_type, materials_data, labour_data, created_by, miscellaneous_percentage=None, miscellaneous_amount=None, overhead_percentage=None, overhead_amount=None, profit_margin_percentage=None, profit_margin_amount=None, discount_percentage=None, discount_amount=None, vat_percentage=None, vat_amount=None, unit=None, quantity=None, per_unit_cost=None, total_amount=None, item_total_cost=None):
    """Add items, materials, and labour to master tables if they don't exist"""
    master_item_id = None
    master_material_ids = []
    master_labour_ids = []
    # Add to master items (prevent duplicates)
    master_item = MasterItem.query.filter_by(item_name=item_name).first()
    if not master_item:
        master_item = MasterItem(
            item_name=item_name,
            description=description,
            unit=unit,
            quantity=quantity,
            per_unit_cost=per_unit_cost,
            total_amount=total_amount,
            item_total_cost=item_total_cost,
            miscellaneous_percentage=miscellaneous_percentage,
            miscellaneous_amount=miscellaneous_amount,
            overhead_percentage=overhead_percentage,
            overhead_amount=overhead_amount,
            profit_margin_percentage=profit_margin_percentage,
            profit_margin_amount=profit_margin_amount,
            discount_percentage=discount_percentage,
            discount_amount=discount_amount,
            vat_percentage=vat_percentage,
            vat_amount=vat_amount,
            created_by=created_by
        )
        db.session.add(master_item)
        db.session.flush()
    else:
        # If item exists, update description, cost fields, and miscellaneous/profit values
        if description:
            master_item.description = description

        # Always update all fields with latest values (even if None)
        master_item.unit = unit
        master_item.quantity = quantity
        master_item.per_unit_cost = per_unit_cost
        master_item.total_amount = total_amount
        master_item.item_total_cost = item_total_cost
        master_item.miscellaneous_percentage = miscellaneous_percentage
        master_item.miscellaneous_amount = miscellaneous_amount
        master_item.overhead_percentage = overhead_percentage
        master_item.overhead_amount = overhead_amount
        master_item.profit_margin_percentage = profit_margin_percentage
        master_item.profit_margin_amount = profit_margin_amount
        master_item.discount_percentage = discount_percentage
        master_item.discount_amount = discount_amount
        master_item.vat_percentage = vat_percentage
        master_item.vat_amount = vat_amount

        db.session.flush()
    master_item_id = master_item.item_id

    # ✅ OPTIMIZED: Bulk query for materials (prevents N+1 queries)
    # BEFORE: 1 query per material = N+1 queries
    # AFTER: 1 bulk query for all materials
    material_names = [mat_data.get("material_name") for mat_data in materials_data]
    existing_materials = MasterMaterial.query.filter(
        MasterMaterial.material_name.in_(material_names)
    ).all()
    existing_materials_map = {mat.material_name: mat for mat in existing_materials}

    # Add to master materials (prevent duplicates) with item_id reference
    for mat_data in materials_data:
        material_name = mat_data.get("material_name")
        quantity = mat_data.get("quantity", 0.0)
        unit_price = mat_data.get("unit_price", 0.0)
        total_price = mat_data.get("total_price", quantity * unit_price)
        vat_percentage = mat_data.get("vat_percentage", 0.0)
        vat_amount = mat_data.get("vat_amount", 0.0)

        master_material = existing_materials_map.get(material_name)
        if not master_material:
            master_material = MasterMaterial(
                material_name=material_name,
                item_id=master_item_id,  # Set the item_id reference
                description=mat_data.get("description"),
                brand=mat_data.get("brand"),
                size=mat_data.get("size"),
                specification=mat_data.get("specification"),
                quantity=quantity,
                default_unit=mat_data.get("unit", "nos"),
                current_market_price=unit_price,
                total_price=total_price,
                vat_percentage=vat_percentage,
                vat_amount=vat_amount,
                created_by=created_by,
                last_modified_by=created_by
            )
            db.session.add(master_material)
            db.session.flush()
        else:
            # Update existing material: always update current_market_price and item_id if needed
            if master_material.item_id is None:
                master_material.item_id = master_item_id

            # Always update current_market_price with the new unit_price from BOQ
            master_material.description = mat_data.get("description")
            master_material.brand = mat_data.get("brand")
            master_material.size = mat_data.get("size")
            master_material.specification = mat_data.get("specification")
            master_material.quantity = quantity
            master_material.current_market_price = unit_price
            master_material.total_price = total_price
            master_material.vat_percentage = vat_percentage
            master_material.vat_amount = vat_amount
            master_material.last_modified_by = created_by

            # Update unit if different
            new_unit = mat_data.get("unit", "nos")
            if master_material.default_unit != new_unit:
                master_material.default_unit = new_unit

            db.session.flush()
        master_material_ids.append(master_material.material_id)

    # ✅ OPTIMIZED: Bulk query for labour (prevents N+1 queries)
    # BEFORE: 1 query per labour role = N+1 queries
    # AFTER: 1 bulk query for all labour roles
    labour_roles = [labour_data_item.get("labour_role") for labour_data_item in labour_data]
    existing_labour = MasterLabour.query.filter(
        MasterLabour.labour_role.in_(labour_roles)
    ).all()
    existing_labour_map = {labour.labour_role: labour for labour in existing_labour}

    # Add to master labour (prevent duplicates) with item_id reference
    for i, labour_data_item in enumerate(labour_data):
        labour_role = labour_data_item.get("labour_role")
        # Get hours and rate_per_hour
        rate_per_hour = labour_data_item.get("rate_per_hour", 0.0)
        hours = labour_data_item.get("hours", 0.0)
        labour_amount = float(rate_per_hour) * float(hours)

        master_labour = existing_labour_map.get(labour_role)

        if not master_labour:
            master_labour = MasterLabour(
                labour_role=labour_role,
                item_id=master_item_id,  # Set the item_id reference
                work_type=work_type,  # Set the work_type
                hours=float(hours),  # Store hours as float
                rate_per_hour=float(rate_per_hour),  # Store rate per hour as float
                amount=labour_amount,  # Set the calculated amount
                created_by=created_by
            )
            db.session.add(master_labour)
            db.session.flush()
        else:
            # Update existing labour: always update item_id, work_type, hours, rate_per_hour, and amount
            if master_labour.item_id is None:
                master_labour.item_id = master_item_id
            if master_labour.work_type is None and work_type:
                master_labour.work_type = work_type

            # Always update hours, rate_per_hour, and amount with the latest values
            master_labour.hours = float(hours)
            master_labour.rate_per_hour = float(rate_per_hour)
            master_labour.amount = labour_amount

            db.session.flush()
        master_labour_ids.append(master_labour.labour_id)

    return master_item_id, master_material_ids, master_labour_ids

def add_sub_items_to_master_tables(master_item_id, sub_items, created_by):
    """Add sub-items, their materials, and labour to master tables.

    Duplicate Prevention:
    - Sub-items: Checked globally by sub_item_name (case-insensitive)
    - Materials: Checked globally by material_name (case-insensitive)
    - Labour: Checked globally by labour_role (case-insensitive)

    If duplicate exists, we reuse the existing record and link it to the current sub-item.
    """
    master_sub_item_ids = []

    for sub_item in sub_items:
        sub_item_name = sub_item.get("sub_item_name", "").strip()
        if not sub_item_name:
            continue

        # Check if master sub-item already exists GLOBALLY by name (case-insensitive)
        # This prevents duplicate sub-item names across the entire system
        master_sub_item = MasterSubItem.query.filter(
            db.func.lower(MasterSubItem.sub_item_name) == sub_item_name.lower(),
            MasterSubItem.is_deleted == False
        ).first()

        if not master_sub_item:
            # Create new master sub-item (only if name doesn't exist globally)
            master_sub_item = MasterSubItem(
                item_id=master_item_id,
                sub_item_name=sub_item_name,
                description=sub_item.get("scope") or sub_item.get("description", ""),
                size=sub_item.get("size", ""),
                location=sub_item.get("location", ""),
                brand=sub_item.get("brand", ""),
                unit=sub_item.get("unit"),
                quantity=sub_item.get("quantity"),
                per_unit_cost=sub_item.get("per_unit_cost"),
                sub_item_total_cost=sub_item.get("sub_item_total_cost"),
                misc_percentage=sub_item.get("misc_percentage", 10.0),
                misc_amount=sub_item.get("misc_amount", 0.0),
                overhead_profit_percentage=sub_item.get("overhead_profit_percentage", 25.0),
                overhead_profit_amount=sub_item.get("overhead_profit_amount", 0.0),
                transport_percentage=sub_item.get("transport_percentage", 5.0),
                transport_amount=sub_item.get("transport_amount", 0.0),
                material_cost=sub_item.get("material_cost", 0.0),
                labour_cost=sub_item.get("labour_cost", 0.0),
                internal_cost=sub_item.get("internal_cost", 0.0),
                planned_profit=sub_item.get("planned_profit", 0.0),
                negotiable_margin=sub_item.get("negotiable_margin", 0.0),
                created_by=created_by
            )
            db.session.add(master_sub_item)
            db.session.flush()
            log.info(f"Created new master sub-item: '{sub_item_name}'")
        else:
            # Sub-item already exists - just log it, don't update (to preserve existing data)
            log.info(f"Sub-item '{sub_item_name}' already exists in master table (ID: {master_sub_item.sub_item_id})")

        master_sub_item_id = master_sub_item.sub_item_id
        master_sub_item_ids.append(master_sub_item_id)

        # Add materials for this sub-item
        materials = sub_item.get("materials", [])
        if materials:
            # Filter out materials with empty names
            material_names = [mat.get("material_name", "").strip().lower() for mat in materials if mat.get("material_name", "").strip()]

            # Query existing materials GLOBALLY by name (case-insensitive) to prevent duplicates
            existing_materials_map = {}
            if material_names:
                existing_materials = MasterMaterial.query.filter(
                    db.func.lower(MasterMaterial.material_name).in_(material_names),
                    MasterMaterial.is_active == True
                ).all()
                existing_materials_map = {mat.material_name.lower(): mat for mat in existing_materials}

            for mat in materials:
                material_name = mat.get("material_name", "").strip()
                if not material_name:
                    continue

                quantity = mat.get("quantity", 0.0)
                unit_price = mat.get("unit_price", 0.0)
                total_price = mat.get("total_price", quantity * unit_price)

                # Check if material exists GLOBALLY (case-insensitive)
                master_material = existing_materials_map.get(material_name.lower())
                if not master_material:
                    # Create new material only if it doesn't exist globally
                    master_material = MasterMaterial(
                        material_name=material_name,
                        item_id=master_item_id,
                        sub_item_id=master_sub_item_id,
                        description=mat.get("description"),
                        brand=mat.get("brand"),
                        size=mat.get("size"),
                        specification=mat.get("specification"),
                        quantity=quantity,
                        default_unit=mat.get("unit", "nos"),
                        current_market_price=unit_price,
                        total_price=total_price,
                        vat_percentage=mat.get("vat_percentage", 0.0),
                        vat_amount=mat.get("vat_amount", 0.0),
                        created_by=created_by,
                        last_modified_by=created_by
                    )
                    db.session.add(master_material)
                    db.session.flush()
                    log.info(f"Created new master material: '{material_name}'")
                else:
                    # Material already exists globally - just log it, don't create duplicate
                    log.info(f"Material '{material_name}' already exists in master table (ID: {master_material.material_id})")

        # Add labour for this sub-item
        labour_list = sub_item.get("labour", [])
        if labour_list:
            # Filter out labour with empty roles
            labour_roles = [labour.get("labour_role", "").strip().lower() for labour in labour_list if labour.get("labour_role", "").strip()]

            # Query existing labour GLOBALLY by role (case-insensitive) to prevent duplicates
            existing_labour_map = {}
            if labour_roles:
                existing_labour = MasterLabour.query.filter(
                    db.func.lower(MasterLabour.labour_role).in_(labour_roles),
                    MasterLabour.is_active == True
                ).all()
                existing_labour_map = {labour.labour_role.lower(): labour for labour in existing_labour}

            for labour in labour_list:
                labour_role = labour.get("labour_role", "").strip()
                if not labour_role:
                    continue

                rate_per_hour = labour.get("rate_per_hour", 0.0)
                hours = labour.get("hours", 0.0)
                labour_amount = float(rate_per_hour) * float(hours)

                # Check if labour_role exists GLOBALLY (case-insensitive)
                master_labour = existing_labour_map.get(labour_role.lower())

                if not master_labour:
                    # Create new labour only if it doesn't exist globally
                    master_labour = MasterLabour(
                        labour_role=labour_role,
                        item_id=master_item_id,
                        sub_item_id=master_sub_item_id,
                        work_type=labour.get("work_type", "daily_wages"),
                        hours=float(hours),
                        rate_per_hour=float(rate_per_hour),
                        amount=labour_amount,
                        created_by=created_by
                    )
                    db.session.add(master_labour)
                    db.session.flush()
                    log.info(f"Created new master labour: '{labour_role}'")
                else:
                    # Labour already exists globally - just log it, don't create duplicate
                    log.info(f"Labour '{labour_role}' already exists in master table (ID: {master_labour.labour_id})")

    return master_sub_item_ids

def clean_numeric_value(value):
    """Clean numeric values that might come wrapped in {source, parsedValue} objects"""
    if value is None:
        return 0.0

    # If it's a dict with parsedValue, extract it
    if isinstance(value, dict):
        if 'parsedValue' in value:
            return float(value['parsedValue']) if value['parsedValue'] is not None else 0.0
        if 'source' in value:
            try:
                return float(value['source'])
            except (ValueError, TypeError):
                return 0.0
        return 0.0

    # If it's already a number, return it
    try:
        return float(value)
    except (ValueError, TypeError):
        return 0.0

def create_boq():
    """Create a new BOQ using master tables and JSON storage"""
    try:
        data = request.get_json()
        project_id = data.get("project_id")

        # Validate required fields
        if not project_id:
            return jsonify({"error": "Project ID is required"}), 400

        if not data.get("boq_name"):
            return jsonify({"error": "BOQ name is required"}), 400

        # Check if project exists
        project = Project.query.filter_by(project_id=project_id).first()
        if not project:
            return jsonify({"error": "Project not found"}), 404

        # Check if an active (non-deleted) BOQ already exists for this project
        existing_boq = BOQ.query.filter_by(project_id=project_id, is_deleted=False).first()
        if existing_boq:
            return jsonify({
                "error": "A BOQ already exists for this project",
                "message": f"Project already has an active BOQ (ID: {existing_boq.boq_id}). Please edit the existing BOQ or delete it first.",
                "existing_boq_id": existing_boq.boq_id
            }), 400

        created_by = data.get("created_by", "Admin")
        project.status = data.get("project_status", "active")

        # Create BOQ
        boq = BOQ(
            project_id=project_id,
            boq_name=data.get("boq_name"),
            status=data.get("status", "active"),
            created_by=created_by,
        )
        db.session.add(boq)
        db.session.flush()  # Get boq_id

        # Process items and create JSON structure
        boq_items = []
        total_boq_cost = 0
        total_materials = 0
        total_labour = 0

        # Track processed items to prevent duplicates
        processed_item_names = set()

        for idx, item_data in enumerate(data.get("items", [])):
            item_name = item_data.get("item_name", "")

            # Skip if this item name was already processed (prevent duplicates)
            if item_name in processed_item_names:
                continue

            processed_item_names.add(item_name)
            # Initialize variables for this item iteration
            item_materials = []
            item_labour = []

            # Get item-level materials and labour
            item_level_materials = item_data.get("materials", [])
            item_level_labour = item_data.get("labour", [])

            # Get sub-items
            sub_items = item_data.get("sub_items", [])

            # Extract item-level cost fields from payload
            item_unit = item_data.get("unit")
            item_quantity = item_data.get("quantity")
            item_per_unit_cost = item_data.get("per_unit_cost")
            item_rate = item_data.get("rate", item_per_unit_cost)  # rate is alias for per_unit_cost
            item_total_amount = item_data.get("total_amount")  # Accept total_amount from payload

            # Use rate if per_unit_cost not provided
            if item_per_unit_cost is None and item_rate is not None:
                item_per_unit_cost = item_rate

            # Calculate base cost from materials and labour (item-level + sub-items)
            materials_cost = 0
            labour_cost = 0

            # Collect ALL materials from item-level
            all_materials = []
            for mat_data in item_level_materials:
                all_materials.append(mat_data)
                quantity = mat_data.get("quantity", 1.0)
                unit_price = mat_data.get("unit_price", 0.0)
                materials_cost += quantity * unit_price

            # Collect ALL labour from item-level
            all_labour = []
            for labour_data_item in item_level_labour:
                all_labour.append(labour_data_item)
                hours = labour_data_item.get("hours", 0.0)
                rate_per_hour = labour_data_item.get("rate_per_hour", 0.0)
                labour_cost += hours * rate_per_hour

            # Process sub-items and collect their materials and labour
            processed_sub_items = []
            for sub_item_idx, sub_item in enumerate(sub_items):
                sub_item_materials = []
                sub_item_labour = []
                sub_item_materials_cost = 0
                sub_item_labour_cost = 0

                # Process sub-item materials
                for mat_data in sub_item.get("materials", []):
                    all_materials.append(mat_data)
                    quantity = mat_data.get("quantity", 1.0)
                    unit_price = mat_data.get("unit_price", 0.0)
                    total_price = quantity * unit_price
                    materials_cost += total_price
                    sub_item_materials_cost += total_price

                    sub_item_materials.append({
                        "material_id": mat_data.get("material_id"),
                        "material_name": mat_data.get("material_name"),
                        "location": mat_data.get("location", ""),
                        "brand": mat_data.get("brand", ""),
                        "size": mat_data.get("size", ""),
                        "specification": mat_data.get("specification", ""),
                        "description": mat_data.get("description", ""),
                        "quantity": quantity,
                        "unit": mat_data.get("unit", "nos"),
                        "unit_price": unit_price,
                        "total_price": total_price
                    })

                # Process sub-item labour
                for labour_data_item in sub_item.get("labour", []):
                    all_labour.append(labour_data_item)
                    hours = labour_data_item.get("hours", 0.0)
                    rate_per_hour = labour_data_item.get("rate_per_hour", 0.0)
                    total_cost_labour = hours * rate_per_hour
                    labour_cost += total_cost_labour
                    sub_item_labour_cost += total_cost_labour

                    sub_item_labour.append({
                        "labour_role": labour_data_item.get("labour_role"),
                        "hours": hours,
                        "rate_per_hour": rate_per_hour,
                        "total_cost": total_cost_labour
                    })

                # Get per-sub-item percentages from payload or use config defaults
                misc_percentage = sub_item.get("misc_percentage", CR_CONFIG.DEFAULT_MISC_PERCENTAGE)
                overhead_profit_percentage = sub_item.get("overhead_profit_percentage", CR_CONFIG.DEFAULT_OVERHEAD_PROFIT_PERCENTAGE)
                transport_percentage = sub_item.get("transport_percentage", CR_CONFIG.DEFAULT_TRANSPORT_PERCENTAGE)

                # Calculate sub-item client amount
                sub_item_quantity = sub_item.get("quantity", 0)
                sub_item_rate = sub_item.get("rate", 0) or sub_item.get("per_unit_cost", 0)
                sub_item_client_amount = sub_item_quantity * sub_item_rate

                # Calculate percentage amounts (from client rate)
                misc_amount = sub_item_client_amount * (misc_percentage / 100)
                overhead_profit_amount = sub_item_client_amount * (overhead_profit_percentage / 100)
                transport_amount = sub_item_client_amount * (transport_percentage / 100)

                # Calculate internal cost (materials + labour)
                sub_item_internal_cost = sub_item_materials_cost + sub_item_labour_cost

                # Calculate profits
                planned_profit = overhead_profit_amount
                # Negotiable Margin = Client Amount - (Materials + Labour + Misc + O&P + Transport)
                negotiable_margin = sub_item_client_amount - sub_item_internal_cost - misc_amount - overhead_profit_amount - transport_amount

                # Validate the calculation
                try:
                    validate_negotiable_margin_formula(
                        client_amount=sub_item_client_amount,
                        materials=sub_item_materials_cost,
                        labour=sub_item_labour_cost,
                        misc=misc_amount,
                        overhead_profit=overhead_profit_amount,
                        transport=transport_amount,
                        calculated_margin=negotiable_margin
                    )
                except ValueError as e:
                    log.warning(f"Negotiable margin validation failed for sub-item: {e}")

                # Store processed sub-item
                processed_sub_items.append({
                    "sub_item_name": sub_item.get("sub_item_name"),
                    "description": sub_item.get("scope", ""),
                    "size": sub_item.get("size", ""),
                    "location": sub_item.get("location", ""),
                    "brand": sub_item.get("brand", ""),
                    "unit": sub_item.get("unit"),
                    "quantity": sub_item_quantity,
                    "per_unit_cost": sub_item_rate,
                    "rate": sub_item_rate,
                    "sub_item_total": sub_item_client_amount,

                    # Per-sub-item percentages
                    "misc_percentage": misc_percentage,
                    "misc_amount": misc_amount,
                    "overhead_profit_percentage": overhead_profit_percentage,
                    "overhead_profit_amount": overhead_profit_amount,
                    "transport_percentage": transport_percentage,
                    "transport_amount": transport_amount,

                    # Cost breakdown
                    "materials": sub_item_materials,
                    "labour": sub_item_labour,
                    "material_cost": sub_item_materials_cost,
                    "labour_cost": sub_item_labour_cost,
                    "internal_cost": sub_item_internal_cost,
                    "planned_profit": planned_profit,
                    "negotiable_margin": negotiable_margin,

                    # Legacy fields for backward compatibility
                    "total_materials_cost": sub_item_materials_cost,
                    "total_labour_cost": sub_item_labour_cost,
                    "total_cost": sub_item_materials_cost + sub_item_labour_cost
                })

            # Calculate base_cost from sub-items or from item-level quantity * rate
            sub_items_base_cost = materials_cost + labour_cost

            # Determine base cost: Priority: total_amount > (quantity * rate) > sub-items
            item_total_cost_field = None
            if item_total_amount is not None:
                # Use total_amount directly from payload
                base_cost = float(item_total_amount)
                item_total_cost_field = float(item_total_amount)
            elif item_quantity is not None and item_per_unit_cost is not None:
                # Calculate from quantity * rate
                item_total_cost_field = float(item_quantity) * float(item_per_unit_cost)
                base_cost = item_total_cost_field
            else:
                # Use sub-items cost
                base_cost = sub_items_base_cost
                item_total_cost_field = sub_items_base_cost

            # Get percentages and amounts from payload
            miscellaneous_percentage = item_data.get("miscellaneous_percentage", 0.0)
            overhead_percentage = item_data.get("overhead_percentage", 0.0)
            profit_margin_percentage = item_data.get("profit_margin_percentage", 0.0)
            discount_percentage = item_data.get("discount_percentage", 0.0)
            vat_percentage = item_data.get("vat_percentage", 0.0)

            # Check if amounts are provided in payload, if yes use them, else calculate
            if item_data.get("miscellaneous_amount") is not None:
                miscellaneous_amount = float(item_data.get("miscellaneous_amount"))
            else:
                miscellaneous_amount = (base_cost * float(miscellaneous_percentage)) / 100 if miscellaneous_percentage else 0.0

            cost_after_misc = base_cost + miscellaneous_amount

            # Overhead amount (separate from profit margin)
            if item_data.get("overhead_amount") is not None:
                overhead_amount = float(item_data.get("overhead_amount"))
            else:
                overhead_amount = (base_cost * float(overhead_percentage)) / 100 if overhead_percentage else 0.0

            # Profit margin amount (separate from overhead)
            if item_data.get("profit_margin_amount") is not None:
                profit_margin_amount = float(item_data.get("profit_margin_amount"))
            else:
                profit_margin_amount = (base_cost * float(profit_margin_percentage)) / 100 if profit_margin_percentage else 0.0

            # Total after adding overhead and profit
            total_cost = base_cost + miscellaneous_amount + profit_margin_amount
            selling_price_before_discount = total_cost

            # Discount amount
            if item_data.get("discount_amount") is not None:
                discount_amount = float(item_data.get("discount_amount"))
            else:
                discount_amount = (selling_price_before_discount * float(discount_percentage)) / 100 if discount_percentage else 0.0

            after_discount = selling_price_before_discount - discount_amount

            # VAT - Apply on the final amount after discount (based on after_discount amount)
            if item_data.get("vat_amount") is not None:
                # Use provided VAT amount
                vat_amount = float(item_data.get("vat_amount"))
            else:
                # Calculate VAT on after_discount amount
                vat_amount = (after_discount * float(vat_percentage)) / 100 if vat_percentage else 0.0

            final_selling_price = after_discount + vat_amount
            # Now add to master tables with calculated values (using ALL materials and labour)
            # Use project's work_type as default instead of hardcoded "contract"
            default_work_type = project.work_type if project and project.work_type else "contract"
            master_item_id, master_material_ids, master_labour_ids = add_to_master_tables(
                item_data.get("item_name"),
                item_data.get("description"),
                item_data.get("work_type", default_work_type),
                all_materials,
                all_labour,
                created_by,
                miscellaneous_percentage,
                miscellaneous_amount,
                overhead_percentage,
                overhead_amount,
                profit_margin_percentage,
                profit_margin_amount,
                discount_percentage,
                discount_amount,
                vat_percentage,
                vat_amount,
                unit=item_unit,
                quantity=item_quantity,
                per_unit_cost=item_per_unit_cost,
                total_amount=item_total_amount,
                item_total_cost=item_total_cost_field
            )

            # Add sub-items to master tables (if any) and update processed_sub_items with master IDs
            master_sub_item_ids = []
            if sub_items:
                master_sub_item_ids = add_sub_items_to_master_tables(master_item_id, sub_items, created_by)

                # Add master_sub_item_id to each processed sub-item
                for idx, processed_sub_item in enumerate(processed_sub_items):
                    if idx < len(master_sub_item_ids):
                        processed_sub_item["master_sub_item_id"] = master_sub_item_ids[idx]
            # Check if item has sub_items structure (new format)
            has_sub_items = "sub_items" in item_data and item_data.get("sub_items")

            if has_sub_items:
                # NEW FORMAT: Process items with sub_items structure
                sub_items_list = []
                materials_count = 0
                labour_count = 0

                # Get item-level quantity and rate - THIS is the base for calculations!
                item_quantity = clean_numeric_value(item_data.get("quantity", 1.0))
                item_rate = clean_numeric_value(item_data.get("rate", 0.0))
                item_unit = item_data.get("unit", "nos")

                # Calculate item_total from item-level quantity × rate (NOT sub-items!)
                item_total = item_quantity * item_rate

                # Get item-level percentages
                # overhead_percentage is labeled as "Miscellaneous" in UI
                # profit_margin_percentage is labeled as "Overhead & Profit" in UI
                miscellaneous_percentage = clean_numeric_value(item_data.get("overhead_percentage", 10.0))
                overhead_profit_percentage = clean_numeric_value(item_data.get("profit_margin_percentage", 15.0))
                discount_percentage = clean_numeric_value(item_data.get("discount_percentage", 0.0))
                vat_percentage = clean_numeric_value(item_data.get("vat_percentage", 0.0))

                # Calculate ALL amounts based on item-level total (NOT sub-items!)
                total_miscellaneous_amount = (item_total * miscellaneous_percentage) / 100
                total_overhead_profit_amount = (item_total * overhead_profit_percentage) / 100
                total_subtotal = item_total + total_miscellaneous_amount + total_overhead_profit_amount
                total_discount_amount = (total_subtotal * discount_percentage) / 100 if discount_percentage > 0 else 0.0
                total_after_discount = total_subtotal - total_discount_amount
                total_vat_amount = (total_after_discount * vat_percentage) / 100 if vat_percentage > 0 else 0.0
                total_selling_price = total_after_discount + total_vat_amount

                for sub_item_data in item_data.get("sub_items", []):
                    # Get sub-item fields (just for material/labour breakdown)
                    sub_item_quantity = clean_numeric_value(sub_item_data.get("quantity", 1.0))
                    sub_item_unit = sub_item_data.get("unit", "nos")
                    sub_item_rate = clean_numeric_value(sub_item_data.get("rate", 0.0))
                    sub_item_base_total = sub_item_quantity * sub_item_rate

                    # Process materials for this sub-item
                    sub_item_materials = []
                    materials_cost = 0
                    for mat_data in sub_item_data.get("materials", []):
                        quantity = clean_numeric_value(mat_data.get("quantity", 1.0))
                        unit_price = clean_numeric_value(mat_data.get("unit_price", 0.0))
                        total_price = quantity * unit_price
                        materials_cost += total_price

                        sub_item_materials.append({
                            "material_id": mat_data.get("material_id"),
                            "material_name": mat_data.get("material_name"),
                            "location": mat_data.get("location", ""),
                            "brand": mat_data.get("brand", ""),
                            "size": mat_data.get("size", ""),
                            "specification": mat_data.get("specification", ""),
                            "description": mat_data.get("description", ""),
                            "quantity": quantity,
                            "unit": mat_data.get("unit", "nos"),
                            "unit_price": unit_price,
                            "total_price": total_price,
                            "vat_percentage": clean_numeric_value(mat_data.get("vat_percentage", 0.0))
                        })

                    # Process labour for this sub-item
                    sub_item_labour = []
                    labour_cost = 0
                    for labour_data_item in sub_item_data.get("labour", []):
                        hours = clean_numeric_value(labour_data_item.get("hours", 0.0))
                        rate_per_hour = clean_numeric_value(labour_data_item.get("rate_per_hour", 0.0))
                        total_cost_labour = hours * rate_per_hour
                        labour_cost += total_cost_labour

                        sub_item_labour.append({
                            "labour_role": labour_data_item.get("labour_role"),
                            "hours": hours,
                            "rate_per_hour": rate_per_hour,
                            "total_cost": total_cost_labour
                        })

                    # Create sub-item JSON (stores only material/labour breakdown, NOT pricing)
                    sub_item_json = {
                        "sub_item_name": sub_item_data.get("sub_item_name"),
                        "scope": sub_item_data.get("scope", ""),
                        "size": sub_item_data.get("size", ""),
                        "description": sub_item_data.get("description", ""),
                        "location": sub_item_data.get("location", ""),
                        "brand": sub_item_data.get("brand", ""),
                        "quantity": sub_item_quantity,
                        "unit": sub_item_unit,
                        "rate": sub_item_rate,
                        "base_total": sub_item_base_total,
                        "materials_cost": materials_cost,
                        "labour_cost": labour_cost,
                        "materials": sub_item_materials,
                        "labour": sub_item_labour
                    }

                    sub_items_list.append(sub_item_json)
                    materials_count += len(sub_item_materials)
                    labour_count += len(sub_item_labour)

                # Add sub-items to master tables and get IDs
                master_sub_item_ids = add_sub_items_to_master_tables(master_item_id, item_data.get("sub_items", []), created_by)

                # Add sub_item_id to each sub-item in the list
                for idx, sub_item in enumerate(sub_items_list):
                    if idx < len(master_sub_item_ids):
                        sub_item["sub_item_id"] = master_sub_item_ids[idx]
                        sub_item["master_sub_item_id"] = master_sub_item_ids[idx]

                # Calculate total materials and labour costs from all sub-items
                total_materials_cost = sum(si.get("materials_cost", 0) for si in sub_items_list)
                total_labour_cost = sum(si.get("labour_cost", 0) for si in sub_items_list)
                base_cost = total_materials_cost + total_labour_cost

                # Create parent item with sub_items
                item_json = {
                    "item_name": item_data.get("item_name"),
                    "description": item_data.get("description", ""),
                    "work_type": item_data.get("work_type", default_work_type),
                    "has_sub_items": True,
                    "sub_items": sub_items_list,
                    "quantity": item_quantity,
                    "unit": item_unit,
                    "rate": item_rate,
                    "item_total": item_total,
                    "base_cost": base_cost,
                    "sub_items_cost": base_cost,
                    "total_selling_price": total_selling_price,
                    "selling_price": total_selling_price,
                    "estimatedSellingPrice": total_selling_price,
                    "actualItemCost": base_cost,
                    "total_cost": total_selling_price,
                    "overhead_percentage": miscellaneous_percentage,  # Labeled as "Miscellaneous" in UI
                    "overhead_amount": total_miscellaneous_amount,
                    "profit_margin_percentage": overhead_profit_percentage,  # Labeled as "Overhead & Profit" in UI
                    "profit_margin_amount": total_overhead_profit_amount,
                    "subtotal": total_subtotal,
                    "discount_percentage": discount_percentage,
                    "discount_amount": total_discount_amount,
                    "vat_percentage": vat_percentage,
                    "vat_amount": total_vat_amount,
                    "after_discount": total_after_discount,
                    "total_materials": materials_count,
                    "total_labour": labour_count,
                    "totalMaterialCost": total_materials_cost,
                    "totalLabourCost": total_labour_cost,
                    "materials": item_materials,
                    "labour": item_labour
                }

                boq_items.append(item_json)
                total_boq_cost += total_selling_price
                total_materials += materials_count
                total_labour += labour_count

            else:
                # EXISTING FORMAT: Original flat structure (backwards compatible)
                materials_data = item_data.get("materials", [])
                labour_data = item_data.get("labour", [])

                # Get item-level fields (quantity, unit, rate) - CLEAN wrapped values
                item_quantity = clean_numeric_value(item_data.get("quantity", 1.0))
                item_unit = item_data.get("unit", "nos")
                item_rate = clean_numeric_value(item_data.get("rate", 0.0))

                # Calculate item total from quantity × rate
                item_total = item_quantity * item_rate

                # Use provided percentages from frontend - CLEAN wrapped values
                miscellaneous_percentage = clean_numeric_value(item_data.get("overhead_percentage", 10.0))
                profit_margin_percentage = clean_numeric_value(item_data.get("profit_margin_percentage", 15.0))

                # NEW CALCULATION: miscellaneous and profit margin are based on ITEM TOTAL (qty × rate), NOT subitems
                miscellaneous_amount = (item_total * miscellaneous_percentage) / 100
                profit_margin_amount = (item_total * profit_margin_percentage) / 100
                before_discount = item_total + miscellaneous_amount + profit_margin_amount

                # Handle discount after miscellaneous and overhead - CLEAN wrapped values
                discount_percentage = clean_numeric_value(item_data.get("discount_percentage", 0.0))
                discount_amount = 0.0
                after_discount = before_discount

                if discount_percentage > 0:
                    discount_amount = (before_discount * discount_percentage) / 100
                    after_discount = before_discount - discount_amount

                # Handle VAT on final amount - CLEAN wrapped values
                vat_percentage = clean_numeric_value(item_data.get("vat_percentage", 0.0))
                vat_amount = 0.0
                final_selling_price = after_discount

                if vat_percentage > 0:
                    vat_amount = (after_discount * vat_percentage) / 100
                    final_selling_price = after_discount + vat_amount

                # Also calculate sub-items cost for reference - CLEAN wrapped values
                materials_cost = 0
                for mat_data in materials_data:
                    quantity = clean_numeric_value(mat_data.get("quantity", 1.0))
                    unit_price = clean_numeric_value(mat_data.get("unit_price", 0.0))
                    materials_cost += quantity * unit_price

                labour_cost = 0
                for labour_data_item in labour_data:
                    hours = clean_numeric_value(labour_data_item.get("hours", 0.0))
                    rate_per_hour = clean_numeric_value(labour_data_item.get("rate_per_hour", 0.0))
                    labour_cost += hours * rate_per_hour

                sub_items_total = materials_cost + labour_cost

                # Now add to master tables with calculated values
                master_item_id, master_material_ids, master_labour_ids = add_to_master_tables(
                    item_data.get("item_name"),
                    item_data.get("description"),
                    item_data.get("work_type", default_work_type),
                    materials_data,
                    labour_data,
                    created_by,
                    miscellaneous_percentage,
                    miscellaneous_amount,
                    miscellaneous_percentage,  # overhead_percentage = miscellaneous
                    miscellaneous_amount,  # overhead_amount = miscellaneous
                    profit_margin_percentage,
                    profit_margin_amount
                )

                # Process materials for BOQ details (from all_materials with master IDs) - CLEAN wrapped values
                item_materials = []
                for i, mat_data in enumerate(all_materials):
                    quantity = clean_numeric_value(mat_data.get("quantity", 1.0))
                    unit_price = clean_numeric_value(mat_data.get("unit_price", 0.0))
                    total_price = quantity * unit_price
                    vat_pct = clean_numeric_value(mat_data.get("vat_percentage", 0.0))

                    item_materials.append({
                        "master_material_id": master_material_ids[i] if i < len(master_material_ids) else None,
                        "material_name": mat_data.get("material_name"),
                    "location": mat_data.get("location", ""),
                    "brand": mat_data.get("brand", ""),
                        "size": mat_data.get("size", ""),
                        "specification": mat_data.get("specification", ""),
                        "description": mat_data.get("description", ""),
                        "quantity": quantity,
                        "unit": mat_data.get("unit", "nos"),
                        "unit_price": unit_price,
                        "total_price": total_price,
                        "vat_percentage": vat_pct
                    })

                # Process labour for BOQ details (from all_labour with master IDs) - CLEAN wrapped values
                item_labour = []
                for i, labour_data_item in enumerate(all_labour):
                    hours = clean_numeric_value(labour_data_item.get("hours", 0.0))
                    rate_per_hour = clean_numeric_value(labour_data_item.get("rate_per_hour", 0.0))
                    total_cost_labour = hours * rate_per_hour

                    item_labour.append({
                        "master_labour_id": master_labour_ids[i] if i < len(master_labour_ids) else None,
                        "labour_role": labour_data_item.get("labour_role"),
                        "hours": hours,
                        "rate_per_hour": rate_per_hour,
                        "total_cost": total_cost_labour
                    })

        # Get preliminaries from request data
        from models.preliminary_master import BOQPreliminary

        preliminaries = data.get("preliminaries", {})
        preliminary_id = None

        # Prepare preliminary selections to save to boq_preliminaries junction table
        preliminary_selections_to_save = []
        if preliminaries and preliminaries.get('items'):
            preliminary_items = preliminaries.get('items', [])
            log.info(f"Processing {len(preliminary_items)} preliminary items from request")

            for item in preliminary_items:
                prelim_id = item.get('prelim_id')
                is_checked = item.get('checked', False) or item.get('selected', False)
                is_custom = item.get('isCustom', False)

                log.info(f"Preliminary item: prelim_id={prelim_id}, checked={is_checked}, isCustom={is_custom}, item={item}")

                # Handle edited master preliminaries - update the master record
                if prelim_id and not is_custom:
                    description = item.get('description', '')
                    if description:
                        # Check if description was changed from master
                        from models.preliminary_master import PreliminaryMaster
                        master_prelim = PreliminaryMaster.query.get(prelim_id)
                        if master_prelim and master_prelim.description != description:
                            # Update the master preliminary description
                            master_prelim.description = description
                            master_prelim.updated_by = 'Estimator'
                            log.info(f"[CREATE_BOQ] Updated master preliminary: prelim_id={prelim_id}, new description={description}")

                # Handle custom preliminaries - create new row in preliminaries_master
                if is_custom and not prelim_id:
                    from models.preliminary_master import PreliminaryMaster
                    description = item.get('description', '')
                    name = item.get('name', description[:50] if description else 'Custom Item')

                    if description:  # Only create if there's a description
                        # Check if this custom preliminary already exists (by description)
                        existing_custom = PreliminaryMaster.query.filter_by(
                            description=description,
                            created_by='Estimator'
                        ).first()

                        if existing_custom:
                            prelim_id = existing_custom.prelim_id
                            log.info(f"[CREATE_BOQ] Found existing custom preliminary: prelim_id={prelim_id}")
                        else:
                            # Create new custom preliminary in master table
                            new_custom_prelim = PreliminaryMaster(
                                name=name,
                                description=description,
                                unit='nos',
                                rate=0,
                                is_active=True,
                                display_order=9999,  # Custom items appear at the end
                                created_by='Estimator',
                                updated_by='Estimator'
                            )
                            db.session.add(new_custom_prelim)
                            db.session.flush()  # Get the prelim_id
                            prelim_id = new_custom_prelim.prelim_id
                            log.info(f"[CREATE_BOQ] Created new custom preliminary: prelim_id={prelim_id}, description={description}")

                if prelim_id:
                    preliminary_selections_to_save.append({
                        'prelim_id': prelim_id,
                        'is_checked': is_checked
                    })

            log.info(f"Prepared {len(preliminary_selections_to_save)} preliminary selections for saving: {preliminary_selections_to_save}")

        # Apply BOQ-level discount to total
        boq_discount_percentage = data.get("discount_percentage", 0) or 0
        boq_discount_amount = data.get("discount_amount", 0) or 0

        # Get preliminary amount to include in discount calculation
        preliminary_amount = preliminaries.get('cost_details', {}).get('amount', 0) if preliminaries else 0

        # Combined subtotal = items total + preliminary amount
        combined_subtotal = total_boq_cost + preliminary_amount

        # Calculate discount amount if only percentage is provided
        # Discount should be calculated on combined subtotal (items + preliminaries)
        if boq_discount_amount == 0 and boq_discount_percentage > 0 and combined_subtotal > 0:
            boq_discount_amount = combined_subtotal * (boq_discount_percentage / 100)

        # Apply BOQ-level discount to get final total
        final_boq_cost = combined_subtotal - boq_discount_amount if boq_discount_amount > 0 else combined_subtotal

        log.info(f"BOQ {boq.boq_id} create totals - Items: {total_boq_cost}, Preliminaries: {preliminary_amount}, Combined: {combined_subtotal}, Discount: {boq_discount_amount} ({boq_discount_percentage}%), Final: {final_boq_cost}")

        # Calculate total negotiable margin from all sub-items
        total_negotiable_margin = 0.0
        total_planned_profit = 0.0
        total_misc_amount = 0.0
        total_overhead_profit_amount = 0.0
        total_transport_amount = 0.0

        for item in boq_items:
            if item.get("has_sub_items") and item.get("sub_items"):
                for sub_item in item["sub_items"]:
                    total_negotiable_margin += sub_item.get("negotiable_margin", 0.0)
                    total_planned_profit += sub_item.get("planned_profit", 0.0)
                    total_misc_amount += sub_item.get("misc_amount", 0.0)
                    total_overhead_profit_amount += sub_item.get("overhead_profit_amount", 0.0)
                    total_transport_amount += sub_item.get("transport_amount", 0.0)

        log.info(f"BOQ {boq.boq_id} profit breakdown - Negotiable Margin: {total_negotiable_margin}, Planned Profit (O&P): {total_planned_profit}, Misc: {total_misc_amount}, Transport: {total_transport_amount}")

        # Create BOQ details JSON (without terms - stored in junction table)
        boq_details_json = {
            "boq_id": boq.boq_id,
            "preliminaries": preliminaries,
            "preliminary_id": preliminary_id,  # Reference to preliminaries table
            "discount_percentage": boq_discount_percentage,
            "discount_amount": boq_discount_amount,
            "items": boq_items,
            "summary": {
                "total_items": len(boq_items),
                "total_materials": total_materials,
                "total_labour": total_labour,
                "total_material_cost": sum(item["totalMaterialCost"] for item in boq_items),
                "total_labour_cost": sum(item["totalLabourCost"] for item in boq_items),
                "total_cost": final_boq_cost,
                "selling_price": final_boq_cost,
                "estimatedSellingPrice": final_boq_cost,
                "actual_profit": round(total_negotiable_margin, 2),
                "negotiable_margin": round(total_negotiable_margin, 2),
                "planned_profit": round(total_planned_profit, 2),
                "total_misc": round(total_misc_amount, 2),
                "total_overhead_profit": round(total_overhead_profit_amount, 2),
                "total_transport": round(total_transport_amount, 2)
            }
        }

        # Save BOQ details
        boq_details = BOQDetails(
            boq_id=boq.boq_id,
            boq_details=boq_details_json,
            total_cost=final_boq_cost,
            total_items=len(boq_items),
            total_materials=total_materials,
            total_labour=total_labour,
            created_by=created_by
        )
        db.session.add(boq_details)
        db.session.flush()  # Flush to get IDs

        # Save preliminary selections to boq_preliminaries junction table
        if preliminary_selections_to_save:
            for selection in preliminary_selections_to_save:
                boq_prelim = BOQPreliminary(
                    boq_id=boq.boq_id,
                    prelim_id=selection['prelim_id'],
                    is_checked=selection['is_checked']
                )
                db.session.add(boq_prelim)

            log.info(f"Saved {len(preliminary_selections_to_save)} preliminary selections to boq_preliminaries for BOQ {boq.boq_id}")

        # Save terms & conditions selections to boq_terms_selections (single row with term_ids array)
        terms_conditions = data.get("terms_conditions", [])
        log.info(f"Received terms_conditions payload: {len(terms_conditions) if terms_conditions else 0} terms")

        if terms_conditions and isinstance(terms_conditions, list):
            from sqlalchemy import text
            # Extract only checked term IDs
            selected_term_ids = [
                term.get('term_id') for term in terms_conditions
                if term.get('term_id') and term.get('checked', False)
            ]

            # Insert or update single row with term_ids array
            db.session.execute(text("""
                INSERT INTO boq_terms_selections (boq_id, term_ids, created_at, updated_at)
                VALUES (:boq_id, :term_ids, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                ON CONFLICT (boq_id)
                DO UPDATE SET term_ids = :term_ids, updated_at = CURRENT_TIMESTAMP
            """), {
                'boq_id': boq.boq_id,
                'term_ids': selected_term_ids
            })

            log.info(f"✅ Saved {len(selected_term_ids)} terms selections to boq_terms_selections for BOQ {boq.boq_id}")
        else:
            log.warning(f"No terms_conditions in payload for BOQ {boq.boq_id}")

        db.session.commit()

        log.info(f"BOQ {boq.boq_id} created successfully with {len(boq_items)} items and {len(preliminary_selections_to_save)} preliminary selections")

        return jsonify({
            "message": "BOQ created successfully",
            "boq": {
                "boq_id": boq.boq_id,
                "boq_name": boq.boq_name,
                "project_id": boq.project_id,
                "status": boq.status,
                "total_cost": total_boq_cost,
                "items_count": len(boq_items),
                "materials_count": total_materials,
                "labour_count": total_labour,
                "selling_price": total_boq_cost,
                "estimatedSellingPrice": total_boq_cost
            }
        }), 201

    except SQLAlchemyError as e:
        db.session.rollback()
        log.error(f"Database error creating BOQ: {str(e)}")
        return jsonify({"error": f"Database error: {str(e)}"}), 500
    except Exception as e:
        db.session.rollback()
        log.error(f"Error creating BOQ: {str(e)}")
        return jsonify({"error": f"Error: {str(e)}"}), 500

def get_boq(boq_id):
    """Get BOQ details from JSON storage with existing and new purchases separated"""
    try:
        boq = BOQ.query.filter_by(boq_id=boq_id).first()
        if not boq:
            return jsonify({"error": "BOQ not found"}), 404

        # Get BOQ details from JSON
        boq_details = BOQDetails.query.filter_by(boq_id=boq_id).first()
        if not boq_details:
            return jsonify({"error": "BOQ details not found"}), 404

        # Get current user for role-based access control
        # Support admin viewing as another role
        current_user = getattr(g, 'user', None)
        user_role = ''
        user_role_id = None
        actual_role = ''

        if current_user:
            # Get the actual role from JWT
            role_name = current_user.get('role') or current_user.get('role_name', '')
            actual_role = role_name.lower().replace(' ', '').replace('_', '') if isinstance(role_name, str) else ''
            user_role_id = current_user.get('role_id')

            # Check if admin is viewing as another role
            context = get_effective_user_context()
            effective_role = context.get('effective_role', actual_role)

            # Use effective role for access control (handles admin viewing as PM)
            user_role = effective_role.lower().replace(' ', '').replace('_', '') if isinstance(effective_role, str) else ''

            log.info(f"BOQ {boq_id} - User access: actual_role='{actual_role}', effective_role='{user_role}', is_admin_viewing={context.get('is_admin_viewing', False)}")
        # Fetch project details
        project = Project.query.filter_by(project_id=boq.project_id).first()
        # Get BOQ history to track which items were added via new_purchase
        # ✅ PERFORMANCE: Limit history to last 200 entries (sufficient for tracking new purchases)
        boq_history = BOQHistory.query.filter_by(boq_id=boq_id).order_by(BOQHistory.action_date.desc()).limit(200).all()
        boq_history.reverse()  # Restore ascending order for processing
        # Track newly added items using master_item_id and item_name from history
        new_purchase_item_ids = set()  # Track by master_item_id
        new_purchase_item_names = set()  # Track by item_name as fallback
        original_item_count = 0

        for history in boq_history:
            if history.action:
                actions = history.action if isinstance(history.action, list) else [history.action]
                for action in actions:
                    if isinstance(action, dict):
                        action_type = action.get("type")
                        if action_type == "add_new_purchase":
                            # Get item identifiers from history (new minimal format)
                            item_identifiers = action.get("item_identifiers", [])

                            # If item_identifiers exists (new minimal format), use it
                            if item_identifiers:
                                for identifier in item_identifiers:
                                    master_item_id = identifier.get("master_item_id")
                                    item_name = identifier.get("item_name")

                                    if master_item_id:
                                        new_purchase_item_ids.add(master_item_id)
                                    if item_name:
                                        new_purchase_item_names.add(item_name)
                            else:
                                # Fallback to old formats for backward compatibility
                                # Try items_details first (medium format)
                                items_details = action.get("items_details", [])
                                if items_details:
                                    for item_detail in items_details:
                                        master_item_id = item_detail.get("master_item_id")
                                        item_name = item_detail.get("item_name")

                                        if master_item_id:
                                            new_purchase_item_ids.add(master_item_id)
                                        if item_name:
                                            new_purchase_item_names.add(item_name)
                                else:
                                    # Fallback to items_added (old format)
                                    items_added = action.get("items_added", [])
                                    for item_info in items_added:
                                        item_name = item_info.get("item_name")
                                        if item_name:
                                            new_purchase_item_names.add(item_name)

        # Get all items from BOQ details
        all_items = []
        if boq_details.boq_details and "items" in boq_details.boq_details:
            all_items = boq_details.boq_details["items"]
        # If no history of new purchases, determine original items count from first creation
        if not new_purchase_item_ids and not new_purchase_item_names and boq_history:
            # Find the creation action to determine original item count
            for history in boq_history:
                if history.action:
                    actions = history.action if isinstance(history.action, list) else [history.action]
                    for action in actions:
                        if isinstance(action, dict) and action.get("type") in ["boq_created", "created"]:
                            original_item_count = action.get("items_count", len(all_items))
                            break
                if original_item_count > 0:
                    break

        # Separate existing and new purchases
        existing_purchase_items = []
        new_add_purchase_items = []

        for idx, item in enumerate(all_items):
            master_item_id = item.get("master_item_id")
            item_name = item.get("item_name")
            is_new_purchase = False

            # Check if item is a new purchase
            # Priority 0: Check if item has is_extra_purchase flag (from approved change requests)
            if item.get("is_extra_purchase"):
                is_new_purchase = True
            # Priority 1: Match by master_item_id (most reliable)
            elif master_item_id and master_item_id in new_purchase_item_ids:
                is_new_purchase = True
            # Priority 2: Match by item_name (fallback)
            elif item_name and item_name in new_purchase_item_names:
                is_new_purchase = True
            # Priority 3: Use original item count position
            elif not new_purchase_item_ids and not new_purchase_item_names and original_item_count > 0:
                if idx >= original_item_count:
                    is_new_purchase = True

            # Ensure purchase_tracking exists in item
            if "purchase_tracking" not in item:
                item["purchase_tracking"] = {
                    "total_purchased_amount": 0.0,
                    "purchased_materials": []
                }

            # Add to appropriate list
            if is_new_purchase:
                new_add_purchase_items.append(item)
            else:
                existing_purchase_items.append(item)

        # Calculate summary for existing purchases
        existing_material_cost = 0
        existing_labour_cost = 0
        existing_materials_count = 0
        existing_labour_count = 0
        existing_total_cost = 0

        for item in existing_purchase_items:
            existing_total_cost += item.get("selling_price", 0)
            existing_material_cost += item.get("totalMaterialCost", 0)
            existing_labour_cost += item.get("totalLabourCost", 0)
            existing_materials_count += len(item.get("materials", []))
            existing_labour_count += len(item.get("labour", []))
        # Calculate summary for new purchases
        new_material_cost = 0
        new_labour_cost = 0
        new_materials_count = 0
        new_labour_count = 0
        new_total_cost = 0

        for item in new_add_purchase_items:
            new_total_cost += item.get("selling_price", 0)
            new_material_cost += item.get("totalMaterialCost", 0)
            new_labour_cost += item.get("totalLabourCost", 0)
            new_materials_count += len(item.get("materials", []))
            new_labour_count += len(item.get("labour", []))
        # Role-based access control for new purchase items
        # Determine if user can view new purchase details based on status and role
        # Admin always has access (both direct admin and admin viewing as another role)
        can_view_new_purchase = False
        boq_status = boq.status.lower() if boq.status else ''

        # Admin has full access
        if actual_role == 'admin':
            can_view_new_purchase = True
            log.info(f"BOQ {boq_id} - Admin access GRANTED for status '{boq_status}'")
        elif boq_status in ['new_purchase_create', 'sent_for_review']:
            # Only Project Manager can view when purchase is created or sent for review
            if user_role in ['projectmanager', 'project_manager']:
                can_view_new_purchase = True
            else:
                log.info(f"BOQ {boq_id} - Access DENIED: Only PM can view '{boq_status}', current role: '{user_role}'")
        elif boq_status in ['add_new_purchase', 'new_purchase_request']:
            # Estimator and Project Manager can view
            if user_role in ['estimator', 'projectmanager', 'project_manager']:
                can_view_new_purchase = True
            else:
                log.info(f"BOQ {boq_id} - Access DENIED: Only Estimator/PM can view '{boq_status}', current role: '{user_role}'")
        elif boq_status == 'new_purchase_approved':
            # All roles can view when new purchase is approved
            can_view_new_purchase = True
        elif boq_status == 'new_purchase_rejected':
            # Only Project Manager can view when new purchase is rejected
            if user_role in ['projectmanager', 'project_manager']:
                can_view_new_purchase = True
            else:
                log.info(f"BOQ {boq_id} - Access DENIED: Only PM can view 'new_purchase_rejected', current role: '{user_role}'")
        else:
            log.info(f"BOQ {boq_id} - Access DENIED: Unknown status '{boq_status}'")

        # Filter new purchase items based on access control
        filtered_new_purchase_items = []
        filtered_new_total_cost = 0
        filtered_new_material_cost = 0
        filtered_new_labour_cost = 0
        filtered_new_materials_count = 0
        filtered_new_labour_count = 0

        if can_view_new_purchase:
            # User has permission to view new purchases
            filtered_new_purchase_items = new_add_purchase_items
            filtered_new_total_cost = new_total_cost
            filtered_new_material_cost = new_material_cost
            filtered_new_labour_cost = new_labour_cost
            filtered_new_materials_count = new_materials_count
            filtered_new_labour_count = new_labour_count

        # Process items with purchase_tracking and add them to new_purchase.items
        # BUT only if user has permission to view (can_view_new_purchase)
        new_purchase_items_with_tracking = []
        new_purchase_total_materials_count = 0
        new_purchase_total_labour_count = 0
        new_purchase_total_material_cost = 0.0
        new_purchase_total_labour_cost = 0.0
        new_purchase_total_cost = 0.0

        # Calculate total purchased amounts (all purchases, not just latest)
        total_all_purchased_amount = 0.0
        existing_purchased_amount = 0.0

        for item in all_items:
            purchase_tracking = item.get("purchase_tracking", {})
            total_all_purchased_amount += purchase_tracking.get("total_purchased_amount", 0.0)

        if can_view_new_purchase:
            # Get the LATEST add_new_purchase action timestamp from BOQ history
            latest_purchase_action_date = None
            for history in boq_history:
                if history.action:
                    actions = history.action if isinstance(history.action, list) else [history.action]
                    for action in actions:
                        if isinstance(action, dict) and action.get("type") == "add_new_purchase":
                            action_timestamp = action.get("timestamp")
                            if action_timestamp:
                                try:
                                    action_date = datetime.fromisoformat(action_timestamp)
                                    if latest_purchase_action_date is None or action_date > latest_purchase_action_date:
                                        latest_purchase_action_date = action_date
                                except:
                                    pass

            # Process items with purchase_tracking and add them to new purchase items
            if latest_purchase_action_date:
                for item in all_items:
                    purchase_tracking = item.get("purchase_tracking", {})
                    purchased_materials = purchase_tracking.get("purchased_materials", [])

                    if purchased_materials:
                        # Collect only the LATEST purchased materials (from most recent add_new_purchase)
                        latest_materials = []
                        earlier_materials = []

                        for material in purchased_materials:
                            purchase_date_str = material.get("purchase_date")
                            if purchase_date_str:
                                try:
                                    purchase_date = datetime.fromisoformat(purchase_date_str)
                                    # Check if this material was purchased during the latest add_new_purchase action
                                    time_diff = abs((purchase_date - latest_purchase_action_date).total_seconds())
                                    if time_diff <= 60:  # Within 1 minute
                                        latest_materials.append(material)
                                    else:
                                        earlier_materials.append(material)
                                except:
                                    earlier_materials.append(material)

                        # Calculate existing purchase amount (purchased before latest action)
                        existing_purchased_amount += sum(mat.get("total_price", 0) for mat in earlier_materials)

                        # If there are latest materials, create a simple purchase entry
                        if latest_materials:
                            # Calculate totals for this purchase
                            new_materials_total = sum(mat.get("total_price", 0) for mat in latest_materials)

                            new_purchase_items_with_tracking.append({
                                "master_item_id": item.get("master_item_id"),
                                "item_name": item.get("item_name"),
                                "description": item.get("description"),
                                "materials": latest_materials,
                                "total_purchased_amount": new_materials_total
                            })

                            new_purchase_total_materials_count += len(latest_materials)
                            new_purchase_total_material_cost += new_materials_total
                            new_purchase_total_cost += new_materials_total

        # Remove purchase_tracking from existing_purchase items (keep all items)
        for item in existing_purchase_items:
            # Remove purchase_tracking completely from existing purchase items
            if "purchase_tracking" in item:
                del item["purchase_tracking"]

        # Fetch sub_item_image from database for all items (both existing and new)
        # Also track if we need to update the database with recovered IDs
        from models.boq import MasterSubItem, MasterItem
        ids_were_recovered = False

        for item in existing_purchase_items + new_add_purchase_items:
            sub_items = item.get("sub_items", [])
            for sub_item in sub_items:
                sub_item_id = sub_item.get("sub_item_id") or sub_item.get("master_sub_item_id")
                master_sub_item = None

                if sub_item_id:
                    # Query database for sub_item_image using ID
                    master_sub_item = MasterSubItem.query.filter_by(sub_item_id=sub_item_id).first()
                else:
                    # Fallback: Try to find by item_name and sub_item_name (for BOQs that lost their IDs)
                    item_name = item.get("item_name")
                    sub_item_name = sub_item.get("sub_item_name")

                    if item_name and sub_item_name:
                        # First find the master item
                        master_item = MasterItem.query.filter_by(item_name=item_name).first()
                        if master_item:
                            # Then find the sub-item by item_id and sub_item_name
                            master_sub_item = MasterSubItem.query.filter_by(
                                item_id=master_item.item_id,
                                sub_item_name=sub_item_name
                            ).first()

                            # If found, add the ID back to the JSON for future use
                            if master_sub_item:
                                sub_item["sub_item_id"] = master_sub_item.sub_item_id
                                sub_item["master_sub_item_id"] = master_sub_item.sub_item_id
                                ids_were_recovered = True
                                log.info(f"Recovered sub_item_id {master_sub_item.sub_item_id} for '{sub_item_name}' in item '{item_name}'")

                # Add images if found
                if master_sub_item and master_sub_item.sub_item_image:
                    sub_item["sub_item_image"] = master_sub_item.sub_item_image

        # If we recovered any IDs, persist them back to the database
        if ids_were_recovered:
            try:
                log.info(f"Persisting recovered sub_item_ids back to BOQDetails for BOQ {boq_id}")
                # Update the existing_purchase items in boq_details with recovered IDs
                boq_details.boq_details["items"] = existing_purchase_items + new_add_purchase_items
                db.session.add(boq_details)
                db.session.commit()
                log.info(f"Successfully persisted recovered sub_item_ids for BOQ {boq_id}")
            except Exception as e:
                log.error(f"Failed to persist recovered sub_item_ids for BOQ {boq_id}: {str(e)}")
                db.session.rollback()

        # Calculate combined totals (with filtered new purchases)
        total_material_cost = existing_material_cost + filtered_new_material_cost
        total_labour_cost = existing_labour_cost + filtered_new_labour_cost
        total_cost = existing_total_cost + filtered_new_total_cost
        overhead_percentage = 0
        profit_margin = 0

        # Get overhead and profit from summary or first item
        if boq_details.boq_details and "summary" in boq_details.boq_details:
            summary = boq_details.boq_details["summary"]
            overhead_percentage = summary.get("overhead_percentage", 0) or summary.get("overhead", 0)
            profit_margin = summary.get("profit_margin_percentage", 0) or summary.get("profit_margin", 0)

        # Fallback: Get from first item if not in summary
        if (overhead_percentage == 0 or profit_margin == 0) and all_items:
            for item in all_items:
                if overhead_percentage == 0:
                    overhead_percentage = item.get("overhead_percentage", 0)
                if profit_margin == 0:
                    profit_margin = item.get("profit_margin_percentage", 0) or item.get("profit_margin", 0)
                if overhead_percentage > 0 and profit_margin > 0:
                    break

        # Determine display status for Technical Director
        display_status = boq.status
        if boq.status == "new_purchase_approved" and user_role in ['technicaldirector', 'technical_director']:
            display_status = "approved"

        # Get preliminaries from NEW boq_preliminaries junction table
        from models.preliminary_master import BOQPreliminary, PreliminaryMaster

        preliminaries = {}
        try:
            # Fetch selected preliminaries for this BOQ
            boq_prelims = db.session.query(
                BOQPreliminary, PreliminaryMaster
            ).join(
                PreliminaryMaster, BOQPreliminary.prelim_id == PreliminaryMaster.prelim_id
            ).filter(
                BOQPreliminary.boq_id == boq.boq_id,
                BOQPreliminary.is_checked == True
            ).order_by(PreliminaryMaster.display_order.asc()).all()

            # Build preliminaries data with selected items (both master and custom)
            items = []
            for boq_prelim, prelim_master in boq_prelims:
                # Mark as custom if display_order is 9999 (our custom indicator)
                is_custom = prelim_master.display_order == 9999

                items.append({
                    'id': f'prelim-{prelim_master.prelim_id}',
                    'prelim_id': prelim_master.prelim_id,
                    'description': prelim_master.description,
                    'name': prelim_master.name,
                    'checked': True,
                    'selected': True,
                    'isCustom': is_custom
                })

            # Get cost details and notes from JSON
            stored_preliminaries = boq_details.boq_details.get("preliminaries", {}) if boq_details.boq_details else {}

            preliminaries = {
                'items': items,
                'cost_details': stored_preliminaries.get("cost_details", {}),
                'notes': stored_preliminaries.get("notes", "")
            }

            custom_count = len([i for i in items if i.get('isCustom')])
            master_count = len(items) - custom_count
            log.info(f"Retrieved {len(items)} preliminaries ({master_count} master + {custom_count} custom) for BOQ {boq.boq_id}")
        except Exception as e:
            log.error(f"Error fetching preliminaries for BOQ {boq.boq_id}: {str(e)}")
            # Fallback to empty
            preliminaries = {'items': [], 'cost_details': {}, 'notes': ''}

        # Get discount values from boq_details JSON
        discount_percentage = boq_details.boq_details.get("discount_percentage", 0) if boq_details.boq_details else 0
        discount_amount = boq_details.boq_details.get("discount_amount", 0) if boq_details.boq_details else 0

        # Get terms & conditions from boq_terms_selections junction table using JOIN
        try:
            from sqlalchemy import text
            # First get selected term_ids for this BOQ (single row with term_ids array)
            term_ids_query = text("""
                SELECT term_ids FROM boq_terms_selections WHERE boq_id = :boq_id
            """)
            term_ids_result = db.session.execute(term_ids_query, {'boq_id': boq_id}).fetchone()
            selected_term_ids = term_ids_result[0] if term_ids_result and term_ids_result[0] else []

            # Get all active terms from master
            all_terms_query = text("""
                SELECT term_id, terms_text, display_order
                FROM boq_terms
                WHERE is_active = TRUE AND is_deleted = FALSE
                ORDER BY display_order, term_id
            """)
            all_terms_result = db.session.execute(all_terms_query)
            terms_items = []

            for row in all_terms_result:
                term_id = row[0]
                terms_items.append({
                    'id': f'term-{term_id}',
                    'term_id': term_id,
                    'terms_text': row[1],
                    'display_order': row[2],
                    'checked': term_id in selected_term_ids,
                    'isCustom': False
                })

            terms_conditions = {'items': terms_items}
            log.info(f"Retrieved {len(terms_items)} terms from boq_terms_selections for BOQ {boq.boq_id}")
        except Exception as e:
            log.error(f"Error fetching terms for BOQ {boq.boq_id}: {str(e)}")
            terms_conditions = {'items': []}

        # Build response with project details
        response_data = {
            "boq_id": boq.boq_id,
            "boq_name": boq.boq_name,
            "project_id": boq.project_id,
            "status": display_status,
            "email_sent": boq.email_sent,
            "created_at": boq.created_at.isoformat() if boq.created_at else None,
            "created_by": boq.created_by,
            "user_id": project.user_id if project else None,
            "discount_percentage": discount_percentage,
            "discount_amount": discount_amount,
            "preliminaries": preliminaries,
            "terms_conditions": terms_conditions,
            "project_details": {
                "project_name": project.project_name if project else None,
                "client": project.client if project else None,
                "location": project.location if project else None,
                "floor": project.floor_name if project else None,
                "hours": project.working_hours if project else None,
                "status": project.status if project else None,
                "start_date": project.start_date.isoformat() if project and project.start_date else None,
                "end_date": project.end_date.isoformat() if project and project.end_date else None,
                "duration_days": project.duration_days if project else None
            },
            "existing_purchase": {
                "items": existing_purchase_items,
                "summary": {
                    "total_items": len(existing_purchase_items),
                    "total_materials": existing_materials_count,
                    "total_labour": existing_labour_count,
                    "total_material_cost": existing_material_cost,
                    "total_labour_cost": existing_labour_cost,
                    "total_cost": existing_total_cost,
                    "selling_price": existing_total_cost,
                    "estimatedSellingPrice": existing_total_cost
                }
            },
            "new_purchase": {
                "items": new_purchase_items_with_tracking,
                "summary": {
                    "total_items": len(new_purchase_items_with_tracking),
                    "total_materials": new_purchase_total_materials_count,
                    "total_material_cost": new_purchase_total_material_cost,
                    "total_cost": new_purchase_total_cost,
                    "selling_price": new_purchase_total_cost,
                    "estimatedSellingPrice": new_purchase_total_cost
                },
                "access_info": {
                    "can_view": can_view_new_purchase,
                    "user_role": user_role,
                    "boq_status": boq.status
                }
            },
            "combined_summary": {
                "total_items": len(existing_purchase_items),
                "total_materials": existing_materials_count + new_purchase_total_materials_count,
                "total_labour": existing_labour_count,
                "total_item_amount": existing_total_cost,  # Total amount from existing BOQ items
                "total_material_cost": existing_material_cost,
                "total_labour_cost": existing_labour_cost,
                "existing_purchase_amount": existing_purchased_amount,  # Materials purchased before latest action
                "new_purchase_amount": new_purchase_total_cost,  # Materials from latest purchase
                "total_purchased_amount": total_all_purchased_amount,  # Sum of all purchases
                "balance_amount": existing_total_cost - total_all_purchased_amount,  # Remaining to be purchased
                "total_cost": existing_total_cost,
                "selling_price": existing_total_cost,
                "estimatedSellingPrice": existing_total_cost
            },
            "total_material_cost": total_material_cost,
            "total_labour_cost": total_labour_cost,
            "overhead_percentage": overhead_percentage,
            "profit_margin": profit_margin,
            "profit_margin_percentage": profit_margin
        }

        # Add change request materials tracking (if any)
        try:
            from models.change_request import ChangeRequest

            # Get change requests that consume/reserve material quantities
            # Uses centralized config to prevent over-allocation
            approved_change_requests = ChangeRequest.query.filter(
                ChangeRequest.boq_id == boq_id,
                ChangeRequest.status.in_(CR_CONFIG.MATERIAL_CONSUMING_STATUSES),
                ChangeRequest.is_deleted == False
            ).order_by(ChangeRequest.approval_date.desc()).all()

            if approved_change_requests:
                change_request_items = []
                total_cr_materials_cost = 0

                # Build material lookup map from BOQ for enrichment
                material_lookup = {}
                for item in all_items:
                    for sub_item in item.get('sub_items', []):
                        for material in sub_item.get('materials', []):
                            material_id = material.get('master_material_id')
                            if material_id:
                                material_lookup[material_id] = {
                                    'brand': material.get('brand'),
                                    'specification': material.get('specification')
                                }

                for cr in approved_change_requests:
                    cr_materials = cr.materials_data or []

                    # Enrich materials with brand/specification from BOQ if missing
                    enriched_materials = []
                    for mat in cr_materials:
                        enriched_mat = dict(mat)  # Create a copy
                        # If material doesn't have brand/spec, try to get from BOQ
                        if not enriched_mat.get('brand') and not enriched_mat.get('specification'):
                            material_id = enriched_mat.get('master_material_id')
                            if material_id and material_id in material_lookup:
                                boq_mat = material_lookup[material_id]
                                enriched_mat['brand'] = boq_mat.get('brand')
                                enriched_mat['specification'] = boq_mat.get('specification')
                        enriched_materials.append(enriched_mat)

                    change_request_items.append({
                        'cr_id': cr.cr_id,
                        'requested_by': cr.requested_by_name,
                        'request_date': cr.created_at.isoformat() if cr.created_at else None,
                        'approval_date': cr.approval_date.isoformat() if cr.approval_date else None,
                        'justification': cr.justification,
                        'materials': enriched_materials,
                        'materials_cost': cr.materials_total_cost
                    })

                    total_cr_materials_cost += cr.materials_total_cost or 0

                response_data['change_requests'] = {
                    'items': change_request_items,
                    'summary': {
                        'total_requests': len(approved_change_requests),
                        'total_materials_cost': round(total_cr_materials_cost, 2)
                    }
                }
        except Exception as e:
            # Don't fail the entire request if change request data fails
            pass

        return jsonify(response_data), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error fetching BOQ: {str(e)}")
        return jsonify({"error": str(e)}), 500


def update_boq(boq_id):
    """Update BOQ using JSON storage approach"""
    try:
        data = request.get_json()

        # Get current logged-in user
        current_user = getattr(g, 'user', None)
        user_id = current_user.get('user_id') if current_user else None
        user_role = current_user.get('role', '').lower() if current_user else ''
        user_name = current_user.get('full_name') or current_user.get('username') or 'Unknown' if current_user else 'Unknown'

        boq = BOQ.query.filter_by(boq_id=boq_id).first()
        if not boq:
            return jsonify({"error": "BOQ not found"}), 404

        # Get project for default work_type
        project = Project.query.filter_by(project_id=boq.project_id).first()
        default_work_type = project.work_type if project and project.work_type else "contract"

        # Validate that BOQ can be edited based on status
        # Cannot edit if PM has approved or items are assigned
        restricted_statuses = ["PM_Approved", "Items_Assigned", "Approved"]
        if boq.status in restricted_statuses:
            return jsonify({
                "error": f"Cannot edit BOQ with status '{boq.status}'. BOQ has been approved and is no longer editable.",
                "status": boq.status
            }), 403

        # Update BOQ basic details
        if "boq_name" in data:
            boq.boq_name = data["boq_name"]
        # Check if this is a revision edit (from Revisions button)
        is_revision = data.get("is_revision", False)
        # Set status based on current status and revision mode
        current_status = boq.status
        if is_revision:
            # If this is a revision edit, always set to Under_Revision
            boq.status = "Under_Revision"
        elif current_status == "Client_Rejected":
            boq.status = "Under_Revision"
        elif current_status == "Rejected":
            # If TD rejected, keep as Under_Revision when editing
            boq.status = "Under_Revision"
        elif current_status in ["Sent_for_Confirmation", "Pending_Revision", "Pending", "Approved", "Client_Confirmed", "Under_Revision"]:
            # Keep the current status (don't change workflow statuses)
            pass
        else:
            boq.status = boq.status

        # Update last modified by
        boq.last_modified_by = user_name
        # Get existing BOQ details
        boq_details = BOQDetails.query.filter_by(boq_id=boq_id).first()
        if not boq_details:
            return jsonify({"error": "BOQ details not found"}), 404

        # Store old values before updating (for change tracking)
        old_boq_name = boq.boq_name
        old_status = boq.status
        old_total_cost = boq_details.total_cost
        old_total_items = boq_details.total_items
        old_boq_details_json = boq_details.boq_details

        # Update last modified timestamp
        boq.last_modified_at = datetime.utcnow()
        # Note: BOQDetailsHistory is NOT stored in update_boq
        # History is only stored in revision_boq function
        next_version = 1
        boq_items = []
        total_boq_cost = 0

        # Check if we should store payload directly (when combined_summary exists in payload)
        if "items" in data and "combined_summary" in data:
            # Store payload directly without recalculation
            import copy
            payload_copy = copy.deepcopy(data)
            # Get values directly from payload
            boq_items = data.get("items", [])
            combined_summary = data.get("combined_summary", {})
            total_boq_cost = combined_summary.get("total_cost", 0)
            total_items = combined_summary.get("total_items", len(boq_items))
            total_materials = combined_summary.get("total_materials", 0)
            total_labour = combined_summary.get("total_labour", 0)

            # Get current user for master table operations
            current_user = getattr(g, 'user', None)
            if current_user:
                created_by = current_user.get('username') or current_user.get('full_name') or current_user.get('user_id', 'Admin')
            else:
                created_by = data.get("modified_by", "Admin")

            # Process ALL items to store in master tables (both new and existing)
            # This ensures materials/labour added to existing items are also saved
            for idx, item_data in enumerate(boq_items):
                # Check if item has sub_items structure
                if "sub_items" in item_data and item_data.get("sub_items"):
                    # Get item-level data
                    item_quantity = clean_numeric_value(item_data.get("quantity", 1.0))
                    item_rate = clean_numeric_value(item_data.get("rate", 0.0))
                    item_unit = item_data.get("unit", "nos")
                    item_total = item_quantity * item_rate

                    # Get percentages
                    miscellaneous_percentage = clean_numeric_value(item_data.get("overhead_percentage", 10.0))
                    overhead_profit_percentage = clean_numeric_value(item_data.get("profit_margin_percentage", 15.0))

                    # Calculate amounts
                    total_miscellaneous_amount = (item_total * miscellaneous_percentage) / 100
                    total_overhead_profit_amount = (item_total * overhead_profit_percentage) / 100

                    # Add item to master tables (or update if exists)
                    # Use existing master_item_id if available, otherwise will create new
                    existing_master_item_id = item_data.get("master_item_id")
                    master_item_id, _, _ = add_to_master_tables(
                        item_data.get("item_name"),
                        item_data.get("description", ""),
                        item_data.get("work_type", default_work_type),
                        [],  # Don't add materials here, will add per sub-item
                        [],  # Don't add labour here, will add per sub-item
                        created_by,
                        miscellaneous_percentage,
                        total_miscellaneous_amount,
                        overhead_profit_percentage,
                        total_overhead_profit_amount,
                        overhead_profit_percentage,
                        total_overhead_profit_amount,
                        clean_numeric_value(item_data.get("discount_percentage", 0.0)),
                        clean_numeric_value(item_data.get("discount_amount", 0.0)),
                        clean_numeric_value(item_data.get("vat_percentage", 0.0)),
                        clean_numeric_value(item_data.get("vat_amount", 0.0)),
                        unit=item_unit,
                        quantity=item_quantity,
                        per_unit_cost=item_rate,
                        total_amount=item_total,
                        item_total_cost=item_total
                    )

                    # Add master_item_id back to payload
                    item_data["master_item_id"] = master_item_id
                    payload_copy["items"][idx]["master_item_id"] = master_item_id

                    # Process sub-items with their materials and labour
                    sub_items_list = item_data.get("sub_items", [])
                    if sub_items_list:
                        master_sub_item_ids = add_sub_items_to_master_tables(
                            master_item_id,
                            sub_items_list,
                            created_by
                        )
                        # Add master sub-item IDs back to payload
                        for sub_idx, sub_item_id in enumerate(master_sub_item_ids):
                            if sub_idx < len(sub_items_list):
                                sub_items_list[sub_idx]["sub_item_id"] = sub_item_id
                                sub_items_list[sub_idx]["master_sub_item_id"] = sub_item_id
                                payload_copy["items"][idx]["sub_items"][sub_idx]["sub_item_id"] = sub_item_id
                                payload_copy["items"][idx]["sub_items"][sub_idx]["master_sub_item_id"] = sub_item_id

            # Update BOQDetails with the raw payload directly
            boq_details.boq_details = payload_copy
            flag_modified(boq_details, 'boq_details')
            boq_details.total_cost = total_boq_cost
            boq_details.total_items = total_items
            boq_details.total_materials = total_materials
            boq_details.total_labour = total_labour
            boq_details.last_modified_by = user_name

        # If items are provided, update the JSON structure (normal calculation mode)
        elif "items" in data:
            # Use the same current user logic for BOQ details
            current_user = getattr(g, 'user', None)
            if current_user:
                created_by = current_user.get('username') or current_user.get('full_name') or current_user.get('user_id', 'Admin')
            else:
                created_by = data.get("modified_by", "Admin")

            # Process updated items
            total_boq_cost = 0
            total_materials = 0
            total_labour = 0

            for item_data in data["items"]:
                # Initialize variables for both formats
                materials_data = []
                labour_data = []
                # Check if item has sub_items structure (new format)
                has_sub_items = "sub_items" in item_data and item_data.get("sub_items")

                if has_sub_items:
                    # NEW FORMAT: Item with sub_items structure - preserve scope and size
                    sub_items_list = []
                    materials_count = 0
                    labour_count = 0

                    # Get item-level quantity and rate
                    item_quantity = clean_numeric_value(item_data.get("quantity", 1.0))
                    item_rate = clean_numeric_value(item_data.get("rate", 0.0))
                    item_unit = item_data.get("unit", "nos")
                    item_total = item_quantity * item_rate

                    # Get percentages
                    miscellaneous_percentage = clean_numeric_value(item_data.get("overhead_percentage", 10.0))
                    overhead_profit_percentage = clean_numeric_value(item_data.get("profit_margin_percentage", 15.0))
                    discount_percentage = clean_numeric_value(item_data.get("discount_percentage", 0.0))
                    vat_percentage = clean_numeric_value(item_data.get("vat_percentage", 0.0))

                    # Calculate amounts
                    total_miscellaneous_amount = (item_total * miscellaneous_percentage) / 100
                    total_overhead_profit_amount = (item_total * overhead_profit_percentage) / 100
                    total_subtotal = item_total + total_miscellaneous_amount + total_overhead_profit_amount
                    total_discount_amount = (total_subtotal * discount_percentage) / 100 if discount_percentage > 0 else 0.0
                    total_after_discount = total_subtotal - total_discount_amount
                    total_vat_amount = (total_after_discount * vat_percentage) / 100 if vat_percentage > 0 else 0.0
                    total_selling_price = total_after_discount + total_vat_amount

                    # Process sub_items
                    for idx, sub_item_data in enumerate(item_data.get("sub_items", [])):
                        sub_item_quantity = clean_numeric_value(sub_item_data.get("quantity", 1.0))
                        sub_item_unit = sub_item_data.get("unit", "nos")
                        sub_item_rate = clean_numeric_value(sub_item_data.get("rate", 0.0))
                        sub_item_base_total = sub_item_quantity * sub_item_rate

                        # Process materials for this sub-item
                        sub_item_materials = []
                        materials_cost = 0
                        for mat_data in sub_item_data.get("materials", []):
                            material_name = mat_data.get("material_name", "").strip()
                            # Skip materials with empty or null names
                            if not material_name:
                                continue

                            quantity = clean_numeric_value(mat_data.get("quantity", 1.0))
                            unit_price = clean_numeric_value(mat_data.get("unit_price", 0.0))
                            total_price = quantity * unit_price
                            materials_cost += total_price

                            sub_item_materials.append({
                                "material_name": material_name,
                                "location": mat_data.get("location", ""),
                                "brand": mat_data.get("brand", ""),
                                "size": mat_data.get("size", ""),
                                "specification": mat_data.get("specification", ""),
                                "description": mat_data.get("description", ""),
                                "quantity": quantity,
                                "unit": mat_data.get("unit", "nos"),
                                "unit_price": unit_price,
                                "total_price": total_price,
                                "vat_percentage": clean_numeric_value(mat_data.get("vat_percentage", 0.0))
                            })

                        # Process labour for this sub-item
                        sub_item_labour = []
                        labour_cost = 0
                        for labour_data_item in sub_item_data.get("labour", []):
                            labour_role = labour_data_item.get("labour_role", "").strip()
                            # Skip labour with empty or null roles
                            if not labour_role:
                                continue

                            hours = clean_numeric_value(labour_data_item.get("hours", 0.0))
                            rate_per_hour = clean_numeric_value(labour_data_item.get("rate_per_hour", 0.0))
                            total_cost_labour = hours * rate_per_hour
                            labour_cost += total_cost_labour

                            sub_item_labour.append({
                                "labour_role": labour_role,
                                "work_type": labour_data_item.get("work_type", "daily_wages"),
                                "hours": hours,
                                "rate_per_hour": rate_per_hour,
                                "total_cost": total_cost_labour
                            })

                        # Create sub-item JSON with scope and size
                        sub_item_json = {
                            "sub_item_name": sub_item_data.get("sub_item_name"),
                            "scope": sub_item_data.get("scope", ""),
                            "size": sub_item_data.get("size", ""),
                            "description": sub_item_data.get("description", ""),
                            "location": sub_item_data.get("location", ""),
                            "brand": sub_item_data.get("brand", ""),
                            "quantity": sub_item_quantity,
                            "unit": sub_item_unit,
                            "rate": sub_item_rate,
                            "per_unit_cost": sub_item_rate,  # Added for master table
                            "base_total": sub_item_base_total,
                            "sub_item_total_cost": sub_item_base_total,  # Added for master table
                            "materials_cost": materials_cost,
                            "labour_cost": labour_cost,
                            "material_cost": materials_cost,  # Added for master table (uses singular)
                            "internal_cost": sub_item_data.get("internal_cost", 0.0),
                            "planned_profit": sub_item_data.get("planned_profit", 0.0),
                            "actual_profit": sub_item_data.get("actual_profit", 0.0),
                            "negotiable_margin": sub_item_data.get("actual_profit", 0.0),  # Same as actual_profit
                            "misc_percentage": sub_item_data.get("misc_percentage", 10.0),
                            "misc_amount": sub_item_data.get("misc_amount", 0.0),
                            "overhead_profit_percentage": sub_item_data.get("overhead_profit_percentage", 25.0),
                            "overhead_profit_amount": sub_item_data.get("overhead_profit_amount", 0.0),
                            "transport_percentage": sub_item_data.get("transport_percentage", 5.0),
                            "transport_amount": sub_item_data.get("transport_amount", 0.0),
                            "materials": sub_item_materials,
                            "labour": sub_item_labour
                        }

                        # PRESERVE sub_item_id if it exists in the input data
                        if "sub_item_id" in sub_item_data:
                            sub_item_json["sub_item_id"] = sub_item_data["sub_item_id"]
                        if "master_sub_item_id" in sub_item_data:
                            sub_item_json["master_sub_item_id"] = sub_item_data["master_sub_item_id"]

                        sub_items_list.append(sub_item_json)
                        materials_count += len(sub_item_materials)
                        labour_count += len(sub_item_labour)

                    # Calculate total materials and labour costs from all sub-items
                    total_materials_cost = sum(si.get("materials_cost", 0) for si in sub_items_list)
                    total_labour_cost = sum(si.get("labour_cost", 0) for si in sub_items_list)
                    base_cost = total_materials_cost + total_labour_cost

                    # Create item JSON with sub_items
                    item_json = {
                        "item_name": item_data.get("item_name"),
                        "description": item_data.get("description", ""),
                        "work_type": item_data.get("work_type", default_work_type),
                        "has_sub_items": True,
                        "sub_items": sub_items_list,
                        "quantity": item_quantity,
                        "unit": item_unit,
                        "rate": item_rate,
                        "item_total": item_total,
                        "base_cost": base_cost,
                        "sub_items_cost": base_cost,
                        "total_selling_price": total_selling_price,
                        "selling_price": total_selling_price,
                        "estimatedSellingPrice": total_selling_price,
                        "actualItemCost": base_cost,
                        "total_cost": total_selling_price,
                        "overhead_percentage": miscellaneous_percentage,
                        "overhead_amount": total_miscellaneous_amount,
                        "profit_margin_percentage": overhead_profit_percentage,
                        "profit_margin_amount": total_overhead_profit_amount,
                        "subtotal": total_subtotal,
                        "discount_percentage": discount_percentage,
                        "discount_amount": total_discount_amount,
                        "vat_percentage": vat_percentage,
                        "vat_amount": total_vat_amount,
                        "totalMaterialCost": total_materials_cost,
                        "totalLabourCost": total_labour_cost
                    }

                    # Add/Update to master tables
                    # Step 1: Add item to boq_items table
                    master_item_id, _, _ = add_to_master_tables(
                        item_data.get("item_name"),
                        item_data.get("description", ""),
                        item_data.get("work_type", default_work_type),
                        [],  # Don't add materials here, will add per sub-item
                        [],  # Don't add labour here, will add per sub-item
                        created_by,
                        miscellaneous_percentage,
                        total_miscellaneous_amount,
                        overhead_profit_percentage,
                        total_overhead_profit_amount,
                        overhead_profit_percentage,
                        total_overhead_profit_amount,
                        discount_percentage,
                        total_discount_amount,
                        vat_percentage,
                        total_vat_amount,
                        unit=item_unit,
                        quantity=item_quantity,
                        per_unit_cost=item_rate,
                        total_amount=item_total,
                        item_total_cost=item_total
                    )

                    # Step 2: Add sub-items to boq_sub_items table, and their materials & labour
                    master_sub_item_ids = []
                    if sub_items_list:
                        # Pass the processed sub_items_list that contains materials and labour
                        master_sub_item_ids = add_sub_items_to_master_tables(
                            master_item_id,
                            sub_items_list,
                            created_by
                        )

                        # Assign master sub-item IDs back to the sub_items in item_json
                        # This ensures sub_item_id is preserved for future edits
                        for idx, sub_item_id in enumerate(master_sub_item_ids):
                            if idx < len(item_json.get("sub_items", [])):
                                # Only assign if not already present (preserve existing IDs)
                                if "sub_item_id" not in item_json["sub_items"][idx]:
                                    item_json["sub_items"][idx]["sub_item_id"] = sub_item_id
                                if "master_sub_item_id" not in item_json["sub_items"][idx]:
                                    item_json["sub_items"][idx]["master_sub_item_id"] = sub_item_id

                    boq_items.append(item_json)
                    total_boq_cost += total_selling_price
                    total_materials += materials_count
                    total_labour += labour_count


            # Get preliminaries from request data (for discount calculation only)
            preliminaries = data.get("preliminaries", {})
            preliminary_id = old_boq_details_json.get("preliminary_id") if old_boq_details_json else None

            # Apply BOQ-level discount to total
            boq_discount_percentage = data.get("discount_percentage", old_boq_details_json.get("discount_percentage", 0)) or 0
            boq_discount_amount = data.get("discount_amount", old_boq_details_json.get("discount_amount", 0)) or 0

            # Get preliminary amount to include in discount calculation
            preliminary_amount = preliminaries.get('cost_details', {}).get('amount', 0) if preliminaries else 0

            # Combined subtotal = items total + preliminary amount
            combined_subtotal = total_boq_cost + preliminary_amount

            # Calculate discount amount if only percentage is provided
            # Discount should be calculated on combined subtotal (items + preliminaries)
            if boq_discount_amount == 0 and boq_discount_percentage > 0 and combined_subtotal > 0:
                boq_discount_amount = combined_subtotal * (boq_discount_percentage / 100)

            # Apply BOQ-level discount to get final total
            final_boq_cost = combined_subtotal - boq_discount_amount if boq_discount_amount > 0 else combined_subtotal

            # Update JSON structure
            updated_json = {
                "boq_id": boq.boq_id,
                "preliminaries": preliminaries,
                "preliminary_id": preliminary_id,
                "discount_percentage": boq_discount_percentage,
                "discount_amount": boq_discount_amount,
                "items": boq_items,
                "summary": {
                    "total_items": len(boq_items),
                    "total_materials": total_materials,
                    "total_labour": total_labour,
                    "total_material_cost": sum(item["totalMaterialCost"] for item in boq_items),
                    "total_labour_cost": sum(item["totalLabourCost"] for item in boq_items),
                    "total_cost": final_boq_cost,
                    "selling_price": final_boq_cost,
                    "estimatedSellingPrice": final_boq_cost
                }
            }

            # Update BOQ details
            boq_details.boq_details = updated_json
            flag_modified(boq_details, 'boq_details')
            boq_details.total_cost = final_boq_cost
            boq_details.total_items = len(boq_items)
            boq_details.total_materials = total_materials
            boq_details.total_labour = total_labour
            boq_details.last_modified_by = created_by

        # Track detailed changes
        detailed_changes = {}

        # Check BOQ name change
        if old_boq_name != boq.boq_name:
            detailed_changes["boq_name"] = {
                "old": old_boq_name,
                "new": boq.boq_name
            }

        # Check total cost change
        new_total_cost = total_boq_cost if "items" in data else boq_details.total_cost
        if old_total_cost != new_total_cost:
            detailed_changes["total_cost"] = {
                "old": float(old_total_cost) if old_total_cost else 0,
                "new": float(new_total_cost) if new_total_cost else 0,
                "difference": float(new_total_cost - old_total_cost) if old_total_cost and new_total_cost else 0
            }

        # Check total items change
        new_total_items = len(boq_items) if "items" in data else boq_details.total_items
        if old_total_items != new_total_items:
            detailed_changes["total_items"] = {
                "old": old_total_items,
                "new": new_total_items,
                "difference": new_total_items - old_total_items if old_total_items and new_total_items else 0
            }

        # Track item-level changes (if items were updated)
        if "items" in data and old_boq_details_json and "items" in old_boq_details_json:
            items_changes = []
            old_items = old_boq_details_json.get("items", [])
            new_items = boq_items

            # Create dictionaries for easier lookup
            old_items_dict = {item.get("master_item_id"): item for item in old_items if item.get("master_item_id")}
            new_items_dict = {item.get("master_item_id"): item for item in new_items if item.get("master_item_id")}

            # Check for modified items
            for item_id, new_item in new_items_dict.items():
                if item_id in old_items_dict:
                    old_item = old_items_dict[item_id]
                    item_change = {"item_name": new_item.get("item_name"), "master_item_id": item_id}

                    # Check specific field changes
                    if old_item.get("base_cost") != new_item.get("base_cost"):
                        item_change["base_cost"] = {
                            "old": float(old_item.get("base_cost", 0)),
                            "new": float(new_item.get("base_cost", 0))
                        }

                    if old_item.get("selling_price") != new_item.get("selling_price"):
                        item_change["selling_price"] = {
                            "old": float(old_item.get("selling_price", 0)),
                            "new": float(new_item.get("selling_price", 0))
                        }

                    if old_item.get("overhead_percentage") != new_item.get("overhead_percentage"):
                        item_change["overhead_percentage"] = {
                            "old": float(old_item.get("overhead_percentage", 0)),
                            "new": float(new_item.get("overhead_percentage", 0))
                        }

                    if old_item.get("profit_margin_percentage") != new_item.get("profit_margin_percentage"):
                        item_change["profit_margin_percentage"] = {
                            "old": float(old_item.get("profit_margin_percentage", 0)),
                            "new": float(new_item.get("profit_margin_percentage", 0))
                        }

                    # Check material changes
                    old_materials_count = len(old_item.get("materials", []))
                    new_materials_count = len(new_item.get("materials", []))
                    if old_materials_count != new_materials_count:
                        item_change["materials_count"] = {
                            "old": old_materials_count,
                            "new": new_materials_count
                        }

                    # Check labour changes
                    old_labour_count = len(old_item.get("labour", []))
                    new_labour_count = len(new_item.get("labour", []))
                    if old_labour_count != new_labour_count:
                        item_change["labour_count"] = {
                            "old": old_labour_count,
                            "new": new_labour_count
                        }

                    if len(item_change) > 2:  # More than just item_name and master_item_id
                        items_changes.append(item_change)

            # Check for added items
            for item_id, new_item in new_items_dict.items():
                if item_id not in old_items_dict:
                    items_changes.append({
                        "type": "added",
                        "item_name": new_item.get("item_name"),
                        "master_item_id": item_id,
                        "selling_price": float(new_item.get("selling_price", 0))
                    })

            # Check for removed items
            for item_id, old_item in old_items_dict.items():
                if item_id not in new_items_dict:
                    items_changes.append({
                        "type": "removed",
                        "item_name": old_item.get("item_name"),
                        "master_item_id": item_id,
                        "selling_price": float(old_item.get("selling_price", 0))
                    })

            if items_changes:
                detailed_changes["items"] = items_changes

        # Create action for BOQ history with current user role and name
        update_action = {
            "type": "boq_updated",
            "role": user_role if user_role else 'system',
            "user_name": user_name,
            "user_id": user_id,
            "status": boq.status,
            "timestamp": datetime.utcnow().isoformat(),
            "updated_by": user_name,
            "updated_by_user_id": user_id,
            "boq_name": boq.boq_name,
            "total_items": len(boq_items) if "items" in data else boq_details.total_items,
            "total_cost": total_boq_cost if "items" in data else boq_details.total_cost,
            "changes": detailed_changes,
            "change_summary": {
                "boq_name_changed": bool(detailed_changes.get("boq_name")),
                "cost_changed": bool(detailed_changes.get("total_cost")),
                "items_changed": bool(detailed_changes.get("items")),
                "items_count_changed": bool(detailed_changes.get("total_items"))
            }
        }

        # Check if history entry exists for this BOQ
        existing_history = BOQHistory.query.filter_by(boq_id=boq_id).order_by(BOQHistory.action_date.desc()).first()

        if existing_history:
            # Append to existing action array
            if existing_history.action is None:
                current_actions = []
            elif isinstance(existing_history.action, list):
                current_actions = existing_history.action
            elif isinstance(existing_history.action, dict):
                current_actions = [existing_history.action]
            else:
                current_actions = []

            current_actions.append(update_action)
            existing_history.action = current_actions

            # Mark JSONB field as modified for SQLAlchemy
            flag_modified(existing_history, "action")

            existing_history.action_by = user_name
            existing_history.boq_status = boq.status
            # Add role information for admin users
            if user_role == 'admin':
                existing_history.sender_role = 'Admin'
                existing_history.comments = f"BOQ updated - Version {next_version} by Admin {user_name}"
            else:
                existing_history.sender_role = user_role.title() if user_role else None
                existing_history.comments = f"BOQ updated - Version {next_version} by {user_name}"
            existing_history.action_date = datetime.utcnow()
            existing_history.last_modified_by = user_name
            existing_history.last_modified_at = datetime.utcnow()
        else:
            # Create new history entry
            # Determine sender role for history tracking
            sender_role = 'Admin' if user_role == 'admin' else (user_role.title() if user_role else None)
            comments_text = f"BOQ updated - Version {next_version} by Admin {user_name}" if user_role == 'admin' else f"BOQ updated - Version {next_version} by {user_name}"

            boq_history = BOQHistory(
                boq_id=boq_id,
                action=[update_action],
                action_by=user_name,
                sender_role=sender_role,
                boq_status=boq.status,
                comments=comments_text,
                action_date=datetime.utcnow(),
                created_by=user_name
            )
            db.session.add(boq_history)

        # Update preliminary selections in boq_preliminaries junction table
        preliminaries = data.get("preliminaries", {})
        if preliminaries and preliminaries.get('items'):
            from models.preliminary_master import BOQPreliminary, PreliminaryMaster

            preliminary_items = preliminaries.get('items', [])
            # Delete all existing preliminary selections for this BOQ
            BOQPreliminary.query.filter_by(boq_id=boq_id).delete()
            # Insert new selections
            preliminary_selections_saved = 0
            custom_preliminaries_created = 0

            for item in preliminary_items:
                prelim_id = item.get('prelim_id')
                is_checked = item.get('checked', False) or item.get('selected', False)
                is_custom = item.get('isCustom', False)

                # Handle edited master preliminaries - update the master record
                if prelim_id and not is_custom:
                    description = item.get('description', '')
                    if description:
                        # Check if description was changed from master
                        master_prelim = PreliminaryMaster.query.get(prelim_id)
                        if master_prelim and master_prelim.description != description:
                            # Update the master preliminary description
                            master_prelim.description = description
                            master_prelim.updated_by = user_name

                # Handle custom preliminaries - create new row in preliminaries_master
                if is_custom and not prelim_id:
                    description = item.get('description', '')
                    name = item.get('name', description[:50] if description else 'Custom Item')

                    if description:  # Only create if there's a description
                        # Check if this custom preliminary already exists (by description)
                        existing_custom = PreliminaryMaster.query.filter_by(
                            description=description,
                            created_by=user_name
                        ).first()

                        if existing_custom:
                            prelim_id = existing_custom.prelim_id
                        else:
                            # Create new custom preliminary in master table
                            new_custom_prelim = PreliminaryMaster(
                                name=name,
                                description=description,
                                unit='nos',
                                rate=0,
                                is_active=True,
                                display_order=9999,  # Custom items appear at the end
                                created_by=user_name,
                                updated_by=user_name
                            )
                            db.session.add(new_custom_prelim)
                            db.session.flush()  # Get the prelim_id
                            prelim_id = new_custom_prelim.prelim_id
                            custom_preliminaries_created += 1

                if prelim_id:
                    boq_prelim = BOQPreliminary(
                        boq_id=boq_id,
                        prelim_id=prelim_id,
                        is_checked=is_checked
                    )
                    db.session.add(boq_prelim)
                    preliminary_selections_saved += 1

        # Save terms & conditions selections to boq_terms_selections (single row with term_ids array)
        terms_conditions = data.get("terms_conditions", [])
        if terms_conditions and isinstance(terms_conditions, list):
            from sqlalchemy import text
            # Extract only checked term IDs
            selected_term_ids = [
                term.get('term_id') for term in terms_conditions
                if term.get('term_id') and term.get('checked', False)
            ]

            # Insert or update single row with term_ids array
            db.session.execute(text("""
                INSERT INTO boq_terms_selections (boq_id, term_ids, created_at, updated_at)
                VALUES (:boq_id, :term_ids, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                ON CONFLICT (boq_id)
                DO UPDATE SET term_ids = :term_ids, updated_at = CURRENT_TIMESTAMP
            """), {
                'boq_id': boq_id,
                'term_ids': selected_term_ids
            })
            log.info(f"✅ Updated {len(selected_term_ids)} terms selections in boq_terms_selections for BOQ {boq_id}")

        db.session.commit()

        # Return updated BOQ
        return jsonify({
            "message": "BOQ Updated successfully",
            "success": True,
            "boq_id": boq_id,
            "version": next_version,
            "status": boq.status,
            "updated_by": user_name
        }), 200
        # return get_boq(boq_id)

    except Exception as e:
        db.session.rollback()
        log.error(f"Error updating BOQ: {str(e)}")
        return jsonify({"error": str(e)}), 500

def revision_boq(boq_id):
    """Create a revision of BOQ - stores history and increments revision number"""
    try:
        data = request.get_json()

        # Get current logged-in user
        current_user = getattr(g, 'user', None)
        user_id = current_user.get('user_id') if current_user else None
        user_role = current_user.get('role', '').lower() if current_user else ''
        user_name = current_user.get('full_name') or current_user.get('username') or 'Unknown' if current_user else 'Unknown'

        boq = BOQ.query.filter_by(boq_id=boq_id).first()

        if not boq:
            return jsonify({"error": "BOQ not found"}), 404

        # Get project for default work_type
        project = Project.query.filter_by(project_id=boq.project_id).first()
        default_work_type = project.work_type if project and project.work_type else "contract"

        # Get existing BOQ details BEFORE any updates
        boq_details = BOQDetails.query.filter_by(boq_id=boq_id).first()
        if not boq_details:
            return jsonify({"error": "BOQ details not found"}), 404

        # Store old values before updating (for change tracking)
        # IMPORTANT: Use deepcopy to create independent copy of JSON data
        import copy
        old_boq_name = boq.boq_name
        old_status = boq.status
        old_revision_number = boq.revision_number or 0
        old_total_cost = boq_details.total_cost
        old_total_items = boq_details.total_items
        old_boq_details_json = copy.deepcopy(boq_details.boq_details)  # Deep copy to prevent reference issues

        # Update BOQ basic details
        if "boq_name" in data:
            boq.boq_name = data["boq_name"]

        # Check if this is a revision edit (from Revisions button)
        is_revision = data.get("is_revision", False)

        # Set current_status BEFORE using it
        current_status = old_status

        # This ensures revision increments each time estimator starts revising after sending to client
        statuses_that_start_new_revision = ["Client_Rejected", "Sent_for_Confirmation"]

        if is_revision and current_status in statuses_that_start_new_revision:
            boq.revision_number = (boq.revision_number or 0) + 1

        new_revision_number = boq.revision_number or 0

        # Set status based on current status and revision mode
        if is_revision:
            # If this is a revision edit, always set to Under_Revision
            boq.status = "Under_Revision"
        elif current_status == "Client_Rejected":
            boq.status = "Under_Revision"
        elif current_status == "Rejected":
            # If TD rejected, keep as Under_Revision when editing
            boq.status = "Under_Revision"
        elif current_status in ["Sent_for_Confirmation", "Pending_Revision", "Pending", "Approved", "Client_Confirmed", "Under_Revision"]:
            # Keep the current status (don't change workflow statuses)
            pass
        else:
            boq.status = boq.status

        # Update last modified by and timestamp
        boq.last_modified_by = user_name
        boq.last_modified_at = datetime.utcnow()
        next_version = old_revision_number

        # Initialize variables used later in the function
        boq_items = []
        total_boq_cost = 0

        # ========== FIRST TIME EDIT: SAVE ORIGINAL BOQ TO HISTORY ==========
        # Check if this is the first edit (no history exists for this BOQ)
        existing_history_count = BOQDetailsHistory.query.filter_by(
            boq_id=boq_id
        ).count()

        if existing_history_count == 0 and old_boq_details_json:
            # This is the first edit - save the ORIGINAL/CURRENT BOQ data to history
            log.info(f"📝 First edit detected for BOQ {boq_id} - storing original BOQ to history")

            # Calculate totals from original BOQ data
            original_items = old_boq_details_json.get("items", [])
            original_total_items = len(original_items)
            original_total_materials = 0
            original_total_labour = 0
            original_total_cost = 0

            for item in original_items:
                # Get selling price from original data
                original_total_cost += item.get("selling_price", 0) or item.get("total_selling_price", 0) or 0

                # Count materials and labour from sub_items
                for sub_item in item.get("sub_items", []):
                    original_total_materials += len(sub_item.get("materials", []))
                    original_total_labour += len(sub_item.get("labour", []))

            # Create history entry for ORIGINAL BOQ data (version 0)
            original_boq_history = BOQDetailsHistory(
                boq_detail_id=boq_details.boq_detail_id,
                boq_id=boq_id,
                version=0,  # Version 0 = original BOQ before any edits
                boq_details=old_boq_details_json,  # Store original data
                total_cost=old_total_cost or original_total_cost,
                total_items=old_total_items or original_total_items,
                total_materials=original_total_materials,
                total_labour=original_total_labour,
                created_by=f"System (Original by {boq.created_by})"
            )
            db.session.add(original_boq_history)
            log.info(f"✅ Stored original BOQ data to history for BOQ {boq_id} (version 0)")

        # Store the payload directly in BOQDetailsHistory without recalculation
        if data.get("is_revision", False) and "items" in data:
            # Create history entry with payload data directly (no recalculation)
            import copy
            payload_copy = copy.deepcopy(data)

            # Calculate totals from payload as-is
            boq_items = data.get("items", [])  # Use payload items directly
            total_items = len(boq_items)
            total_materials = 0
            total_labour = 0
            total_cost = 0

            for item in boq_items:
                # Get selling price from payload directly
                total_cost += item.get("selling_price", 0)

                # Count materials and labour from sub_items
                for sub_item in item.get("sub_items", []):
                    total_materials += len(sub_item.get("materials", []))
                    total_labour += len(sub_item.get("labour", []))

            # Set total_boq_cost for later use
            total_boq_cost = total_cost

            # ========== DETERMINE VERSION NUMBER FOR EDITED BOQ ==========
            # Get the latest version from history to determine next version number
            latest_history = BOQDetailsHistory.query.filter_by(
                boq_id=boq_id
            ).order_by(BOQDetailsHistory.version.desc()).first()

            if latest_history:
                # Increment from the latest version
                edited_version = latest_history.version + 1
            else:
                # This shouldn't happen since we just added version 0, but fallback to next_version
                edited_version = next_version if next_version > 0 else 1

            log.info(f"📝 Storing edited BOQ to history for BOQ {boq_id} (version {edited_version})")

            # Create BOQDetailsHistory entry with the raw payload
            boq_detail_history = BOQDetailsHistory(
                boq_detail_id=boq_details.boq_detail_id,
                boq_id=boq_id,
                version=edited_version,
                boq_details=payload_copy,  # Store payload directly as-is
                total_cost=total_cost,
                total_items=total_items,
                total_materials=total_materials,
                total_labour=total_labour,
                created_by=user_name
            )
            db.session.add(boq_detail_history)

            # Also update BOQDetails with the raw payload (no recalculation)
            boq_details.boq_details = payload_copy
            flag_modified(boq_details, 'boq_details')
            boq_details.total_cost = total_cost
            boq_details.total_items = total_items
            boq_details.total_materials = total_materials
            boq_details.total_labour = total_labour
            boq_details.last_modified_by = user_name

            # ===== MASTER TABLES SYNC =====
            # Process ALL items to store/update in master tables (handles all 3 scenarios)
            # Scenario 1: New item + new sub-items + materials/labour
            # Scenario 2: Existing item + new sub-items + materials/labour
            # Scenario 3: Existing sub-item + new materials/labour
            created_by = user_name

            for idx, item_data in enumerate(boq_items):
                # Check if item has sub_items structure
                if "sub_items" in item_data and item_data.get("sub_items"):
                    # Get item-level data
                    item_quantity = clean_numeric_value(item_data.get("quantity", 1.0))
                    item_rate = clean_numeric_value(item_data.get("rate", 0.0))
                    item_unit = item_data.get("unit", "nos")
                    item_total = item_quantity * item_rate

                    # Get percentages
                    miscellaneous_percentage = clean_numeric_value(item_data.get("overhead_percentage", 10.0))
                    overhead_profit_percentage = clean_numeric_value(item_data.get("profit_margin_percentage", 15.0))

                    # Calculate amounts
                    total_miscellaneous_amount = (item_total * miscellaneous_percentage) / 100
                    total_overhead_profit_amount = (item_total * overhead_profit_percentage) / 100

                    # Add item to master tables (or update if exists)
                    master_item_id, _, _ = add_to_master_tables(
                        item_data.get("item_name"),
                        item_data.get("description", ""),
                        item_data.get("work_type", default_work_type),
                        [],  # Don't add materials here, will add per sub-item
                        [],  # Don't add labour here, will add per sub-item
                        created_by,
                        miscellaneous_percentage,
                        total_miscellaneous_amount,
                        overhead_profit_percentage,
                        total_overhead_profit_amount,
                        overhead_profit_percentage,
                        total_overhead_profit_amount,
                        clean_numeric_value(item_data.get("discount_percentage", 0.0)),
                        clean_numeric_value(item_data.get("discount_amount", 0.0)),
                        clean_numeric_value(item_data.get("vat_percentage", 0.0)),
                        clean_numeric_value(item_data.get("vat_amount", 0.0)),
                        unit=item_unit,
                        quantity=item_quantity,
                        per_unit_cost=item_rate,
                        total_amount=item_total,
                        item_total_cost=item_total
                    )

                    # Update master_item_id in the item data
                    item_data["master_item_id"] = master_item_id
                    payload_copy["items"][idx]["master_item_id"] = master_item_id

                    # Process sub-items with their materials and labour
                    sub_items_list = item_data.get("sub_items", [])
                    if sub_items_list:
                        master_sub_item_ids = add_sub_items_to_master_tables(
                            master_item_id,
                            sub_items_list,
                            created_by
                        )

                        # Add master sub-item IDs back to payload
                        for sub_idx, sub_item_id in enumerate(master_sub_item_ids):
                            if sub_idx < len(sub_items_list):
                                sub_items_list[sub_idx]["sub_item_id"] = sub_item_id
                                sub_items_list[sub_idx]["master_sub_item_id"] = sub_item_id
                                payload_copy["items"][idx]["sub_items"][sub_idx]["sub_item_id"] = sub_item_id
                                payload_copy["items"][idx]["sub_items"][sub_idx]["master_sub_item_id"] = sub_item_id

            # Update boq_details and history with master IDs
            boq_details.boq_details = payload_copy
            flag_modified(boq_details, 'boq_details')
            boq_detail_history.boq_details = payload_copy
            # ===== END MASTER TABLES SYNC =====

            # Save preliminary selections to boq_preliminaries junction table
            preliminaries_data = data.get("preliminaries", {})
            if preliminaries_data and isinstance(preliminaries_data, dict):
                prelim_items = preliminaries_data.get("items", [])
                if prelim_items:
                    # Delete existing preliminary selections for this BOQ
                    BOQPreliminary.query.filter_by(boq_id=boq_id).delete()

                    # Insert new selections
                    for prelim in prelim_items:
                        prelim_id = prelim.get('prelim_id')
                        is_checked = prelim.get('checked', False) or prelim.get('selected', False)

                        if prelim_id:  # Only save master preliminary items
                            boq_prelim = BOQPreliminary(
                                boq_id=boq_id,
                                prelim_id=prelim_id,
                                is_checked=is_checked
                            )
                            db.session.add(boq_prelim)
                    log.info(f"✅ Updated preliminary selections in boq_preliminaries for BOQ {boq_id} during revision")

            # Save terms & conditions selections to boq_terms_selections (single row with term_ids array)
            terms_conditions = data.get("terms_conditions", [])
            if terms_conditions and isinstance(terms_conditions, list):
                from sqlalchemy import text
                # Extract only checked term IDs
                selected_term_ids = [
                    term.get('term_id') for term in terms_conditions
                    if term.get('term_id') and term.get('checked', False)
                ]

                # Insert or update single row with term_ids array
                db.session.execute(text("""
                    INSERT INTO boq_terms_selections (boq_id, term_ids, created_at, updated_at)
                    VALUES (:boq_id, :term_ids, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    ON CONFLICT (boq_id)
                    DO UPDATE SET term_ids = :term_ids, updated_at = CURRENT_TIMESTAMP
                """), {
                    'boq_id': boq_id,
                    'term_ids': selected_term_ids
                })
                log.info(f"✅ Updated {len(selected_term_ids)} terms selections in boq_terms_selections for BOQ {boq_id} during revision")

        # If items are provided, update the JSON structure (for non-revision updates)
        elif "items" in data:
            # Use the same current user logic for BOQ details
            current_user = getattr(g, 'user', None)
            if current_user:
                created_by = current_user.get('username') or current_user.get('full_name') or current_user.get('user_id', 'Admin')
            else:
                created_by = data.get("modified_by", "Admin")

            # Process updated items
            boq_items = []
            total_boq_cost = 0
            total_materials = 0
            total_labour = 0

            for item_data in data["items"]:
                # Check if item has sub_items structure (new format)
                has_sub_items = "sub_items" in item_data and item_data.get("sub_items")

                if has_sub_items:
                    # NEW FORMAT: Item with sub_items structure - preserve scope and size
                    sub_items_list = []
                    materials_count = 0
                    labour_count = 0

                    # Get item-level quantity and rate
                    item_quantity = clean_numeric_value(item_data.get("quantity", 1.0))
                    item_rate = clean_numeric_value(item_data.get("rate", 0.0))
                    item_unit = item_data.get("unit", "nos")
                    item_total = item_quantity * item_rate

                    # Get percentages
                    miscellaneous_percentage = clean_numeric_value(item_data.get("overhead_percentage", 10.0))
                    overhead_profit_percentage = clean_numeric_value(item_data.get("profit_margin_percentage", 15.0))
                    discount_percentage = clean_numeric_value(item_data.get("discount_percentage", 0.0))
                    vat_percentage = clean_numeric_value(item_data.get("vat_percentage", 0.0))

                    # Calculate amounts
                    total_miscellaneous_amount = (item_total * miscellaneous_percentage) / 100
                    total_overhead_profit_amount = (item_total * overhead_profit_percentage) / 100
                    total_subtotal = item_total + total_miscellaneous_amount + total_overhead_profit_amount
                    total_discount_amount = (total_subtotal * discount_percentage) / 100 if discount_percentage > 0 else 0.0
                    total_after_discount = total_subtotal - total_discount_amount
                    total_vat_amount = (total_after_discount * vat_percentage) / 100 if vat_percentage > 0 else 0.0
                    total_selling_price = total_after_discount + total_vat_amount

                    # Process sub_items
                    for idx, sub_item_data in enumerate(item_data.get("sub_items", [])):
                        sub_item_quantity = clean_numeric_value(sub_item_data.get("quantity", 1.0))
                        sub_item_unit = sub_item_data.get("unit", "nos")
                        sub_item_rate = clean_numeric_value(sub_item_data.get("rate", 0.0))
                        sub_item_base_total = sub_item_quantity * sub_item_rate

                        # Process materials for this sub-item
                        sub_item_materials = []
                        materials_cost = 0
                        for mat_data in sub_item_data.get("materials", []):
                            material_name = mat_data.get("material_name", "").strip()
                            # Skip materials with empty or null names
                            if not material_name:
                                continue

                            quantity = clean_numeric_value(mat_data.get("quantity", 1.0))
                            unit_price = clean_numeric_value(mat_data.get("unit_price", 0.0))
                            total_price = quantity * unit_price
                            materials_cost += total_price

                            sub_item_materials.append({
                                "material_name": material_name,
                                "location": mat_data.get("location", ""),
                                "brand": mat_data.get("brand", ""),
                                "size": mat_data.get("size", ""),
                                "specification": mat_data.get("specification", ""),
                                "description": mat_data.get("description", ""),
                                "quantity": quantity,
                                "unit": mat_data.get("unit", "nos"),
                                "unit_price": unit_price,
                                "total_price": total_price,
                                "vat_percentage": clean_numeric_value(mat_data.get("vat_percentage", 0.0))
                            })

                        # Process labour for this sub-item
                        sub_item_labour = []
                        labour_cost = 0
                        for labour_data_item in sub_item_data.get("labour", []):
                            labour_role = labour_data_item.get("labour_role", "").strip()
                            # Skip labour with empty or null roles
                            if not labour_role:
                                continue

                            hours = clean_numeric_value(labour_data_item.get("hours", 0.0))
                            rate_per_hour = clean_numeric_value(labour_data_item.get("rate_per_hour", 0.0))
                            total_cost_labour = hours * rate_per_hour
                            labour_cost += total_cost_labour

                            sub_item_labour.append({
                                "labour_role": labour_role,
                                "work_type": labour_data_item.get("work_type", "daily_wages"),
                                "hours": hours,
                                "rate_per_hour": rate_per_hour,
                                "total_cost": total_cost_labour
                            })

                        # Create sub-item JSON with scope and size
                        sub_item_json = {
                            "sub_item_name": sub_item_data.get("sub_item_name"),
                            "scope": sub_item_data.get("scope", ""),
                            "size": sub_item_data.get("size", ""),
                            "description": sub_item_data.get("description", ""),
                            "location": sub_item_data.get("location", ""),
                            "brand": sub_item_data.get("brand", ""),
                            "quantity": sub_item_quantity,
                            "unit": sub_item_unit,
                            "rate": sub_item_rate,
                            "per_unit_cost": sub_item_rate,  # Added for master table
                            "base_total": sub_item_base_total,
                            "sub_item_total_cost": sub_item_base_total,  # Added for master table
                            "materials_cost": materials_cost,
                            "labour_cost": labour_cost,
                            "material_cost": materials_cost,  # Added for master table (uses singular)
                            "internal_cost": sub_item_data.get("internal_cost", 0.0),
                            "planned_profit": sub_item_data.get("planned_profit", 0.0),
                            "actual_profit": sub_item_data.get("actual_profit", 0.0),
                            "negotiable_margin": sub_item_data.get("actual_profit", 0.0),  # Same as actual_profit
                            "misc_percentage": sub_item_data.get("misc_percentage", 10.0),
                            "misc_amount": sub_item_data.get("misc_amount", 0.0),
                            "overhead_profit_percentage": sub_item_data.get("overhead_profit_percentage", 25.0),
                            "overhead_profit_amount": sub_item_data.get("overhead_profit_amount", 0.0),
                            "transport_percentage": sub_item_data.get("transport_percentage", 5.0),
                            "transport_amount": sub_item_data.get("transport_amount", 0.0),
                            "materials": sub_item_materials,
                            "labour": sub_item_labour
                        }

                        # PRESERVE sub_item_id if it exists in the input data
                        if "sub_item_id" in sub_item_data:
                            sub_item_json["sub_item_id"] = sub_item_data["sub_item_id"]
                        if "master_sub_item_id" in sub_item_data:
                            sub_item_json["master_sub_item_id"] = sub_item_data["master_sub_item_id"]

                        sub_items_list.append(sub_item_json)
                        materials_count += len(sub_item_materials)
                        labour_count += len(sub_item_labour)

                    # Calculate total materials and labour costs from all sub-items
                    total_materials_cost = sum(si.get("materials_cost", 0) for si in sub_items_list)
                    total_labour_cost = sum(si.get("labour_cost", 0) for si in sub_items_list)
                    base_cost = total_materials_cost + total_labour_cost

                    # Create item JSON with sub_items
                    item_json = {
                        "item_name": item_data.get("item_name"),
                        "description": item_data.get("description", ""),
                        "work_type": item_data.get("work_type", default_work_type),
                        "has_sub_items": True,
                        "sub_items": sub_items_list,
                        "quantity": item_quantity,
                        "unit": item_unit,
                        "rate": item_rate,
                        "item_total": item_total,
                        "base_cost": base_cost,
                        "sub_items_cost": base_cost,
                        "total_selling_price": total_selling_price,
                        "selling_price": total_selling_price,
                        "estimatedSellingPrice": total_selling_price,
                        "actualItemCost": base_cost,
                        "total_cost": total_selling_price,
                        "overhead_percentage": miscellaneous_percentage,
                        "overhead_amount": total_miscellaneous_amount,
                        "profit_margin_percentage": overhead_profit_percentage,
                        "profit_margin_amount": total_overhead_profit_amount,
                        "subtotal": total_subtotal,
                        "discount_percentage": discount_percentage,
                        "discount_amount": total_discount_amount,
                        "vat_percentage": vat_percentage,
                        "vat_amount": total_vat_amount,
                        "totalMaterialCost": total_materials_cost,
                        "totalLabourCost": total_labour_cost
                    }

                    # Add/Update to master tables
                    # Step 1: Add item to boq_items table
                    master_item_id, _, _ = add_to_master_tables(
                        item_data.get("item_name"),
                        item_data.get("description", ""),
                        item_data.get("work_type", default_work_type),
                        [],  # Don't add materials here, will add per sub-item
                        [],  # Don't add labour here, will add per sub-item
                        created_by,
                        miscellaneous_percentage,
                        total_miscellaneous_amount,
                        overhead_profit_percentage,
                        total_overhead_profit_amount,
                        overhead_profit_percentage,
                        total_overhead_profit_amount,
                        discount_percentage,
                        total_discount_amount,
                        vat_percentage,
                        total_vat_amount,
                        unit=item_unit,
                        quantity=item_quantity,
                        per_unit_cost=item_rate,
                        total_amount=item_total,
                        item_total_cost=item_total
                    )

                    # Step 2: Add sub-items to boq_sub_items table, and their materials & labour
                    master_sub_item_ids = []
                    if sub_items_list:
                        # Pass the processed sub_items_list that contains materials and labour
                        master_sub_item_ids = add_sub_items_to_master_tables(
                            master_item_id,
                            sub_items_list,
                            created_by
                        )

                        # Assign master sub-item IDs back to the sub_items in item_json
                        # This ensures sub_item_id is preserved for future edits
                        for idx, sub_item_id in enumerate(master_sub_item_ids):
                            if idx < len(item_json.get("sub_items", [])):
                                # Only assign if not already present (preserve existing IDs)
                                if "sub_item_id" not in item_json["sub_items"][idx]:
                                    item_json["sub_items"][idx]["sub_item_id"] = sub_item_id
                                if "master_sub_item_id" not in item_json["sub_items"][idx]:
                                    item_json["sub_items"][idx]["master_sub_item_id"] = sub_item_id

                    boq_items.append(item_json)
                    total_boq_cost += total_selling_price
                    total_materials += materials_count
                    total_labour += labour_count

                else:
                    # OLD FORMAT: Item without sub_items (materials/labour directly on item)
                    materials_data = item_data.get("materials", [])
                    labour_data = item_data.get("labour", [])

                    # Calculate costs first to get overhead and profit amounts
                    materials_cost = 0
                    labour_cost = 0

                    # Calculate material and labour costs
                    for mat_data in materials_data:
                        quantity = mat_data.get("quantity", 1.0)
                        unit_price = mat_data.get("unit_price", 0.0)
                        materials_cost += quantity * unit_price

                    for labour_data_item in labour_data:
                        hours = labour_data_item.get("hours", 0.0)
                        rate_per_hour = labour_data_item.get("rate_per_hour", 0.0)
                        labour_cost += hours * rate_per_hour

                    # Calculate item costs
                    base_cost = materials_cost + labour_cost

                    # Use provided percentages, default to 10% overhead and 15% profit if not provided
                    overhead_percentage = item_data.get("overhead_percentage", 10.0)
                    profit_margin_percentage = item_data.get("profit_margin_percentage", 15.0)

                    # Calculate amounts based on percentages
                    overhead_amount = (base_cost * overhead_percentage) / 100
                    profit_margin_amount = (base_cost * profit_margin_percentage) / 100
                    total_cost = base_cost + overhead_amount
                    selling_price = total_cost + profit_margin_amount

                    # Handle discount (can be null or a value)
                    discount_percentage = item_data.get("discount_percentage")
                    discount_amount = 0.0
                    after_discount = selling_price

                    if discount_percentage is not None and discount_percentage > 0:
                        discount_amount = (selling_price * float(discount_percentage)) / 100
                        after_discount = selling_price - discount_amount

                    # Handle VAT - check if using per-material VAT or item-level VAT
                    vat_percentage = item_data.get("vat_percentage", 0.0)
                    vat_amount = 0.0
                    final_selling_price = after_discount

                    # Check if any material has VAT percentage defined (per-material mode)
                    has_material_vat = any(mat.get("vat_percentage") is not None and mat.get("vat_percentage", 0) > 0 for mat in materials_data)

                    if has_material_vat:
                        # Per-material VAT mode: Calculate VAT for each material
                        for mat_data in materials_data:
                            mat_vat_pct = mat_data.get("vat_percentage", 0.0)
                            if mat_vat_pct and mat_vat_pct > 0:
                                mat_total = mat_data.get("quantity", 0) * mat_data.get("unit_price", 0)
                                vat_amount += (mat_total * float(mat_vat_pct)) / 100
                        final_selling_price = after_discount + vat_amount
                    elif vat_percentage is not None and vat_percentage > 0:
                        # Item-level VAT mode: Apply single VAT to after-discount amount
                        vat_amount = (after_discount * float(vat_percentage)) / 100
                        final_selling_price = after_discount + vat_amount

                    # Add new items/materials/labour to master tables with calculated values
                    master_item_id, master_material_ids, master_labour_ids = add_to_master_tables(
                        item_data.get("item_name"),
                        item_data.get("description"),
                        item_data.get("work_type", default_work_type),
                        materials_data,
                        labour_data,
                        created_by,
                        overhead_percentage,
                        overhead_amount,
                        profit_margin_percentage,
                        profit_margin_amount
                    )

                    # Process materials with master IDs
                    processed_materials = []
                    for i, mat_data in enumerate(materials_data):
                        quantity = mat_data.get("quantity", 1.0)
                        unit_price = mat_data.get("unit_price", 0.0)
                        total_price = quantity * unit_price
                        vat_pct = mat_data.get("vat_percentage", 0.0)

                        processed_materials.append({
                            "master_material_id": master_material_ids[i] if i < len(master_material_ids) else None,
                            "material_name": mat_data.get("material_name"),
                            "description": mat_data.get("description", ""),
                            "quantity": quantity,
                            "unit": mat_data.get("unit", "nos"),
                            "unit_price": unit_price,
                            "total_price": total_price,
                            "vat_percentage": vat_pct if vat_pct else 0.0
                        })

                    # Process labour with master IDs
                    processed_labour = []
                    for i, labour_data_item in enumerate(labour_data):
                        hours = labour_data_item.get("hours", 0.0)
                        rate_per_hour = labour_data_item.get("rate_per_hour", 0.0)
                        total_cost_labour = hours * rate_per_hour

                        processed_labour.append({
                            "master_labour_id": master_labour_ids[i] if i < len(master_labour_ids) else None,
                            "labour_role": labour_data_item.get("labour_role"),
                            "hours": hours,
                            "rate_per_hour": rate_per_hour,
                            "total_cost": total_cost_labour
                        })

                    # Build updated item JSON
                    item_json = {
                        "master_item_id": master_item_id,
                        "item_name": item_data.get("item_name"),
                        "description": item_data.get("description"),
                        "work_type": item_data.get("work_type"),
                        "base_cost": base_cost,
                        "overhead_percentage": overhead_percentage,
                        "overhead_amount": overhead_amount,
                        "profit_margin_percentage": profit_margin_percentage,
                        "profit_margin_amount": profit_margin_amount,
                        "discount_percentage": discount_percentage if discount_percentage is not None else 0.0,
                        "discount_amount": discount_amount,
                        "vat_percentage": vat_percentage if vat_percentage is not None else 0.0,
                        "vat_amount": vat_amount,
                        "total_cost": total_cost,
                        "selling_price": final_selling_price,  # Use final_selling_price after discount and VAT
                        "selling_price_before_discount": selling_price,  # Original selling price
                        "totalMaterialCost": materials_cost,
                        "totalLabourCost": labour_cost,
                        "actualItemCost": base_cost,
                        "estimatedSellingPrice": final_selling_price,  # Use final_selling_price after discount and VAT
                        "materials": processed_materials,
                        "labour": processed_labour
                    }

                    boq_items.append(item_json)
                    total_boq_cost += final_selling_price  # Add final price after discount to total
                    total_materials += len(materials_data)
                    total_labour += len(labour_data)

            # Get preliminaries from request data (for discount calculation only)
            preliminaries = data.get("preliminaries", {})

            # NOTE: Preliminary updates are now handled by dedicated /preliminary/{project_id} endpoint
            # to prevent race conditions and data conflicts. This section only reads preliminary data
            # for discount calculations, it does not save/update preliminary records.
            preliminary_id = old_boq_details_json.get("preliminary_id") if old_boq_details_json else None

            # Note: Old preliminary system removed - preliminary_id no longer used
            # preliminary_id = None  # Kept for backward compatibility but not used

            # Apply BOQ-level discount to total
            boq_discount_percentage = data.get("discount_percentage", old_boq_details_json.get("discount_percentage", 0)) or 0
            boq_discount_amount = data.get("discount_amount", old_boq_details_json.get("discount_amount", 0)) or 0

            # Get preliminary amount to include in discount calculation
            preliminary_amount = preliminaries.get('cost_details', {}).get('amount', 0) if preliminaries else 0

            # Combined subtotal = items total + preliminary amount
            combined_subtotal = total_boq_cost + preliminary_amount

            # Calculate discount amount if only percentage is provided
            # Discount should be calculated on combined subtotal (items + preliminaries)
            if boq_discount_amount == 0 and boq_discount_percentage > 0 and combined_subtotal > 0:
                boq_discount_amount = combined_subtotal * (boq_discount_percentage / 100)

            # Apply BOQ-level discount to get final total
            final_boq_cost = combined_subtotal - boq_discount_amount if boq_discount_amount > 0 else combined_subtotal

            log.info(f"BOQ {boq.boq_id} revision update totals - Items: {total_boq_cost}, Preliminaries: {preliminary_amount}, Combined: {combined_subtotal}, Discount: {boq_discount_amount} ({boq_discount_percentage}%), Final: {final_boq_cost}")

            # Store new items, sub-items, and materials to master tables
            for item_data in boq_items:
                # Check if item has sub_items structure
                if item_data.get("has_sub_items") and "sub_items" in item_data:
                    # NEW FORMAT: Item with sub_items
                    # 1. Store/Update Item in boq_items table
                    item_name = item_data.get("item_name")
                    existing_item = MasterItem.query.filter_by(item_name=item_name).first()

                    if not existing_item:
                        new_item = MasterItem(
                            item_name=item_name,
                            description=item_data.get("description", ""),
                            unit=item_data.get("unit", "nos"),
                            quantity=item_data.get("quantity", 1.0),
                            per_unit_cost=item_data.get("rate", 0.0),
                            total_amount=item_data.get("item_total", 0.0),
                            item_total_cost=item_data.get("base_cost", 0.0),
                            overhead_percentage=item_data.get("overhead_percentage", 10.0),
                            overhead_amount=item_data.get("overhead_amount", 0.0),
                            profit_margin_percentage=item_data.get("profit_margin_percentage", 15.0),
                            profit_margin_amount=item_data.get("profit_margin_amount", 0.0),
                            discount_percentage=item_data.get("discount_percentage", 0.0),
                            discount_amount=item_data.get("discount_amount", 0.0),
                            vat_percentage=item_data.get("vat_percentage", 0.0),
                            vat_amount=item_data.get("vat_amount", 0.0),
                            is_active=True,
                            created_by=user_name
                        )
                        db.session.add(new_item)
                        db.session.flush()  # Get the item_id
                        master_item_id = new_item.item_id

                        # Update item_data with master_item_id
                        item_data["master_item_id"] = master_item_id
                    else:
                        master_item_id = existing_item.item_id
                        if "master_item_id" not in item_data:
                            item_data["master_item_id"] = master_item_id

                    # 2. Process sub_items for this item
                    for sub_item_data in item_data.get("sub_items", []):
                        sub_item_name = sub_item_data.get("sub_item_name")

                        # Check if sub_item already exists for this item
                        existing_sub_item = MasterSubItem.query.filter_by(
                            item_id=master_item_id,
                            sub_item_name=sub_item_name
                        ).first()

                        if not existing_sub_item:
                            new_sub_item = MasterSubItem(
                                item_id=master_item_id,
                                sub_item_name=sub_item_name,
                                description=sub_item_data.get("description", ""),
                                size=sub_item_data.get("size", ""),
                                location=sub_item_data.get("location", ""),
                                brand=sub_item_data.get("brand", ""),
                                unit=sub_item_data.get("unit", "nos"),
                                quantity=sub_item_data.get("quantity", 1.0),
                                per_unit_cost=sub_item_data.get("rate", 0.0),
                                sub_item_total_cost=sub_item_data.get("base_total", 0.0),
                                material_cost=sub_item_data.get("materials_cost", 0.0),
                                labour_cost=sub_item_data.get("labour_cost", 0.0),
                                is_active=True,
                                created_by=user_name
                            )
                            db.session.add(new_sub_item)
                            db.session.flush()  # Get the sub_item_id
                            master_sub_item_id = new_sub_item.sub_item_id

                            # Update sub_item_data with master_sub_item_id
                            sub_item_data["master_sub_item_id"] = master_sub_item_id
                        else:
                            master_sub_item_id = existing_sub_item.sub_item_id
                            if "master_sub_item_id" not in sub_item_data:
                                sub_item_data["master_sub_item_id"] = master_sub_item_id

                        # 3. Process materials for this sub_item
                        for material_data in sub_item_data.get("materials", []):
                            material_name = material_data.get("material_name")

                            # Check if material already exists
                            existing_material = MasterMaterial.query.filter_by(
                                material_name=material_name
                            ).first()

                            if not existing_material:
                                new_material = MasterMaterial(
                                    material_name=material_name,
                                    item_id=master_item_id,
                                    sub_item_id=master_sub_item_id,
                                    description=material_data.get("description", ""),
                                    brand=material_data.get("brand", ""),
                                    size=material_data.get("size", ""),
                                    specification=material_data.get("specification", ""),
                                    quantity=material_data.get("quantity", 1.0),
                                    default_unit=material_data.get("unit", "nos"),
                                    current_market_price=material_data.get("unit_price", 0.0),
                                    total_price=material_data.get("total_price", 0.0),
                                    vat_percentage=material_data.get("vat_percentage", 0.0),
                                    is_active=True,
                                    created_by=user_name,
                                    last_modified_by=user_name
                                )
                                db.session.add(new_material)
                                db.session.flush()  # Get the material_id
                                master_material_id = new_material.material_id

                                # Update material_data with master_material_id
                                material_data["master_material_id"] = master_material_id
                            else:
                                if "master_material_id" not in material_data:
                                    material_data["master_material_id"] = existing_material.material_id

                        # 4. Process labour for this sub_item
                        for labour_data_item in sub_item_data.get("labour", []):
                            labour_role = labour_data_item.get("labour_role")

                            # Check if labour already exists
                            existing_labour = MasterLabour.query.filter_by(
                                labour_role=labour_role
                            ).first()

                            if not existing_labour:
                                new_labour = MasterLabour(
                                    labour_role=labour_role,
                                    item_id=master_item_id,
                                    sub_item_id=master_sub_item_id,
                                    hours=labour_data_item.get("hours", 0.0),
                                    rate_per_hour=labour_data_item.get("rate_per_hour", 0.0),
                                    amount=labour_data_item.get("total_cost", 0.0),
                                    is_active=True,
                                    created_by=user_name
                                )
                                db.session.add(new_labour)
                                db.session.flush()  # Get the labour_id
                                master_labour_id = new_labour.labour_id

                                # Update labour_data with master_labour_id
                                labour_data_item["master_labour_id"] = master_labour_id
                            else:
                                if "master_labour_id" not in labour_data_item:
                                    labour_data_item["master_labour_id"] = existing_labour.labour_id

            # Update JSON structure
            updated_json = {
                "boq_id": boq.boq_id,
                "preliminaries": preliminaries,
                "preliminary_id": preliminary_id,
                "discount_percentage": boq_discount_percentage,
                "discount_amount": boq_discount_amount,
                "items": boq_items,
                "summary": {
                    "total_items": len(boq_items),
                    "total_materials": total_materials,
                    "total_labour": total_labour,
                    "total_material_cost": sum(item["totalMaterialCost"] for item in boq_items),
                    "total_labour_cost": sum(item["totalLabourCost"] for item in boq_items),
                    "total_cost": final_boq_cost,
                    "selling_price": final_boq_cost,
                    "estimatedSellingPrice": final_boq_cost
                }
            }

            # Update BOQ details
            boq_details.boq_details = updated_json
            flag_modified(boq_details, 'boq_details')
            boq_details.total_cost = final_boq_cost
            boq_details.total_items = len(boq_items)
            boq_details.total_materials = total_materials
            boq_details.total_labour = total_labour
            boq_details.last_modified_by = created_by

        # Track detailed changes
        detailed_changes = {}

        # Check BOQ name change
        if old_boq_name != boq.boq_name:
            detailed_changes["boq_name"] = {
                "old": old_boq_name,
                "new": boq.boq_name
            }

        # Check total cost change
        new_total_cost = total_boq_cost if "items" in data else boq_details.total_cost
        if old_total_cost != new_total_cost:
            detailed_changes["total_cost"] = {
                "old": float(old_total_cost) if old_total_cost else 0,
                "new": float(new_total_cost) if new_total_cost else 0,
                "difference": float(new_total_cost - old_total_cost) if old_total_cost and new_total_cost else 0
            }

        # Check total items change
        new_total_items = len(boq_items) if "items" in data else boq_details.total_items
        if old_total_items != new_total_items:
            detailed_changes["total_items"] = {
                "old": old_total_items,
                "new": new_total_items,
                "difference": new_total_items - old_total_items if old_total_items and new_total_items else 0
            }

        # Track item-level changes (if items were updated)
        if "items" in data and old_boq_details_json and "items" in old_boq_details_json:
            items_changes = []
            old_items = old_boq_details_json.get("items", [])
            new_items = boq_items

            # Create dictionaries for easier lookup
            old_items_dict = {item.get("master_item_id"): item for item in old_items if item.get("master_item_id")}
            new_items_dict = {item.get("master_item_id"): item for item in new_items if item.get("master_item_id")}

            # Check for modified items
            for item_id, new_item in new_items_dict.items():
                if item_id in old_items_dict:
                    old_item = old_items_dict[item_id]
                    item_change = {"item_name": new_item.get("item_name"), "master_item_id": item_id}

                    # Check specific field changes
                    if old_item.get("base_cost") != new_item.get("base_cost"):
                        item_change["base_cost"] = {
                            "old": float(old_item.get("base_cost", 0)),
                            "new": float(new_item.get("base_cost", 0))
                        }

                    if old_item.get("selling_price") != new_item.get("selling_price"):
                        item_change["selling_price"] = {
                            "old": float(old_item.get("selling_price", 0)),
                            "new": float(new_item.get("selling_price", 0))
                        }

                    if old_item.get("overhead_percentage") != new_item.get("overhead_percentage"):
                        item_change["overhead_percentage"] = {
                            "old": float(old_item.get("overhead_percentage", 0)),
                            "new": float(new_item.get("overhead_percentage", 0))
                        }

                    if old_item.get("profit_margin_percentage") != new_item.get("profit_margin_percentage"):
                        item_change["profit_margin_percentage"] = {
                            "old": float(old_item.get("profit_margin_percentage", 0)),
                            "new": float(new_item.get("profit_margin_percentage", 0))
                        }

                    # Check material changes
                    old_materials_count = len(old_item.get("materials", []))
                    new_materials_count = len(new_item.get("materials", []))
                    if old_materials_count != new_materials_count:
                        item_change["materials_count"] = {
                            "old": old_materials_count,
                            "new": new_materials_count
                        }

                    # Check labour changes
                    old_labour_count = len(old_item.get("labour", []))
                    new_labour_count = len(new_item.get("labour", []))
                    if old_labour_count != new_labour_count:
                        item_change["labour_count"] = {
                            "old": old_labour_count,
                            "new": new_labour_count
                        }

                    if len(item_change) > 2:  # More than just item_name and master_item_id
                        items_changes.append(item_change)

            # Check for added items
            for item_id, new_item in new_items_dict.items():
                if item_id not in old_items_dict:
                    items_changes.append({
                        "type": "added",
                        "item_name": new_item.get("item_name"),
                        "master_item_id": item_id,
                        "selling_price": float(new_item.get("selling_price", 0))
                    })

            # Check for removed items
            for item_id, old_item in old_items_dict.items():
                if item_id not in new_items_dict:
                    items_changes.append({
                        "type": "removed",
                        "item_name": old_item.get("item_name"),
                        "master_item_id": item_id,
                        "selling_price": float(old_item.get("selling_price", 0))
                    })

            if items_changes:
                detailed_changes["items"] = items_changes

        # Create action for BOQ history with current user role and name
        update_action = {
            "type": "boq_revision",
            "role": user_role if user_role else 'system',
            "user_name": user_name,
            "user_id": user_id,
            "status": boq.status,
            "old_status": old_status,
            "revision_number": new_revision_number,
            "old_revision_number": old_revision_number,
            "version": next_version,
            "timestamp": datetime.utcnow().isoformat(),
            "updated_by": user_name,
            "updated_by_user_id": user_id,
            "boq_name": boq.boq_name,
            "old_boq_name": old_boq_name,
            "total_items": len(boq_items) if "items" in data else boq_details.total_items,
            "total_cost": total_boq_cost if "items" in data else boq_details.total_cost,
            "changes": detailed_changes,
            "change_summary": {
                "boq_name_changed": bool(detailed_changes.get("boq_name")),
                "cost_changed": bool(detailed_changes.get("total_cost")),
                "items_changed": bool(detailed_changes.get("items")),
                "items_count_changed": bool(detailed_changes.get("total_items")),
                "status_changed": old_status != boq.status,
                "revision_created": True
            }
        }

        # Check if history entry exists for this BOQ
        existing_history = BOQHistory.query.filter_by(boq_id=boq_id).order_by(BOQHistory.action_date.desc()).first()

        if existing_history:
            # Append to existing action array
            if existing_history.action is None:
                current_actions = []
            elif isinstance(existing_history.action, list):
                current_actions = existing_history.action
            elif isinstance(existing_history.action, dict):
                current_actions = [existing_history.action]
            else:
                current_actions = []

            current_actions.append(update_action)
            existing_history.action = current_actions

            # Mark JSONB field as modified for SQLAlchemy
            flag_modified(existing_history, "action")

            existing_history.action_by = user_name
            existing_history.boq_status = boq.status
            existing_history.comments = f"BOQ Revision {new_revision_number} - Version {next_version} by {user_name}"
            existing_history.action_date = datetime.utcnow()
            existing_history.last_modified_by = user_name
            existing_history.last_modified_at = datetime.utcnow()
        else:
            # Create new history entry
            boq_history = BOQHistory(
                boq_id=boq_id,
                action=[update_action],
                action_by=user_name,
                boq_status=boq.status,
                comments=f"BOQ Revision {new_revision_number} - Version {next_version} by {user_name}",
                action_date=datetime.utcnow(),
                created_by=user_name
            )
            db.session.add(boq_history)

        db.session.commit()

        # Return updated BOQ
        return jsonify({
            "message": "BOQ Revision created successfully",
            "boq_id": boq_id,
            "revision_number": new_revision_number,
            "version": next_version,
            "status": boq.status,
            "updated_by": user_name
        }), 200
        # return get_boq(boq_id)

    except Exception as e:
        db.session.rollback()
        log.error(f"Error updating BOQ: {str(e)}")
        return jsonify({"error": str(e)}), 500

def delete_boq(boq_id):
    """Delete BOQ and its details (soft delete could be implemented)"""
    try:
        boq = BOQ.query.filter_by(boq_id=boq_id).first()
        project = Project.query.filter_by(project_id=boq.project_id).first()
        if not boq:
            return jsonify({"error": "BOQ not found"}), 404

        # Delete BOQ details
        boq_details = BOQDetails.query.filter_by(boq_id=boq_id).first()
        if boq_details:
            boq_details.is_deleted = True
            db.session.commit()
            # db.session.delete(boq_details)

        # Delete BOQ (master tables remain untouched)
        # db.session.delete(boq)
        boq.is_deleted = True
        project.status = 'draft'
        db.session.commit()

        return jsonify({"message": "BOQ deleted successfully"}), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error deleting BOQ: {str(e)}")
        return jsonify({"error": str(e)}), 500

def get_sub_item_material(sub_item_id):
    """Get all materials for a given sub_item_id"""
    try:
        # Check if sub-item exists
        boq_sub_item = MasterSubItem.query.filter_by(
            sub_item_id=sub_item_id,
            is_deleted=False
        ).first()
        if not boq_sub_item:
            return jsonify([]), 200

        # Get parent item details
        boq_item = MasterItem.query.filter_by(
            item_id=boq_sub_item.item_id,
            is_deleted=False
        ).first()

        # Get all materials for this sub-item
        boq_materials = MasterMaterial.query.filter_by(
            sub_item_id=sub_item_id,
            is_active=True
        ).all()

        material_details = []
        total_material_cost = 0

        for material in boq_materials:
            material_cost = (material.current_market_price or 0)
            total_material_cost += material_cost

            material_details.append({
                "material_id": material.material_id,
                "material_name": material.material_name,
                "description" : material.description,
                "size" : material.size,
                "specification" : material.specification,
                "quantity" : material.quantity,
                "brand" : material.brand,
                "item_id": material.item_id,
                "sub_item_id": material.sub_item_id,
                "item_name": boq_item.item_name if boq_item else None,
                "sub_item_name": boq_sub_item.sub_item_name,
                "default_unit": material.default_unit,
                "current_market_price": material.current_market_price,
                "is_active": material.is_active,
                "created_at": material.created_at.isoformat() if material.created_at else None,
                "created_by": material.created_by
            })

        return jsonify({
            "sub_item_id": boq_sub_item.sub_item_id,
            "sub_item_name": boq_sub_item.sub_item_name,
            "item_id": boq_sub_item.item_id,
            "item_name": boq_item.item_name if boq_item else None,
            "location": boq_sub_item.location,
            "brand": boq_sub_item.brand,
            "materials_count": len(material_details),
            "total_material_cost": total_material_cost,
            "materials": material_details
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error fetching materials for sub_item {sub_item_id}: {str(e)}")
        import traceback
        log.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500

def get_sub_item_labours(sub_item_id):
    """Get all labour for a given sub_item_id"""
    try:
        # Check if sub-item exists
        boq_sub_item = MasterSubItem.query.filter_by(
            sub_item_id=sub_item_id,
            is_deleted=False
        ).first()

        if not boq_sub_item:
            return jsonify([]), 200

        # Get parent item details
        boq_item = MasterItem.query.filter_by(
            item_id=boq_sub_item.item_id,
            is_deleted=False
        ).first()

        # Get all labour for this sub-item
        boq_labours = MasterLabour.query.filter_by(
            sub_item_id=sub_item_id,
            is_active=True
        ).all()

        labour_details = []
        total_labour_cost = 0
        total_hours = 0

        for labour in boq_labours:
            labour_amount = labour.amount or 0
            labour_hours = labour.hours or 0
            total_labour_cost += labour_amount
            total_hours += labour_hours

            labour_details.append({
                "labour_id": labour.labour_id,
                "labour_role": labour.labour_role,
                "item_id": labour.item_id,
                "sub_item_id": labour.sub_item_id,
                "item_name": boq_item.item_name if boq_item else None,
                "sub_item_name": boq_sub_item.sub_item_name,
                "work_type": labour.work_type,
                "hours": labour.hours,
                "rate_per_hour": labour.rate_per_hour,
                "amount": labour.amount,
                "is_active": labour.is_active,
                "created_at": labour.created_at.isoformat() if labour.created_at else None,
                "created_by": labour.created_by
            })

        return jsonify({
            "sub_item_id": boq_sub_item.sub_item_id,
            "sub_item_name": boq_sub_item.sub_item_name,
            "item_id": boq_sub_item.item_id,
            "item_name": boq_item.item_name if boq_item else None,
            "location": boq_sub_item.location,
            "brand": boq_sub_item.brand,
            "labours_count": len(labour_details),
            "total_hours": total_hours,
            "total_labour_cost": total_labour_cost,
            "labours": labour_details
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error fetching labour for sub_item {sub_item_id}: {str(e)}")
        import traceback
        log.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500

def get_all_item():
    try:
        # ✅ PERFORMANCE: Limit to 500 items (use search for larger datasets)
        boq_items = MasterItem.query.filter_by(is_deleted=False).order_by(MasterItem.item_name.asc()).limit(500).all()
        item_details = []
        for item in boq_items:
            item_details.append({
                "item_id": item.item_id,
                "item_name": item.item_name,
                "description": item.description,
                "miscellaneous_percentage": item.miscellaneous_percentage,
                "miscellaneous_amount": item.miscellaneous_amount,
                "overhead_percentage": item.overhead_percentage,
                "overhead_amount": item.overhead_amount,
                "profit_margin_percentage": item.profit_margin_percentage,
                "profit_margin_amount": item.profit_margin_amount
            })

        return jsonify({
            "item_list": item_details
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error fetching item: {str(e)}")
        return jsonify({"error": str(e)}), 500


def get_all_sub_item_names():
    """Get all unique sub-item names from the database for autocomplete suggestions"""
    try:
        # Query distinct sub_item_names from boq_sub_items table
        # Only include non-deleted sub-items
        sub_item_names = db.session.query(
            MasterSubItem.sub_item_name
        ).filter(
            MasterSubItem.is_deleted == False,
            MasterSubItem.sub_item_name.isnot(None),
            MasterSubItem.sub_item_name != ''
        ).distinct().order_by(
            MasterSubItem.sub_item_name.asc()
        ).limit(500).all()

        # Extract names from tuples and return as list
        names_list = [name[0].strip() for name in sub_item_names if name[0] and name[0].strip()]

        return jsonify({
            "success": True,
            "sub_item_names": names_list,
            "count": len(names_list)
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error fetching sub-item names: {str(e)}")
        return jsonify({"error": str(e)}), 500


def get_sub_item_by_name(sub_item_name):
    """Get sub-item details including materials and labour by sub-item name"""
    try:
        if not sub_item_name:
            return jsonify({"error": "Sub-item name is required"}), 400

        # Find the sub-item by name (case-insensitive, get most recent one)
        sub_item = MasterSubItem.query.filter(
            db.func.lower(MasterSubItem.sub_item_name) == sub_item_name.lower().strip(),
            MasterSubItem.is_deleted == False
        ).order_by(MasterSubItem.created_at.desc()).first()

        if not sub_item:
            return jsonify({
                "success": False,
                "message": "Sub-item not found",
                "sub_item": None
            }), 404

        # Get materials for this sub-item
        materials = MasterMaterial.query.filter_by(
            sub_item_id=sub_item.sub_item_id,
            is_active=True
        ).all()

        material_list = []
        for material in materials:
            material_list.append({
                "material_id": material.material_id,
                "material_name": material.material_name,
                "description": material.description,
                "size": material.size,
                "specification": material.specification,
                "quantity": material.quantity or 1,
                "brand": material.brand,
                "unit": material.default_unit,
                "unit_price": material.current_market_price,
                "current_market_price": material.current_market_price,
                "is_active": material.is_active
            })

        # Get labour for this sub-item
        labours = MasterLabour.query.filter_by(
            sub_item_id=sub_item.sub_item_id,
            is_active=True
        ).all()

        labour_list = []
        for labour in labours:
            labour_list.append({
                "labour_id": labour.labour_id,
                "labour_role": labour.labour_role,
                "work_type": labour.work_type or "daily_wages",
                "hours": labour.hours or 8,
                "rate_per_hour": labour.rate_per_hour or (labour.amount / 8 if labour.amount else 0),
                "amount": labour.amount,
                "is_active": labour.is_active
            })

        # Return sub-item with materials and labour
        return jsonify({
            "success": True,
            "sub_item": {
                "sub_item_id": sub_item.sub_item_id,
                "item_id": sub_item.item_id,
                "sub_item_name": sub_item.sub_item_name,
                "scope": sub_item.description,
                "description": sub_item.description,
                "size": sub_item.size,
                "location": sub_item.location,
                "brand": sub_item.brand,
                "unit": sub_item.unit or "nos",
                "quantity": sub_item.quantity or 1,
                "per_unit_cost": sub_item.per_unit_cost or 0,
                "rate": sub_item.per_unit_cost or 0,
                "misc_percentage": sub_item.misc_percentage or 10.0,
                "overhead_profit_percentage": sub_item.overhead_profit_percentage or 25.0,
                "transport_percentage": sub_item.transport_percentage or 5.0,
                "materials": material_list,
                "labour": labour_list
            }
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error fetching sub-item by name: {str(e)}")
        import traceback
        log.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500


# SEND EMAIL - Send BOQ to Technical Director
def send_boq_email(boq_id):
    try:
        current_user = getattr(g, 'user', None)
        user_id = current_user.get('user_id') if current_user else None
        user_role = current_user.get('role', '').lower() if current_user else ''
        user_name = current_user.get('full_name') or current_user.get('username') or 'Unknown' if current_user else 'Unknown'
        # Get BOQ data
        boq = BOQ.query.filter_by(boq_id=boq_id).first()
        if not boq:
            return jsonify({
                "error": "BOQ not found",
                "message": f"No BOQ found with ID {boq_id}"
            }), 404

        # Get BOQ details
        boq_details = BOQDetails.query.filter_by(boq_id=boq_id).first()
        if not boq_details:
            return jsonify({
                "error": "BOQ details not found",
                "message": f"No BOQ details found for BOQ ID {boq_id}"
            }), 404

        # Get project data
        project = Project.query.filter_by(project_id=boq.project_id).first()
        if not project:
            return jsonify({
                "error": "Project not found",
                "message": f"No project found with ID {boq.project_id}"
            }), 404

        # Prepare BOQ data
        boq_data = {
            'boq_id': boq.boq_id,
            'boq_name': boq.boq_name,
            'status': boq.status,
            'created_by': boq.created_by,
            'created_at': boq.created_at.strftime('%d-%b-%Y %I:%M %p') if boq.created_at else 'N/A'
        }

        # Prepare project data
        project_data = {
            'project_name': project.project_name,
            'client': project.client if hasattr(project, 'client') else 'N/A',
            'location': project.location if hasattr(project, 'location') else 'N/A'
        }

        # Prepare items summary from BOQ details JSON
        items_summary = boq_details.boq_details.get('summary', {})
        items_summary['items'] = boq_details.boq_details.get('items', [])

        # Initialize email service
        # boq_email_service = BOQEmailService()

        # Get TD email from request or fetch all Technical Directors
        # Handle GET request with optional JSON body (non-standard but supported)
        try:
            data = request.get_json(silent=True) or {}
        except Exception as e:
            log.warning(f"Failed to parse JSON body: {e}")
            data = {}

        td_email = data.get('td_email')
        td_name = data.get('full_name')
        comments = data.get('comments')  # Get comments from request

        if td_email:
            # Send to specific TD
            # email_sent = boq_email_service.send_boq_to_technical_director(
            #     boq_data, project_data, items_summary, td_email
            # )

            # if email_sent:
                # Update BOQ status and mark email as sent to TD
            # This API is ONLY for Internal Revisions - status is always Pending_Revision
            is_internal_revision = boq.status == "Internal_Revision_Pending" or boq.has_internal_revisions

            # Internal Revisions sent to TD get status "Pending_Revision"
            # New BOQ (without internal revisions) get status "Pending"
            new_status = "Pending_Revision" if is_internal_revision else "Pending"
            boq.email_sent = True
            boq.status = new_status
            boq.last_modified_by = user_name
            boq.last_modified_at = datetime.utcnow()

            # Check if history entry already exists for this BOQ
            existing_history = BOQHistory.query.filter_by(boq_id=boq_id).order_by(BOQHistory.action_date.desc()).first()

            # Prepare action data in the new format
            action_type = "internal_revision_sent" if is_internal_revision else "email_sent"
            default_comment = "Internal revision sent to TD for review" if is_internal_revision else "BOQ sent for review and approval"

            new_action = {
                "role": user_role,
                "type": action_type,
                "sender": user_role,
                "receiver": "technicalDirector",
                "status": new_status.lower(),
                "comments": comments if comments else default_comment,
                "timestamp": datetime.utcnow().isoformat(),
                "decided_by": user_name,
                "decided_by_user_id": user_id,
                "recipient_email": td_email,
                "recipient_name": td_name if td_name else None,
                "boq_name": boq.boq_name,
                "project_name": project_data.get("project_name"),
                "total_cost": items_summary.get("total_cost"),
                "is_internal_revision": is_internal_revision
            }

            if existing_history:
                # Append to existing action array (avoid duplicates)
                # Handle existing actions - ensure it's always a list
                if existing_history.action is None:
                    current_actions = []
                elif isinstance(existing_history.action, list):
                    current_actions = existing_history.action
                elif isinstance(existing_history.action, dict):
                    current_actions = [existing_history.action]
                else:
                    current_actions = []

                # Check if similar action already exists (same type, sender, receiver, timestamp within 1 minute)
                action_exists = False
                for existing_action in current_actions:
                    if (existing_action.get('type') == new_action['type'] and
                        existing_action.get('sender') == new_action['sender'] and
                        existing_action.get('receiver') == new_action['receiver']):
                        # Check if timestamps are within 1 minute (to avoid duplicate on retry)
                        existing_ts = existing_action.get('timestamp', '')
                        new_ts = new_action['timestamp']
                        if existing_ts and new_ts:
                            try:
                                existing_dt = datetime.fromisoformat(existing_ts)
                                new_dt = datetime.fromisoformat(new_ts)
                                if abs((new_dt - existing_dt).total_seconds()) < 60:
                                    action_exists = True
                                    break
                            except:
                                pass

                if not action_exists:
                    current_actions.append(new_action)
                    existing_history.action = current_actions
                    # Mark JSONB field as modified for SQLAlchemy
                    flag_modified(existing_history, "action")

                existing_history.action_by = user_name
                existing_history.boq_status = "Pending"
                existing_history.sender = user_name
                existing_history.receiver = td_name if td_name else td_email
                existing_history.comments = comments if comments else "BOQ sent for review and approval"
                existing_history.sender_role = user_role
                existing_history.receiver_role = 'technicalDirector'
                existing_history.action_date = datetime.utcnow()
                existing_history.last_modified_by = user_name
                existing_history.last_modified_at = datetime.utcnow()
            else:
                # Create new history entry with action as array
                boq_history = BOQHistory(
                    boq_id=boq_id,
                    action=[new_action],  # Store as array
                    action_by=user_name,
                    boq_status="Pending",
                    sender=user_name,
                    receiver=td_name if td_name else td_email,
                    comments=comments if comments else "BOQ sent for review and approval",
                    sender_role=user_role,
                    receiver_role='technicalDirector',
                    action_date=datetime.utcnow(),
                    created_by=user_name
                )
                db.session.add(boq_history)

            db.session.commit()

            # Send notification to TD
            try:
                from utils.comprehensive_notification_service import notification_service
                from models.user import User as UserModel
                # Find TD user by email
                td_user = UserModel.query.filter_by(email=td_email).first()
                if td_user:
                    log.info(f"[send_boq_email] Sending notification to TD {td_user.user_id}")
                    notification_service.notify_boq_sent_to_td(
                        boq_id=boq_id,
                        project_name=project.project_name,
                        estimator_id=user_id,
                        estimator_name=user_name,
                        td_user_id=td_user.user_id
                    )
                    log.info(f"[send_boq_email] Notification sent successfully")
            except Exception as notif_err:
                log.error(f"[send_boq_email] Failed to send notification: {notif_err}")

            return jsonify({
                "success": True,
                "message": "BOQ review email sent successfully to Technical Director",
                "boq_id": boq_id,
                "recipient": td_email
            }), 200
            # else:
            #     return jsonify({
            #         "success": False,
            #         "message": "Failed to send BOQ review email",
            #         "boq_id": boq_id,
            #         "error": "Email service failed"
            #     }), 500
        else:
            # Send to ALL Technical Directors (support multiple TDs)
            td_role = Role.query.filter_by(role='technicalDirector').first()

            if not td_role:
                return jsonify({
                    "error": "Technical Director role not found",
                    "message": "Technical Director role not configured in the system"
                }), 404

            # Get ALL active TDs instead of just first()
            technical_directors = User.query.filter_by(
                role_id=td_role.role_id,
                is_active=True,
                is_deleted=False
            ).all()

            if not technical_directors:
                return jsonify({
                    "error": "No Technical Director found",
                    "message": "No active Technical Director found in the system"
                }), 404

            # Use first TD for compatibility with single-TD logic below
            technical_director = technical_directors[0]

            if not technical_director.email:
                return jsonify({
                    "error": "Technical Director has no email",
                    "message": f"Technical Director {technical_director.full_name} does not have an email address"
                }), 400

            # Send email to the Technical Director
            # email_sent = boq_email_service.send_boq_to_technical_director(
            #     boq_data, project_data, items_summary, technical_director.email
            # )

            # if email_sent:
                # Update BOQ status and mark email as sent to TD
            # This API is ONLY for Internal Revisions - status is always Pending_Revision
            is_internal_revision = boq.status == "Internal_Revision_Pending" or boq.has_internal_revisions

            # Internal Revisions sent to TD get status "Pending_Revision"
            # New BOQ (without internal revisions) get status "Pending"
            new_status = "Pending_Revision" if is_internal_revision else "Pending"

            boq.email_sent = True
            boq.status = new_status
            boq.last_modified_by = boq.created_by
            boq.last_modified_at = datetime.utcnow()

            # Check if history entry already exists for this BOQ
            existing_history = BOQHistory.query.filter_by(boq_id=boq_id).order_by(BOQHistory.action_date.desc()).first()

            # Prepare action data in the new format
            action_type = "internal_revision_sent" if is_internal_revision else "email_sent"
            default_comment = "Internal revision sent to TD for review" if is_internal_revision else "BOQ sent for review and approval"

            new_action = {
                "role": user_role,
                "type": action_type,
                "sender": user_name,
                "receiver": "technicalDirector",
                "status": new_status.lower(),
                "comments": comments if comments else default_comment,
                "timestamp": datetime.utcnow().isoformat(),
                "decided_by": user_name,
                "decided_by_user_id": user_id,
                "recipient_email": technical_director.email if technical_director.email else None,
                "recipient_name": technical_director.full_name if technical_director.full_name else None,
                "boq_name": boq.boq_name,
                "project_name": project_data.get("project_name"),
                "total_cost": items_summary.get("total_cost"),
                "is_internal_revision": is_internal_revision
            }

            if existing_history:
                # Append to existing action array (avoid duplicates)
                # Handle existing actions - ensure it's always a list
                if existing_history.action is None:
                    current_actions = []
                elif isinstance(existing_history.action, list):
                    current_actions = existing_history.action
                elif isinstance(existing_history.action, dict):
                    current_actions = [existing_history.action]
                else:
                    current_actions = []

                # Check if similar action already exists (same type, sender, receiver, timestamp within 1 minute)
                action_exists = False
                for existing_action in current_actions:
                    if (existing_action.get('type') == new_action['type'] and
                        existing_action.get('sender') == new_action['sender'] and
                        existing_action.get('receiver') == new_action['receiver']):
                        # Check if timestamps are within 1 minute (to avoid duplicate on retry)
                        existing_ts = existing_action.get('timestamp', '')
                        new_ts = new_action['timestamp']
                        if existing_ts and new_ts:
                            try:
                                existing_dt = datetime.fromisoformat(existing_ts)
                                new_dt = datetime.fromisoformat(new_ts)
                                if abs((new_dt - existing_dt).total_seconds()) < 60:
                                    action_exists = True
                                    break
                            except:
                                pass

                if not action_exists:
                    current_actions.append(new_action)
                    existing_history.action = current_actions
                    # Mark JSONB field as modified for SQLAlchemy
                    flag_modified(existing_history, "action")

                existing_history.action_by = user_name
                existing_history.boq_status = "Pending"
                existing_history.sender = user_name
                existing_history.receiver = technical_director.full_name if technical_director.full_name else technical_director.email
                existing_history.comments = comments if comments else "BOQ sent for review and approval"
                existing_history.sender_role = user_role
                existing_history.receiver_role = 'technicalDirector'
                existing_history.action_date = datetime.utcnow()
                existing_history.last_modified_by = user_name
                existing_history.last_modified_at = datetime.utcnow()
            else:
                # Create new history entry with action as array
                boq_history = BOQHistory(
                    boq_id=boq_id,
                    action=[new_action],  # Store as array
                    action_by=user_name,
                    boq_status="Pending",
                    sender=user_name,
                    receiver=technical_director.full_name if technical_director.full_name else technical_director.email,
                    comments=comments if comments else "BOQ sent for review and approval",
                    sender_role=user_role,
                    receiver_role='technicalDirector',
                    action_date=datetime.utcnow(),
                    created_by=user_name
                )
                db.session.add(boq_history)

            db.session.commit()

            # Send notification to ALL TDs
            try:
                from utils.comprehensive_notification_service import notification_service
                log.info(f"[send_boq_email] Sending notification to {len(technical_directors)} Technical Director(s)")
                for td in technical_directors:
                    try:
                        notification_service.notify_boq_sent_to_td(
                            boq_id=boq_id,
                            project_name=project.project_name,
                            estimator_id=user_id,
                            estimator_name=user_name,
                            td_user_id=td.user_id
                        )
                        log.info(f"[send_boq_email] Notification sent successfully to TD {td.user_id} ({td.full_name})")
                    except Exception as td_notif_err:
                        log.error(f"[send_boq_email] Failed to send notification to TD {td.user_id}: {td_notif_err}")
            except Exception as notif_err:
                log.error(f"[send_boq_email] Failed to send notifications to TDs: {notif_err}")

            return jsonify({
                "success": True,
                "message": "BOQ review email sent successfully to Technical Director",
                "boq_id": boq_id,
                "email": technical_director.email,
            }), 200
            # else:
            #     return jsonify({
            #         "success": False,
            #         "message": "Failed to send BOQ review email to Technical Director",
            #         "boq_id": boq_id,
            #         "error": "Email service failed"
            #     }), 500

    except Exception as e:
        log.error(f"Error sending BOQ email for BOQ {boq_id}: {str(e)}")
        return jsonify({
            "success": False,
            "message": "Failed to send BOQ email notification",
            "error": str(e)
        }), 500

def get_boq_history(boq_id):
    try:
        boq_history_records = BOQHistory.query.filter_by(boq_id=boq_id).order_by(BOQHistory.action_date.desc()).all()

        history_list = []
        for h in boq_history_records:
            history_list.append({
                "boq_history_id": h.boq_history_id,
                "boq_id": h.boq_id,
                "action": h.action,
                "action_by": h.action_by,
                "boq_status": h.boq_status,
                "sender": h.sender,
                "receiver": h.receiver,
                "comments": h.comments,
                "sender_role": h.sender_role,
                "receiver_role": h.receiver_role,
                "action_date": h.action_date.isoformat() if h.action_date else None,
                "created_at": h.created_at.isoformat() if h.created_at else None,
                "created_by": h.created_by
            })

        return jsonify({
            "boq_history": history_list
        }), 200
    except Exception as e:
        db.session.rollback()
        log.error(f"Error fetching BOQ history: {str(e)}")
        return jsonify({"error": str(e)}), 500

def get_estimator_dashboard():
    try:
        from datetime import datetime, timedelta
        from collections import defaultdict
        from sqlalchemy import func, case, and_
        from sqlalchemy.orm import selectinload, load_only

        # Get current user context
        current_user = getattr(g, 'user', None)
        user_id = current_user.get('user_id') if current_user else None
        user_role = current_user.get('role', '').lower() if current_user else ''

        # Get effective user context (handles admin viewing as other roles)
        context = get_effective_user_context()
        now = datetime.utcnow()

        # Build base query filter for BOQs
        is_admin = user_role == 'admin' or not should_apply_role_filter(context)

        # OPTIMIZATION 1: Use SQL aggregation for status counts instead of loading all BOQs
        if is_admin:
            status_query = db.session.query(
                BOQ.status,
                func.count(BOQ.boq_id).label('count')
            ).filter(BOQ.is_deleted == False).group_by(BOQ.status)
        else:
            # Get project IDs for this estimator first
            project_ids_subquery = db.session.query(Project.project_id).filter(
                Project.is_deleted == False,
                or_(Project.estimator_id == user_id, Project.estimator_id == None)
            ).subquery()

            status_query = db.session.query(
                BOQ.status,
                func.count(BOQ.boq_id).label('count')
            ).filter(
                BOQ.is_deleted == False,
                BOQ.project_id.in_(project_ids_subquery)
            ).group_by(BOQ.status)

        # Execute status count query - single DB round trip
        status_counts = {row.status: row.count for row in status_query.all()}

        # Count Draft BOQs
        draft_boqs = status_counts.get('Draft', 0) + status_counts.get('draft', 0)

        # Count Pending BOQs (includes various pending states)
        pending_boqs = (
            status_counts.get('Pending', 0) +
            status_counts.get('pending', 0) +
            status_counts.get('Pending_Revision', 0) +
            status_counts.get('Client_Pending_Revision', 0) +
            status_counts.get('Internal_Revision_Pending', 0) +
            status_counts.get('Under_Revision', 0)
        )

        # Count In Review BOQs
        in_review_boqs = status_counts.get('In_Review', 0) + status_counts.get('in_review', 0)

        # Count Approved BOQs (includes various approved states)
        approved_boqs_count = (
            status_counts.get('Approved', 0) +
            status_counts.get('approved', 0) +
            status_counts.get('Client_Confirmed', 0) +
            status_counts.get('client_confirmed', 0) +
            status_counts.get('Revision_Approved', 0) +
            status_counts.get('ITEMS ASSIGNED', 0) +
            status_counts.get('Items_Assigned', 0) +
            status_counts.get('items_assigned', 0) +  # lowercase version used in PM controller
            status_counts.get('CLIENT CONFIRMED', 0) +
            status_counts.get('PM_Approved', 0) +
            status_counts.get('pm_approved', 0)
        )

        # Count Rejected BOQs (includes various rejected states)
        rejected_boqs = (
            status_counts.get('Rejected', 0) +
            status_counts.get('rejected', 0) +
            status_counts.get('Client_Rejected', 0) +
            status_counts.get('client_revision_rejected', 0)
        )

        # Count Sent for Confirmation BOQs
        sent_for_confirmation_boqs = (
            status_counts.get('Sent_for_Confirmation', 0) +
            status_counts.get('sent_for_confirmation', 0) +
            status_counts.get('Sent_To_Client', 0)
        )

        total_boqs = sum(status_counts.values())

        # Debug: Log all status counts for troubleshooting
        log.info(f"[EstimatorDashboard] Status counts: {status_counts}")
        log.info(f"[EstimatorDashboard] Calculated: pending={pending_boqs}, approved={approved_boqs_count}, rejected={rejected_boqs}, sent={sent_for_confirmation_boqs}, draft={draft_boqs}")

        # OPTIMIZATION 2: Calculate average approval time using SQL
        if is_admin:
            avg_time_query = db.session.query(
                func.avg(func.extract('epoch', BOQ.last_modified_at - BOQ.created_at) / 86400)
            ).filter(
                BOQ.is_deleted == False,
                BOQ.status == 'Approved',
                BOQ.last_modified_at != None,
                BOQ.created_at != None
            ).scalar()
        else:
            avg_time_query = db.session.query(
                func.avg(func.extract('epoch', BOQ.last_modified_at - BOQ.created_at) / 86400)
            ).filter(
                BOQ.is_deleted == False,
                BOQ.status == 'Approved',
                BOQ.last_modified_at != None,
                BOQ.created_at != None,
                BOQ.project_id.in_(project_ids_subquery)
            ).scalar()

        average_approval_time = round(float(avg_time_query), 1) if avg_time_query else 0

        # OPTIMIZATION 3: Load only necessary project data with minimal BOQ details
        if is_admin:
            projects = Project.query.options(
                selectinload(Project.boqs).options(
                    load_only(BOQ.boq_id, BOQ.status, BOQ.created_at, BOQ.is_deleted),
                    selectinload(BOQ.details).load_only(
                        BOQDetails.total_cost, BOQDetails.total_items, BOQDetails.boq_details
                    )
                )
            ).filter_by(is_deleted=False).all()
        else:
            projects = Project.query.options(
                selectinload(Project.boqs).options(
                    load_only(BOQ.boq_id, BOQ.status, BOQ.created_at, BOQ.is_deleted),
                    selectinload(BOQ.details).load_only(
                        BOQDetails.total_cost, BOQDetails.total_items, BOQDetails.boq_details
                    )
                )
            ).filter(
                Project.is_deleted == False,
                or_(Project.estimator_id == user_id, Project.estimator_id == None)
            ).all()

        # Initialize aggregation variables
        total_selling_amount = 0
        total_profit_amount = 0
        total_material_cost = 0
        total_labor_cost = 0
        total_item_count = 0
        total_material_count = 0
        total_labor_count = 0
        monthly_data = defaultdict(lambda: {"count": 0, "value": 0})
        top_projects = []

        # Process projects
        for project in projects:
            project_boqs = [boq for boq in (project.boqs or []) if not boq.is_deleted]
            if not project_boqs:
                continue

            project_total_value = 0
            project_total_material = 0
            project_total_labor = 0
            project_total_items = 0
            project_material_count = 0
            project_labor_count = 0

            for boq in project_boqs:
                boq_details = boq.details[0] if boq.details else None
                if not boq_details:
                    continue

                selling_price = float(boq_details.total_cost or 0)
                project_total_value += selling_price
                total_selling_amount += selling_price

                items_count = int(boq_details.total_items or 0)
                project_total_items += items_count
                total_item_count += items_count

                # Get summary data - avoid iterating items if possible
                boq_json = boq_details.boq_details
                if boq_json and isinstance(boq_json, dict):
                    summary = boq_json.get('summary', {})

                    material_cost = float(summary.get('total_material_cost', 0))
                    labor_cost = float(summary.get('total_labor_cost', 0))

                    project_total_material += material_cost
                    total_material_cost += material_cost
                    project_total_labor += labor_cost
                    total_labor_cost += labor_cost

                    # OPTIMIZATION 4: Use pre-calculated summary counts if available
                    # Otherwise calculate from items (fallback)
                    if 'material_item_count' in summary and 'labor_item_count' in summary:
                        project_material_count += int(summary.get('material_item_count', 0))
                        project_labor_count += int(summary.get('labor_item_count', 0))
                        total_profit_amount += float(summary.get('total_profit', 0))
                    else:
                        # Fallback: iterate items only if summary doesn't have counts
                        items = boq_json.get('items', [])
                        for item in items:
                            if item.get('material_cost', 0) > 0:
                                project_material_count += 1
                            if item.get('labor_cost', 0) > 0:
                                project_labor_count += 1
                            total_profit_amount += float(item.get('selling_price', 0)) - float(item.get('base_cost', 0))

                    total_material_count += project_material_count
                    total_labor_count += project_labor_count

                # Monthly trend data
                if boq.created_at:
                    month_key = boq.created_at.strftime('%B %Y')
                    monthly_data[month_key]["count"] += 1
                    monthly_data[month_key]["value"] += selling_price

            top_projects.append({
                "project_id": project.project_id,
                "project_name": project.project_name,
                "boq_count": len(project_boqs),
                "total_value": round(project_total_value, 2),
                "total_items": project_total_items,
                "material_count": project_material_count,
                "labor_count": project_labor_count,
                "material_cost": round(project_total_material, 2),
                "labor_cost": round(project_total_labor, 2)
            })

        # Sort and limit top projects
        top_projects.sort(key=lambda x: x['total_value'], reverse=True)
        top_5_projects = top_projects[:5]

        # Recent activities = top 5 most recent (reuse top_projects, sort by project_id desc as proxy)
        recent_activities = [
            {"project_id": p["project_id"], "project_name": p["project_name"],
             "boq_count": p["boq_count"], "value": p["total_value"]}
            for p in sorted(top_projects, key=lambda x: x['project_id'], reverse=True)[:5]
        ]

        # Monthly trend (last 6 months)
        monthly_trend = []
        for i in range(5, -1, -1):
            month_date = now - timedelta(days=30*i)
            month_key = month_date.strftime('%B %Y')
            monthly_trend.append({
                "month": month_key,
                "count": monthly_data[month_key]["count"],
                "value": round(monthly_data[month_key]["value"], 2)
            })

        total_pending_boqs = draft_boqs + pending_boqs + in_review_boqs

        return jsonify({
            # Summary metrics
            "total_projects": len(projects),
            "total_boqs": total_boqs,
            "total_selling_amount": round(total_selling_amount, 2),
            "total_profit_amount": round(total_profit_amount, 2),
            "total_material_cost": round(total_material_cost, 2),
            "total_labor_cost": round(total_labor_cost, 2),
            "total_items": total_item_count,
            "total_material_count": total_material_count,
            "total_labor_count": total_labor_count,

            # Status breakdown
            "pending_boqs": total_pending_boqs,
            "approved_boqs": approved_boqs_count,
            "rejected_boqs": rejected_boqs,
            "draft_boqs": draft_boqs,
            "sent_for_confirmation_boqs": sent_for_confirmation_boqs,
            "in_review_boqs": in_review_boqs,

            # Additional metrics
            "average_approval_time": average_approval_time,

            # Detailed data
            "monthly_trend": monthly_trend,
            "top_projects": top_5_projects,
            "recent_activities": recent_activities
        }), 200
    except Exception as e:
        db.session.rollback()
        log.error(f"Error fetching Estimator dashboard: {str(e)}")
        return jsonify({"error": str(e)}), 500


def get_estimator_tab_counts():
    """
    Lightweight API to get only tab counts for estimator hub.
    Uses SQL COUNT queries instead of fetching all data.
    Matches exactly with the filtering logic in get_pending_boq and frontend.
    """
    try:
        from sqlalchemy import func, case

        # Get current user context
        current_user = getattr(g, 'user', None)
        user_id = current_user.get('user_id') if current_user else None
        user_role = current_user.get('role', '').lower() if current_user else ''

        # Get effective user context
        context = get_effective_user_context()
        is_admin = user_role == 'admin' or not should_apply_role_filter(context)

        # Build base filter for BOQs
        if is_admin:
            base_filter = BOQ.is_deleted == False
            project_filter = Project.is_deleted == False
        else:
            # Get project IDs for this estimator
            project_filter = and_(
                Project.is_deleted == False,
                or_(Project.estimator_id == user_id, Project.estimator_id == None)
            )
            project_ids_subquery = db.session.query(Project.project_id).filter(project_filter).subquery()
            base_filter = and_(
                BOQ.is_deleted == False,
                BOQ.project_id.in_(project_ids_subquery)
            )

        # Single query to get all status counts
        status_counts = db.session.query(
            BOQ.status,
            func.count(BOQ.boq_id).label('count')
        ).filter(base_filter).group_by(BOQ.status).all()

        # Normalize status keys to lowercase to avoid double counting
        counts_dict = {}
        for row in status_counts:
            if row.status:
                key = row.status.lower()
                counts_dict[key] = counts_dict.get(key, 0) + row.count

        # ============ PENDING TAB COUNT ============
        # Use same logic as get_pending_boq: Projects with Draft BOQ OR Projects without any BOQ
        # This uses LEFT JOIN approach matching get_pending_boq exactly
        # Use DISTINCT to avoid counting duplicates when project has multiple Draft BOQs
        pending_query = (
            db.session.query(func.count(func.distinct(Project.project_id)))
            .select_from(Project)
            .outerjoin(BOQ, and_(BOQ.project_id == Project.project_id, BOQ.is_deleted == False))
            .filter(Project.is_deleted == False)
            .filter(
                or_(
                    BOQ.status.in_(['Draft', 'draft']),
                    BOQ.boq_id == None
                )
            )
        )
        if not is_admin:
            pending_query = pending_query.filter(or_(Project.estimator_id == user_id, Project.estimator_id == None))

        pending_count = pending_query.scalar() or 0

        # Send BOQ tab: Pending, Pending_PM_Approval, Pending_TD_Approval (BOQs sent for review, waiting for approval)
        # All keys are now lowercase after normalization
        sent_count = (
            counts_dict.get('pending', 0) +
            counts_dict.get('pending_pm_approval', 0) +
            counts_dict.get('pending_td_approval', 0)
        )

        # Approved tab: PM approved, TD approved, and subsequent statuses (excluding pending_td_approval which is in Send BOQ tab)
        approved_count = (
            counts_dict.get('pm_approved', 0) +
            counts_dict.get('approved', 0) +
            counts_dict.get('revision_approved', 0) +
            counts_dict.get('sent_for_confirmation', 0) +
            counts_dict.get('client_confirmed', 0) +
            counts_dict.get('items_assigned', 0)
        )

        # Rejected tab: TD rejected, PM rejected, client rejected, internal revision pending
        # Note: 'rejected' status = TD rejected in the workflow
        # Must match frontend filtering logic in EstimatorHub.tsx line 1252
        rejected_count = (
            counts_dict.get('rejected', 0) +
            counts_dict.get('td_rejected', 0) +
            counts_dict.get('client_rejected', 0) +
            counts_dict.get('pm_rejected', 0) +
            counts_dict.get('internal_revision_pending', 0)
        )

        completed_count = counts_dict.get('completed', 0)
        cancelled_count = (
            counts_dict.get('cancelled', 0) +
            counts_dict.get('client_cancelled', 0)
        )

        # Revisions count: BOQs with revision_number > 0
        revisions_count = db.session.query(func.count(BOQ.boq_id)).filter(
            base_filter,
            BOQ.revision_number > 0
        ).scalar() or 0

        return jsonify({
            "success": True,
            "counts": {
                "pending": pending_count,
                "sent": sent_count,
                "approved": approved_count,
                "rejected": rejected_count,
                "completed": completed_count,
                "cancelled": cancelled_count,
                "revisions": revisions_count
            }
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error fetching tab counts: {str(e)}")
        return jsonify({"error": str(e)}), 500


def get_sub_item(item_id):
    """Get all sub-items for a given item_id with their materials and labour"""
    try:
        # Check if the item exists
        boq_item = MasterItem.query.filter_by(item_id=item_id, is_deleted=False).first()
        if not boq_item:
            return jsonify({"error": "BOQ Item not found"}), 404

        # Get all sub-items for this item
        boq_sub_items = MasterSubItem.query.filter_by(
            item_id=item_id,
            is_deleted=False
        ).all()

        sub_item_details = []
        for sub_item in boq_sub_items:
            # Get materials for this sub-item
            materials = MasterMaterial.query.filter_by(
                sub_item_id=sub_item.sub_item_id,
                is_active=True
            ).all()

            material_list = []
            for material in materials:
                material_list.append({
                    "material_id": material.material_id,
                    "material_name": material.material_name,
                    "description" : material.description,
                    "size" : material.size,
                    "specification" : material.specification,
                    "quantity" : material.quantity,
                    "location": None,  # Location is stored in sub_item, not material
                    "brand": material.brand,  # Brand is stored in sub_item, not material
                    "unit": material.default_unit,
                    "current_market_price": material.current_market_price,
                    "is_active": material.is_active
                })

            # Get labour for this sub-item
            labours = MasterLabour.query.filter_by(
                sub_item_id=sub_item.sub_item_id,
                is_active=True
            ).all()

            labour_list = []
            for labour in labours:
                labour_list.append({
                    "labour_id": labour.labour_id,
                    "labour_role": labour.labour_role,
                    "work_type": labour.work_type,
                    "hours": labour.hours,
                    "rate_per_hour": labour.rate_per_hour,
                    "amount": labour.amount,
                    "is_active": labour.is_active
                })

            # Calculate total costs
            total_materials_cost = sum(
                (mat.current_market_price or 0) for mat in materials
            )
            total_labour_cost = sum(
                (lab.amount or 0) for lab in labours
            )

            sub_item_details.append({
                "sub_item_id": sub_item.sub_item_id,
                "item_id": sub_item.item_id,
                "sub_item_name": sub_item.sub_item_name,
                "scope" : sub_item.description,
                "size" : sub_item.size,
                "description": sub_item.description,
                "location": sub_item.location,
                "brand": sub_item.brand,
                "sub_item_image": sub_item.sub_item_image,
                "unit": sub_item.unit,
                "quantity": sub_item.quantity,
                "per_unit_cost": sub_item.per_unit_cost,
                "sub_item_total_cost": sub_item.sub_item_total_cost,
                "materials": material_list,
                "labour": labour_list,
                "total_materials_cost": total_materials_cost,
                "total_labour_cost": total_labour_cost,
                "total_cost": total_materials_cost + total_labour_cost,
                "created_at": sub_item.created_at.isoformat() if sub_item.created_at else None,
                "created_by": sub_item.created_by
            })

        # Collect all unique materials from sub-items for the dropdown
        all_materials_dict = {}
        for sub_item_detail in sub_item_details:
            for material in sub_item_detail.get('materials', []):
                mat_id = material['material_id']
                if mat_id not in all_materials_dict:
                    all_materials_dict[mat_id] = {
                        "material_id": mat_id,
                        "item_id": boq_item.item_id,
                        "item_name": boq_item.item_name,
                        "material_name": material['material_name'],
                        "description" : material['description'],
                        "size" : material['size'],
                        "brand" : material['brand'],
                        "specification" : material['specification'],
                        "quantity" : material['quantity'],
                        "current_market_price": material['current_market_price'],
                        "default_unit": material['unit']
                    }

        # Also fetch materials from purchased change requests for this item
        # Query material_purchase_tracking for materials added via change requests
        from models.boq import MaterialPurchaseTracking
        cr_materials = MaterialPurchaseTracking.query.filter(
            MaterialPurchaseTracking.master_item_id == item_id,
            MaterialPurchaseTracking.is_from_change_request == True
        ).all()

        for cr_mat in cr_materials:
            mat_id = cr_mat.master_material_id
            if mat_id and mat_id not in all_materials_dict:
                # Fetch the full material details from boq_material
                master_material = MasterMaterial.query.filter_by(
                    material_id=mat_id,
                    is_active=True
                ).first()

                if master_material:
                    all_materials_dict[mat_id] = {
                        "material_id": mat_id,
                        "item_id": boq_item.item_id,
                        "item_name": boq_item.item_name,
                        "material_name": master_material.material_name,
                        "description" : master_material.description,
                        "size" : master_material.size,
                        "specification" : master_material.specification,
                        "quantity" : master_material.quantity,
                        "brand" : master_material.brand,
                        "current_market_price": master_material.current_market_price,
                        "default_unit": master_material.default_unit,
                        "is_from_change_request": True
                    }

        materials_for_dropdown = list(all_materials_dict.values())

        return jsonify({
            "item_id": boq_item.item_id,
            "item_name": boq_item.item_name,
            "scope" : sub_item.description,
            "size" : sub_item.size,
            "item_description": boq_item.description,
            "sub_items_count": len(sub_item_details),
            "sub_items": sub_item_details,
            "materials": materials_for_dropdown  # Top-level materials array for dropdown
        }), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error fetching sub-items for item {item_id}: {str(e)}")
        import traceback
        log.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500


# ===================================
# Custom Units Management
# ===================================

def get_custom_units():
    """Get all custom units (non-deleted)"""
    try:
        # ✅ PERFORMANCE: Limit to 200 units (typically much smaller dataset)
        custom_units = CustomUnit.query.filter_by(is_deleted=False).order_by(CustomUnit.unit_label.asc()).limit(200).all()

        units_data = []
        for unit in custom_units:
            units_data.append({
                "unit_id": unit.unit_id,
                "value": unit.unit_value,
                "label": unit.unit_label,
                "created_at": unit.created_at.isoformat() if unit.created_at else None,
                "created_by": unit.created_by
            })

        log.info(f"Retrieved {len(units_data)} custom units")
        return jsonify({
            "message": "Custom units retrieved successfully",
            "custom_units": units_data
        }), 200

    except Exception as e:
        log.error(f"Error fetching custom units: {str(e)}")
        import traceback
        log.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500


def create_custom_unit():
    """Create a new custom unit"""
    try:
        data = request.get_json()
        current_user = g.user

        # Validate required fields
        unit_value = data.get('unit_value', '').strip().lower()
        unit_label = data.get('unit_label', '').strip()

        if not unit_value or not unit_label:
            return jsonify({"error": "Both unit_value and unit_label are required"}), 400

        # Check if unit already exists (case-insensitive)
        existing_unit = CustomUnit.query.filter(
            func.lower(CustomUnit.unit_value) == unit_value,
            CustomUnit.is_deleted == False
        ).first()

        if existing_unit:
            return jsonify({
                "message": "Unit already exists",
                "unit": {
                    "unit_id": existing_unit.unit_id,
                    "value": existing_unit.unit_value,
                    "label": existing_unit.unit_label
                }
            }), 200

        # Create new custom unit
        new_unit = CustomUnit(
            unit_value=unit_value,
            unit_label=unit_label,
            created_by=current_user.get('email', 'Unknown')
        )

        db.session.add(new_unit)
        db.session.commit()

        log.info(f"Created custom unit: {unit_label} ({unit_value}) by {current_user.get('email')}")

        return jsonify({
            "message": "Custom unit created successfully",
            "unit": {
                "unit_id": new_unit.unit_id,
                "value": new_unit.unit_value,
                "label": new_unit.unit_label,
                "created_at": new_unit.created_at.isoformat() if new_unit.created_at else None
            }
        }), 201

    except SQLAlchemyError as e:
        db.session.rollback()
        log.error(f"Database error creating custom unit: {str(e)}")
        import traceback
        log.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"error": "Database error occurred"}), 500
    except Exception as e:
        db.session.rollback()
        log.error(f"Error creating custom unit: {str(e)}")
        import traceback
        log.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500

def get_pending_boq():
    """Get pending/draft BOQs - ESTIMATOR ONLY - OPTIMIZED FOR SPEED"""
    try:
        from sqlalchemy import func

        page = request.args.get('page', type=int)
        page_size = request.args.get('page_size', default=20, type=int)
        page_size = min(page_size, 100)

        current_user = getattr(g, 'user', None)
        user_id = current_user.get('user_id')
        user_role = current_user.get('role', '').lower() if current_user else ''

        context = get_effective_user_context()

        # ROLE RESTRICTION: Only Estimator and Admin (viewing as estimator) can access
        if user_role != 'admin' and user_role != 'estimator':
            return jsonify({
                'error': 'Access denied',
                'message': 'This endpoint is only accessible to Estimators'
            }), 403

        # OPTIMIZED: Column selection with joins
        query = (
            db.session.query(
                BOQ.boq_id,
                BOQ.boq_name,
                BOQ.project_id,
                BOQ.status,
                BOQ.client_status,
                BOQ.revision_number,
                BOQ.email_sent,
                BOQ.created_at,
                BOQ.created_by,
                BOQ.client_rejection_reason,
                BOQ.last_pm_user_id,
                Project.project_id.label('proj_id'),
                Project.project_name,
                Project.project_code,
                Project.work_type,
                Project.client,
                Project.location,
                Project.floor_name,
                Project.working_hours,
                Project.area,
                Project.description,
                Project.start_date,
                Project.duration_days,
                Project.end_date,
                Project.status.label('project_status'),
                Project.user_id,
                User.full_name.label('last_pm_name')
            )
            .select_from(Project)
            .outerjoin(BOQ, and_(BOQ.project_id == Project.project_id, BOQ.is_deleted == False))
            .outerjoin(User, BOQ.last_pm_user_id == User.user_id)
            .filter(Project.is_deleted == False)
            .filter(
                or_(
                    # BOQ with ONLY Draft status (explicitly check for Draft only)
                    BOQ.status.in_(['Draft', 'draft']),
                    # Project without any BOQ yet
                    BOQ.boq_id == None
                )
            )
        )

        # PERFORMANCE: Apply estimator filter (only if not admin)
        if user_role != 'admin' and should_apply_role_filter(context):
            query = query.filter(or_(Project.estimator_id == user_id, Project.estimator_id == None))

        query = query.order_by(Project.created_at.desc())

        # OPTIMIZED: Use func.count() instead of .count()
        if page is not None:
            total_count = query.with_entities(func.count()).scalar()

            if total_count == 0:
                return jsonify({
                    "message": "Pending/Draft BOQs and Draft Projects retrieved successfully",
                    "count": 0,
                    "data": [],
                    "pagination": {"page": page, "page_size": page_size, "total_count": 0, "total_pages": 0, "has_next": False, "has_prev": False}
                }), 200

            offset = (page - 1) * page_size
            rows = query.offset(offset).limit(page_size).all()
        else:
            rows = query.all()
            total_count = len(rows)

            if total_count == 0:
                return jsonify({"message": "Pending/Draft BOQs and Draft Projects retrieved successfully", "count": 0, "data": []}), 200

        # OPTIMIZED: Direct mapping (no N+1 queries)
        complete_boqs = [
            {
                "boq_id": row.boq_id,
                "boq_name": row.boq_name,
                "project_id": row.project_id if row.project_id else row.proj_id,
                "project_name": row.project_name,
                "project_code": row.project_code,
                "work_type": row.work_type,
                "client": row.client,
                "location": row.location,
                "floor": row.floor_name,
                "floor_name": row.floor_name,
                "hours": row.working_hours,
                "working_hours": row.working_hours,
                "area": row.area,
                "description": row.description,
                "start_date": row.start_date.isoformat() if row.start_date else None,
                "duration_days": row.duration_days,
                "end_date": row.end_date.isoformat() if row.end_date else None,
                "project_status": row.project_status,
                "status": row.status if row.status else "No BOQ",
                "client_status": row.client_status,
                "revision_number": row.revision_number or 0,
                "email_sent": row.email_sent if row.email_sent is not None else False,
                "user_id": row.user_id,
                "created_at": row.created_at.isoformat() if row.created_at else None,
                "created_by": row.created_by,
                "client_rejection_reason": row.client_rejection_reason,
                "last_pm_user_id": row.last_pm_user_id,
                "last_pm_name": row.last_pm_name
            }
            for row in rows
        ]

        response = {
            "message": "Pending/Draft BOQs and Draft Projects retrieved successfully",
            "count": len(complete_boqs),
            "data": complete_boqs
        }

        if page is not None:
            total_pages = (total_count + page_size - 1) // page_size
            response["pagination"] = {
                "page": page,
                "page_size": page_size,
                "total_count": total_count,
                "total_pages": total_pages,
                "has_next": page < total_pages,
                "has_prev": page > 1
            }

        return jsonify(response), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error retrieving BOQs: {str(e)}")
        return jsonify({'error': 'Failed to retrieve BOQs', 'details': str(e)}), 500


def get_approved_boq():
    """Get approved BOQs - OPTIMIZED FOR SPEED"""
    try:
        from sqlalchemy import func

        page = request.args.get('page', type=int)
        page_size = request.args.get('page_size', default=20, type=int)
        page_size = min(page_size, 100)

        current_user = getattr(g, 'user', None)
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        user_id = current_user.get('user_id')
        user_role = current_user.get('role', '').lower() if current_user else ''

        context = get_effective_user_context()

        # OPTIMIZED: Column selection with combined filters
        query = (
            db.session.query(
                BOQ.boq_id,
                BOQ.boq_name,
                BOQ.project_id,
                BOQ.status,
                BOQ.client_status,
                BOQ.revision_number,
                BOQ.email_sent,
                BOQ.created_at,
                BOQ.created_by,
                BOQ.client_rejection_reason,
                BOQ.last_pm_user_id,
                Project.project_name,
                Project.project_code,
                Project.client,
                Project.location,
                Project.floor_name,
                Project.working_hours,
                Project.user_id,
                User.full_name.label('last_pm_name')
            )
            .join(Project, BOQ.project_id == Project.project_id)
            .outerjoin(User, BOQ.last_pm_user_id == User.user_id)
            .filter(
                BOQ.is_deleted == False,
                Project.is_deleted == False,
                BOQ.status.in_(['approved', 'Approved', 'items_assigned', 'Sent_for_Confirmation', 'Client_Confirmed','PM_Approved','Revision_Approved'])
            )
        )

        # PERFORMANCE: Apply role filters early
        if user_role != 'admin' and should_apply_role_filter(context):
            if user_role in ['projectmanager', 'project_manager']:
                query = query.filter(Project.user_id.contains([user_id]))
            elif user_role == 'estimator':
                query = query.filter(or_(Project.estimator_id == user_id, Project.estimator_id == None))
            elif user_role in ['siteengineer', 'site_engineer', 'sitesupervisor', 'site_supervisor']:
                query = query.filter(Project.site_supervisor_id == user_id)
            elif user_role == 'buyer':
                query = query.filter(Project.buyer_id == user_id)

        query = query.order_by(BOQ.created_at.desc())

        # OPTIMIZED: Use func.count() instead of .count()
        if page is not None:
            total_count = query.with_entities(func.count()).scalar()

            if total_count == 0:
                return jsonify({
                    "message": "Approved BOQs retrieved successfully",
                    "count": 0,
                    "data": [],
                    "pagination": {"page": page, "page_size": page_size, "total_count": 0, "total_pages": 0, "has_next": False, "has_prev": False}
                }), 200

            offset = (page - 1) * page_size
            rows = query.offset(offset).limit(page_size).all()
        else:
            rows = query.all()
            total_count = len(rows)

            if total_count == 0:
                return jsonify({"message": "Approved BOQs retrieved successfully", "count": 0, "data": []}), 200

        # OPTIMIZED: Direct mapping (no N+1 queries)
        complete_boqs = [
            {
                "boq_id": row.boq_id,
                "boq_name": row.boq_name,
                "project_id": row.project_id,
                "project_name": row.project_name,
                "project_code": row.project_code,
                "client": row.client,
                "location": row.location,
                "floor": row.floor_name,
                "hours": row.working_hours,
                "status": row.status,
                "client_status": row.client_status,
                "revision_number": row.revision_number or 0,
                "email_sent": row.email_sent,
                "user_id": row.user_id,
                "created_at": row.created_at.isoformat() if row.created_at else None,
                "created_by": row.created_by,
                "client_rejection_reason": row.client_rejection_reason,
                "last_pm_user_id": row.last_pm_user_id,
                "last_pm_name": row.last_pm_name
            }
            for row in rows
        ]

        response = {
            "message": "Approved BOQs retrieved successfully",
            "count": len(complete_boqs),
            "data": complete_boqs
        }

        if page is not None:
            total_pages = (total_count + page_size - 1) // page_size
            response["pagination"] = {
                "page": page,
                "page_size": page_size,
                "total_count": total_count,
                "total_pages": total_pages,
                "has_next": page < total_pages,
                "has_prev": page > 1
            }

        return jsonify(response), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error retrieving approved BOQs: {str(e)}")
        return jsonify({'error': 'Failed to retrieve approved BOQs', 'details': str(e)}), 500


def get_rejected_boq():
    try:
        # PERFORMANCE: Optional pagination support (backward compatible)
        page = request.args.get('page', type=int)
        page_size = request.args.get('page_size', default=20, type=int)
        page_size = min(page_size, 100)  # Cap at 100 items per page

        # Get current logged-in user
        current_user = getattr(g, 'user', None)
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        user_id = current_user.get('user_id')
        user_role = current_user.get('role', '').lower() if current_user else ''

        # Get effective user context (handles admin viewing as other roles)
        context = get_effective_user_context()

        # OPTIMIZED: Select only required columns
        query = (
            db.session.query(
                BOQ.boq_id,
                BOQ.boq_name,
                BOQ.project_id,
                BOQ.status,
                BOQ.client_status,
                BOQ.revision_number,
                BOQ.email_sent,
                BOQ.created_at,
                BOQ.created_by,
                BOQ.client_rejection_reason,
                BOQ.last_pm_user_id,
                Project.project_name,
                Project.project_code,
                Project.client,
                Project.location,
                Project.floor_name,
                Project.working_hours,
                Project.user_id,
                User.full_name.label('last_pm_name')
            )
            .join(Project, BOQ.project_id == Project.project_id)
            .outerjoin(User, BOQ.last_pm_user_id == User.user_id)
            .filter(BOQ.is_deleted == False)
            .filter(Project.is_deleted == False)
            .filter(BOQ.status.in_(['rejected', 'Rejected', 'PM_Rejected', 'TD_Rejected', 'Client_Rejected', 'Internal_Revision_Pending']))
            .order_by(BOQ.created_at.desc())
        )

        # Role-based filtering for BOQs
        # Project.user_id is JSONB array, so use .contains() for array membership check
        if user_role != 'admin' and should_apply_role_filter(context):
            if user_role in ['projectmanager', 'project_manager']:
                query = query.filter(Project.user_id.contains([user_id]))
            elif user_role == 'estimator':
                query = query.filter(
                    or_(
                        Project.estimator_id == user_id,
                        Project.estimator_id == None
                    )
                )
            elif user_role in ['siteengineer', 'site_engineer', 'sitesupervisor', 'site_supervisor']:
                query = query.filter(Project.site_supervisor_id == user_id)
            elif user_role == 'buyer':
                query = query.filter(Project.buyer_id == user_id)

        # OPTIMIZED: Use func.count() instead of .count()
        from sqlalchemy import func
        if page is not None:
            total_count = query.with_entities(func.count()).scalar()
            if total_count == 0:
                return jsonify({"message": "Rejected BOQs retrieved successfully", "count": 0, "data": [], "pagination": {"page": page, "page_size": page_size, "total_count": 0, "total_pages": 0, "has_next": False, "has_prev": False}}), 200
            offset = (page - 1) * page_size
            rows = query.offset(offset).limit(page_size).all()
        else:
            rows = query.all()
            total_count = len(rows)
            if total_count == 0:
                return jsonify({"message": "Rejected BOQs retrieved successfully", "count": 0, "data": []}), 200

        # OPTIMIZED: Direct mapping (no N+1 queries)
        rejected_boqs = [
            {
                "boq_id": row.boq_id,
                "boq_name": row.boq_name,
                "project_id": row.project_id,
                "project_name": row.project_name,
                "project_code": row.project_code,
                "client": row.client,
                "location": row.location,
                "floor": row.floor_name,
                "hours": row.working_hours,
                "status": row.status,
                "client_status": row.client_status,
                "revision_number": row.revision_number or 0,
                "email_sent": row.email_sent,
                "user_id": row.user_id,
                "created_at": row.created_at.isoformat() if row.created_at else None,
                "created_by": row.created_by,
                "client_rejection_reason": row.client_rejection_reason,
                "last_pm_user_id": row.last_pm_user_id,
                "last_pm_name": row.last_pm_name
            }
            for row in rows
        ]

        # Build response
        response = {
            "message": "Rejected BOQs retrieved successfully",
            "count": len(rejected_boqs),
            "data": rejected_boqs
        }

        if page is not None:
            total_pages = (total_count + page_size - 1) // page_size
            response["pagination"] = {
                "page": page,
                "page_size": page_size,
                "total_count": total_count,
                "total_pages": total_pages,
                "has_next": page < total_pages,
                "has_prev": page > 1
            }

        return jsonify(response), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"[get_rejected_boq] Traceback: {traceback.format_exc()}")
        log.error(f"Error retrieving rejected BOQs: {str(e)}")
        return jsonify({
            'error': 'Failed to retrieve rejected BOQs',
            'details': str(e)
        }), 500


def get_completed_boq():
    try:
        # PERFORMANCE: Optional pagination support (backward compatible)
        page = request.args.get('page', type=int)
        page_size = request.args.get('page_size', default=20, type=int)
        page_size = min(page_size, 100)  # Cap at 100 items per page

        # Get current logged-in user
        current_user = getattr(g, 'user', None)
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        user_id = current_user.get('user_id')
        user_role = current_user.get('role', '').lower() if current_user else ''

        # Get effective user context (handles admin viewing as other roles)
        context = get_effective_user_context()

        # OPTIMIZED: Select only required columns
        query = (
            db.session.query(
                BOQ.boq_id,
                BOQ.boq_name,
                BOQ.project_id,
                BOQ.client_status,
                BOQ.revision_number,
                BOQ.email_sent,
                BOQ.created_at,
                BOQ.created_by,
                BOQ.client_rejection_reason,
                BOQ.last_pm_user_id,
                Project.project_name,
                Project.project_code,
                Project.client,
                Project.location,
                Project.floor_name,
                Project.working_hours,
                Project.user_id,
                User.full_name.label('last_pm_name')
            )
            .join(Project, BOQ.project_id == Project.project_id)
            .outerjoin(User, BOQ.last_pm_user_id == User.user_id)
            .filter(BOQ.is_deleted == False)
            .filter(Project.is_deleted == False)
            .filter(BOQ.status == 'completed')
            .order_by(BOQ.created_at.desc())
        )

        # Role-based filtering for BOQs
        if user_role != 'admin' and should_apply_role_filter(context):
            if user_role in ['projectmanager', 'project_manager']:
                query = query.filter(Project.user_id == user_id)
            elif user_role == 'estimator':
                query = query.filter(
                    or_(
                        Project.estimator_id == user_id,
                        Project.estimator_id == None
                    )
                )
            elif user_role in ['siteengineer', 'site_engineer', 'sitesupervisor', 'site_supervisor']:
                query = query.filter(Project.site_supervisor_id == user_id)
            elif user_role == 'buyer':
                query = query.filter(Project.buyer_id == user_id)

        # OPTIMIZED: Use func.count() instead of .count()
        from sqlalchemy import func
        if page is not None:
            total_count = query.with_entities(func.count()).scalar()
            if total_count == 0:
                return jsonify({"message": "Completed BOQs retrieved successfully", "count": 0, "data": [], "pagination": {"page": page, "page_size": page_size, "total_count": 0, "total_pages": 0, "has_next": False, "has_prev": False}}), 200
            offset = (page - 1) * page_size
            rows = query.offset(offset).limit(page_size).all()
        else:
            rows = query.all()
            total_count = len(rows)
            if total_count == 0:
                return jsonify({"message": "Completed BOQs retrieved successfully", "count": 0, "data": []}), 200

        # OPTIMIZED: Direct mapping (no N+1 queries)
        completed_boqs = [
            {
                "boq_id": row.boq_id,
                "boq_name": row.boq_name,
                "project_id": row.project_id,
                "project_name": row.project_name,
                "project_code": row.project_code,
                "client": row.client,
                "location": row.location,
                "floor": row.floor_name,
                "hours": row.working_hours,
                "status": "completed",  # Always completed (filtered in query)
                "client_status": row.client_status,
                "revision_number": row.revision_number or 0,
                "email_sent": row.email_sent,
                "user_id": row.user_id,
                "created_at": row.created_at.isoformat() if row.created_at else None,
                "created_by": row.created_by,
                "client_rejection_reason": row.client_rejection_reason,
                "last_pm_user_id": row.last_pm_user_id,
                "last_pm_name": row.last_pm_name
            }
            for row in rows
        ]

        # Build response
        response = {
            "message": "Completed BOQs retrieved successfully",
            "count": len(completed_boqs),
            "data": completed_boqs
        }

        if page is not None:
            total_pages = (total_count + page_size - 1) // page_size
            response["pagination"] = {
                "page": page,
                "page_size": page_size,
                "total_count": total_count,
                "total_pages": total_pages,
                "has_next": page < total_pages,
                "has_prev": page > 1
            }

        return jsonify(response), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"[get_completed_boq] Traceback: {traceback.format_exc()}")
        log.error(f"Error retrieving completed BOQs: {str(e)}")
        return jsonify({
            'error': 'Failed to retrieve completed BOQs',
            'details': str(e)
        }), 500


def get_send_to_client_boq():
    try:
        # PERFORMANCE: Optional pagination support (backward compatible)
        page = request.args.get('page', type=int)
        page_size = request.args.get('page_size', default=20, type=int)
        page_size = min(page_size, 100)  # Cap at 100 items per page

        # Get current logged-in user
        current_user = getattr(g, 'user', None)
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        user_id = current_user.get('user_id')
        user_role = current_user.get('role', '').lower() if current_user else ''

        # Get effective user context (handles admin viewing as other roles)
        context = get_effective_user_context()

        # OPTIMIZED: Select only required columns
        query = (
            db.session.query(
                BOQ.boq_id,
                BOQ.boq_name,
                BOQ.project_id,
                BOQ.status,
                BOQ.client_status,
                BOQ.revision_number,
                BOQ.email_sent,
                BOQ.created_at,
                BOQ.created_by,
                BOQ.client_rejection_reason,
                BOQ.last_pm_user_id,
                Project.project_name,
                Project.project_code,
                Project.client,
                Project.location,
                Project.floor_name,
                Project.working_hours,
                Project.user_id,
                User.full_name.label('last_pm_name')
            )
            .join(Project, BOQ.project_id == Project.project_id)
            .outerjoin(User, BOQ.last_pm_user_id == User.user_id)
            .filter(BOQ.is_deleted == False)
            .filter(Project.is_deleted == False)
            .filter(BOQ.status.in_(['Pending_PM_Approval', 'Pending', 'Pending_TD_Approval']))
            .order_by(BOQ.created_at.desc())
        )

        # Role-based filtering for BOQs
        # Project.user_id is JSONB array, so use .contains() for array membership check
        if user_role != 'admin' and should_apply_role_filter(context):
            if user_role in ['projectmanager', 'project_manager']:
                query = query.filter(Project.user_id.contains([user_id]))
            elif user_role == 'estimator':
                query = query.filter(
                    or_(
                        Project.estimator_id == user_id,
                        Project.estimator_id == None
                    )
                )
            elif user_role in ['siteengineer', 'site_engineer', 'sitesupervisor', 'site_supervisor']:
                query = query.filter(Project.site_supervisor_id == user_id)
            elif user_role == 'buyer':
                query = query.filter(Project.buyer_id == user_id)

        # OPTIMIZED: Use func.count() instead of .count()
        from sqlalchemy import func
        if page is not None:
            total_count = query.with_entities(func.count()).scalar()
            if total_count == 0:
                return jsonify({"message": "Send to client BOQs retrieved successfully", "count": 0, "data": [], "pagination": {"page": page, "page_size": page_size, "total_count": 0, "total_pages": 0, "has_next": False, "has_prev": False}}), 200
            offset = (page - 1) * page_size
            rows = query.offset(offset).limit(page_size).all()
        else:
            rows = query.all()
            total_count = len(rows)
            if total_count == 0:
                return jsonify({"message": "Send to client BOQs retrieved successfully", "count": 0, "data": []}), 200

        # OPTIMIZED: Direct mapping (no N+1 queries)
        send_to_client_boqs = [
            {
                "boq_id": row.boq_id,
                "boq_name": row.boq_name,
                "project_id": row.project_id,
                "project_name": row.project_name,
                "project_code": row.project_code,
                "client": row.client,
                "location": row.location,
                "floor": row.floor_name,
                "hours": row.working_hours,
                "status": row.status,  # Always send_to_client (filtered in query)
                "client_status": row.client_status,
                "revision_number": row.revision_number or 0,
                "email_sent": row.email_sent,
                "user_id": row.user_id,
                "created_at": row.created_at.isoformat() if row.created_at else None,
                "created_by": row.created_by,
                "client_rejection_reason": row.client_rejection_reason,
                "last_pm_user_id": row.last_pm_user_id,
                "last_pm_name": row.last_pm_name
            }
            for row in rows
        ]

        # Build response
        response = {
            "message": "Send to client BOQs retrieved successfully",
            "count": len(send_to_client_boqs),
            "data": send_to_client_boqs
        }

        if page is not None:
            total_pages = (total_count + page_size - 1) // page_size
            response["pagination"] = {
                "page": page,
                "page_size": page_size,
                "total_count": total_count,
                "total_pages": total_pages,
                "has_next": page < total_pages,
                "has_prev": page > 1
            }

        return jsonify(response), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"Error retrieving send to client BOQs: {str(e)}")
        return jsonify({
            'error': 'Failed to retrieve send to client BOQs',
            'details': str(e)
        }), 500


def get_cancelled_boq():
    try:
        # PERFORMANCE: Optional pagination support (backward compatible)
        page = request.args.get('page', type=int)
        page_size = request.args.get('page_size', default=20, type=int)
        page_size = min(page_size, 100)  # Cap at 100 items per page

        # Get current logged-in user
        current_user = getattr(g, 'user', None)
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        user_id = current_user.get('user_id')
        user_role = current_user.get('role', '').lower() if current_user else ''

        # Get effective user context (handles admin viewing as other roles)
        context = get_effective_user_context()

        # OPTIMIZED: Select only required columns
        query = (
            db.session.query(
                BOQ.boq_id,
                BOQ.boq_name,
                BOQ.project_id,
                BOQ.client_status,
                BOQ.revision_number,
                BOQ.email_sent,
                BOQ.created_at,
                BOQ.created_by,
                BOQ.client_rejection_reason,
                BOQ.last_pm_user_id,
                Project.project_name,
                Project.project_code,
                Project.client,
                Project.location,
                Project.floor_name,
                Project.working_hours,
                Project.user_id,
                User.full_name.label('last_pm_name')
            )
            .join(Project, BOQ.project_id == Project.project_id)
            .outerjoin(User, BOQ.last_pm_user_id == User.user_id)
            .filter(BOQ.is_deleted == False)
            .filter(Project.is_deleted == False)
            .filter(BOQ.status == 'Client_Cancelled')
            .order_by(BOQ.created_at.desc())
        )

        # Role-based filtering for BOQs
        if user_role != 'admin' and should_apply_role_filter(context):
            if user_role in ['projectmanager', 'project_manager']:
                query = query.filter(Project.user_id == user_id)
            elif user_role == 'estimator':
                query = query.filter(
                    or_(
                        Project.estimator_id == user_id,
                        Project.estimator_id == None
                    )
                )
            elif user_role in ['siteengineer', 'site_engineer', 'sitesupervisor', 'site_supervisor']:
                query = query.filter(Project.site_supervisor_id == user_id)
            elif user_role == 'buyer':
                query = query.filter(Project.buyer_id == user_id)

        # OPTIMIZED: Use func.count() instead of .count()
        from sqlalchemy import func
        if page is not None:
            total_count = query.with_entities(func.count()).scalar()
            if total_count == 0:
                return jsonify({"message": "Cancelled BOQs retrieved successfully", "count": 0, "data": [], "pagination": {"page": page, "page_size": page_size, "total_count": 0, "total_pages": 0, "has_next": False, "has_prev": False}}), 200
            offset = (page - 1) * page_size
            rows = query.offset(offset).limit(page_size).all()
        else:
            rows = query.all()
            total_count = len(rows)
            if total_count == 0:
                return jsonify({"message": "Cancelled BOQs retrieved successfully", "count": 0, "data": []}), 200

        # OPTIMIZED: Direct mapping (no N+1 queries)
        cancelled_boqs = [
            {
                "boq_id": row.boq_id,
                "boq_name": row.boq_name,
                "project_id": row.project_id,
                "project_name": row.project_name,
                "project_code": row.project_code,
                "client": row.client,
                "location": row.location,
                "floor": row.floor_name,
                "hours": row.working_hours,
                "status": "cancelled",  # Always cancelled (filtered in query)
                "client_status": row.client_status,
                "revision_number": row.revision_number or 0,
                "email_sent": row.email_sent,
                "user_id": row.user_id,
                "created_at": row.created_at.isoformat() if row.created_at else None,
                "created_by": row.created_by,
                "client_rejection_reason": row.client_rejection_reason,
                "last_pm_user_id": row.last_pm_user_id,
                "last_pm_name": row.last_pm_name
            }
            for row in rows
        ]

        # Build response
        response = {
            "message": "Cancelled BOQs retrieved successfully",
            "count": len(cancelled_boqs),
            "data": cancelled_boqs
        }

        if page is not None:
            total_pages = (total_count + page_size - 1) // page_size
            response["pagination"] = {
                "page": page,
                "page_size": page_size,
                "total_count": total_count,
                "total_pages": total_pages,
                "has_next": page < total_pages,
                "has_prev": page > 1
            }

        return jsonify(response), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"[get_cancelled_boq] Traceback: {traceback.format_exc()}")
        log.error(f"Error retrieving cancelled BOQs: {str(e)}")
        return jsonify({
            'error': 'Failed to retrieve cancelled BOQs',
            'details': str(e)
        }), 500


def get_revisions_boq():
    """Get BOQs that are under revision or have revision history"""
    try:
        # PERFORMANCE: Optional pagination support (backward compatible)
        page = request.args.get('page', type=int)
        page_size = request.args.get('page_size', default=20, type=int)
        page_size = min(page_size, 100)  # Cap at 100 items per page

        # Get current logged-in user
        current_user = getattr(g, 'user', None)
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        user_id = current_user.get('user_id')
        user_role = current_user.get('role', '').lower() if current_user else ''

        # Get effective user context (handles admin viewing as other roles)
        context = get_effective_user_context()

        # OPTIMIZED: Select only required columns
        query = (
            db.session.query(
                BOQ.boq_id,
                BOQ.boq_name,
                BOQ.project_id,
                BOQ.status,
                BOQ.client_status,
                BOQ.revision_number,
                BOQ.email_sent,
                BOQ.created_at,
                BOQ.created_by,
                BOQ.client_rejection_reason,
                BOQ.last_pm_user_id,
                Project.project_name,
                Project.project_code,
                Project.client,
                Project.location,
                Project.floor_name,
                Project.working_hours,
                Project.user_id,
                User.full_name.label('last_pm_name')
            )
            .join(Project, BOQ.project_id == Project.project_id)
            .outerjoin(User, BOQ.last_pm_user_id == User.user_id)
            .filter(BOQ.is_deleted == False)
            .filter(Project.is_deleted == False)
            .filter(
                or_(
                    BOQ.status.in_(['under_revision', 'pending_revision', 'revision_approved']),
                    BOQ.revision_number > 0
                )
            )
            .order_by(BOQ.created_at.desc())
        )

        # Role-based filtering for BOQs
        if user_role != 'admin' and should_apply_role_filter(context):
            if user_role in ['projectmanager', 'project_manager']:
                query = query.filter(Project.user_id.contains([user_id]))
            elif user_role == 'estimator':
                query = query.filter(
                    or_(
                        Project.estimator_id == user_id,
                        Project.estimator_id == None
                    )
                )
            elif user_role in ['siteengineer', 'site_engineer', 'sitesupervisor', 'site_supervisor']:
                query = query.filter(Project.site_supervisor_id == user_id)
            elif user_role == 'buyer':
                query = query.filter(Project.buyer_id == user_id)

        # OPTIMIZED: Use func.count() instead of .count()
        from sqlalchemy import func
        if page is not None:
            total_count = query.with_entities(func.count()).scalar()
            if total_count == 0:
                return jsonify({"message": "Revision BOQs retrieved successfully", "count": 0, "data": [], "pagination": {"page": page, "page_size": page_size, "total_count": 0, "total_pages": 0, "has_next": False, "has_prev": False}}), 200
            offset = (page - 1) * page_size
            rows = query.offset(offset).limit(page_size).all()
        else:
            rows = query.all()
            total_count = len(rows)
            if total_count == 0:
                return jsonify({"message": "Revision BOQs retrieved successfully", "count": 0, "data": []}), 200

        # OPTIMIZED: Direct mapping (no N+1 queries)
        revision_boqs = [
            {
                "boq_id": row.boq_id,
                "boq_name": row.boq_name,
                "project_id": row.project_id,
                "project_name": row.project_name,
                "project_code": row.project_code,
                "client": row.client,
                "location": row.location,
                "floor": row.floor_name,
                "hours": row.working_hours,
                "status": row.status,
                "client_status": row.client_status,
                "revision_number": row.revision_number or 0,
                "email_sent": row.email_sent,
                "user_id": row.user_id,
                "created_at": row.created_at.isoformat() if row.created_at else None,
                "created_by": row.created_by,
                "client_rejection_reason": row.client_rejection_reason,
                "last_pm_user_id": row.last_pm_user_id,
                "last_pm_name": row.last_pm_name
            }
            for row in rows
        ]

        # Build response
        response = {
            "message": "Revision BOQs retrieved successfully",
            "count": len(revision_boqs),
            "data": revision_boqs
        }

        if page is not None:
            total_pages = (total_count + page_size - 1) // page_size
            response["pagination"] = {
                "page": page,
                "page_size": page_size,
                "total_count": total_count,
                "total_pages": total_pages,
                "has_next": page < total_pages,
                "has_prev": page > 1
            }

        return jsonify(response), 200

    except Exception as e:
        db.session.rollback()
        log.error(f"[get_revisions_boq] Traceback: {traceback.format_exc()}")
        log.error(f"Error retrieving revision BOQs: {str(e)}")
        return jsonify({
            'error': 'Failed to retrieve revision BOQs',
            'details': str(e)
        }), 500


def search_all_materials():
    """Search all materials across all BOQs for autocomplete suggestions.
    Returns distinct material names with their latest details (brand, size, unit, price).
    Query params: q (search term), limit (max results, default 20)
    """
    try:
        search_term = request.args.get('q', '').strip()
        try:
            limit = min(int(request.args.get('limit', 20)), 50)
        except (ValueError, TypeError):
            limit = 20

        if len(search_term) < 1:
            return jsonify({"success": True, "materials": []}), 200

        # Subquery to get the latest material_id for each unique material_name
        latest_material = db.session.query(
            func.max(MasterMaterial.material_id).label('max_id')
        ).filter(
            MasterMaterial.is_active == True,
            MasterMaterial.material_name.ilike(f'%{search_term}%')
        ).group_by(
            func.lower(func.trim(MasterMaterial.material_name))
        ).subquery()

        materials = db.session.query(MasterMaterial).filter(
            MasterMaterial.material_id.in_(
                db.session.query(latest_material.c.max_id)
            )
        ).order_by(
            # Prioritize exact prefix matches
            db.case(
                (MasterMaterial.material_name.ilike(f'{search_term}%'), 0),
                else_=1
            ),
            MasterMaterial.material_name
        ).limit(limit).all()

        results = []
        for mat in materials:
            results.append({
                "material_id": mat.material_id,
                "material_name": mat.material_name,
                "brand": mat.brand or '',
                "size": mat.size or '',
                "specification": mat.specification or '',
                "description": mat.description or '',
                "default_unit": mat.default_unit,
                "current_market_price": mat.current_market_price or 0
            })

        return jsonify({"success": True, "materials": results}), 200

    except Exception as e:
        log.error(f"[search_all_materials] Error: {str(e)}")
        return jsonify({"success": False, "error": "Failed to search materials"}), 500


def search_all_labours():
    """Search all labours across all BOQs for autocomplete suggestions.
    Returns distinct labour roles with their latest details (work_type, hours, rate).
    Query params: q (search term), limit (max results, default 20)
    """
    try:
        search_term = request.args.get('q', '').strip()
        try:
            limit = min(int(request.args.get('limit', 20)), 50)
        except (ValueError, TypeError):
            limit = 20

        if len(search_term) < 1:
            return jsonify({"success": True, "labours": []}), 200

        # Subquery to get the latest labour_id for each unique labour_role
        latest_labour = db.session.query(
            func.max(MasterLabour.labour_id).label('max_id')
        ).filter(
            MasterLabour.is_active == True,
            MasterLabour.labour_role.ilike(f'%{search_term}%')
        ).group_by(
            func.lower(func.trim(MasterLabour.labour_role))
        ).subquery()

        labours = db.session.query(MasterLabour).filter(
            MasterLabour.labour_id.in_(
                db.session.query(latest_labour.c.max_id)
            )
        ).order_by(
            db.case(
                (MasterLabour.labour_role.ilike(f'{search_term}%'), 0),
                else_=1
            ),
            MasterLabour.labour_role
        ).limit(limit).all()

        results = [{
            "labour_id": lab.labour_id,
            "labour_role": lab.labour_role,
            "work_type": lab.work_type or 'daily_wages',
            "hours": lab.hours or 0,
            "rate_per_hour": lab.rate_per_hour or 0,
            "amount": lab.amount or 0
        } for lab in labours]

        return jsonify({"success": True, "labours": results}), 200

    except Exception as e:
        log.error(f"[search_all_labours] Error: {str(e)}")
        return jsonify({"success": False, "error": "Failed to search labours"}), 500